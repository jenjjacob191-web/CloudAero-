# ✈️ CloudAero DGCA — Aviation Examination Preparation Platform

India's premier computer-based test (CBT) simulator and ground theory preparation platform for **DGCA CPL, ATPL, and PPL** examinations.

Designed to mirror the official **DGCA Pariksha** examination environment with timed mock papers, chapter-wise question drills, instant in-depth explanations, and single-device security.

---

## 🌟 Key Features

- **DGCA Pariksha CBT Simulator**: Timed examination interface (2.0 to 2.5 hours) with authentic question palette navigation (Answered, Flagged for Review, Not Visited), chronometer countdown, and auto-submission at the 70% passing threshold.
- **5 Core DGCA Syllabus Modules**:
  - `Module 0101`: Air Regulations (ICAO Annex 2, Indian Aircraft Rules 1937, CARs)
  - `Module 0102`: Aviation Meteorology (Altimetry, Monsoons, Jet Streams, CAT, Synoptic Charts)
  - `Module 0103`: Air Navigation (1:60 Rule, Wind Triangles, VOR/DME/ILS, PBN)
  - `Module 0104`: Technical General (Gas Turbines, Hydraulics, Electrics, Aerodynamics)
  - `Module 0105`: Technical Specific (Type-Specific Systems, Weight & Balance, Performance)
- **Instant In-Depth Explanations**: Every question includes step-by-step formula derivations, altimetry rules, and official regulatory citations.
- **Dual-Mode Secure Authentication**:
  - **Passwordless Email OTP**: Fast 6-digit login codes dispatched directly to candidate inboxes.
  - **Traditional Password**: Encrypted authentication backed by Supabase Auth.
- **Single-Device Session Enforcement**: Real-time heartbeat tracking prevents credential sharing by terminating previous device sessions automatically upon new login.
- **Anti-Screenshot & Content Protection**: PrintScreen interception, clipboard flushing, and forensic candidate watermarks to safeguard confidential DGCA material.
- **Razorpay Payment Integration**: Integrated checkout for Monthly (₹300) and Six-Month (₹1,500) subscription passes with HMAC signature verification.

---

## 🚀 Quick Start Guide

### 1. Prerequisites
- **Node.js**: `v18.17.0` or higher (Node 20+ recommended)
- **npm** or **pnpm**

### 2. Installation
```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/aeroprep-dgca.git
cd aeroprep-dgca

# Install dependencies
npm install
```

### 3. Environment Configuration
Copy `.env.example` to `.env.local`:
```bash
cp .env.example .env.local
```

Fill in your configuration variables in `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

NEXT_PUBLIC_RAZORPAY_KEY_ID=rzp_test_xxx
RAZORPAY_KEY_SECRET=xxx
RAZORPAY_WEBHOOK_SECRET=xxx

NEXT_PUBLIC_ADMIN_EMAILS=admin@cloudaero.in,admin@dgca.gov.in
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### 4. Running the Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 5. Running the Pre-Flight Smoke Test Suite
```bash
npm run test:smoke
```

### 6. Production Build
```bash
npm run build
npm run start
```

---

## 📁 Project Architecture

```
aeroprep-dgca/
├── public/                 # Static assets, branding logos, icons, manifest
├── src/
│   ├── app/                # Next.js 14 App Router (35 routes)
│   │   ├── (auth)/         # Login, Register, Forgot Password
│   │   ├── (student)/      # Dashboard, CBT Exam Room, Question Practice
│   │   ├── (admin)/        # Admin Console (Questions, Syllabus, Mocks, Reports)
│   │   ├── api/            # Serverless endpoints (Auth OTP, Sessions, Razorpay)
│   │   ├── layout.tsx      # Root Layout with Security & Auth Providers
│   │   └── page.tsx        # Homepage
│   ├── components/         # Modular React Components
│   │   ├── home/           # Interactive Hero, Subject Modules, Features
│   │   ├── security/       # Anti-Screenshot Guard & Session Watermarks
│   │   └── layout/         # Navigation & Footer
│   ├── data/               # Official DGCA Syllabus & Mock Definitions
│   ├── lib/                # Supabase Client, Auth Context, Session Manager
│   └── types/              # TypeScript Interfaces & Database Types
└── scripts/                # Automated Smoke Test Runner & Packaging
```

---

## 🗄️ Supabase Database Setup

1. Create a new project at [supabase.com](https://supabase.com).
2. Go to the **SQL Editor** in your Supabase dashboard.
3. Open `supabase/schema.sql`, copy all contents, and click **Run**. This creates all tables (`profiles`, `subscription_plans`, `questions`, `mock_exams`, etc.) with Row-Level Security (RLS).
4. (Optional) Run `supabase/seed.sql` to populate initial syllabus modules and questions.
5. In your Supabase Project Settings under **API**, copy:
   - **Project URL** -> `NEXT_PUBLIC_SUPABASE_URL`
   - **anon / public key** -> `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **service_role secret** -> `SUPABASE_SERVICE_ROLE_KEY`

---

## 🌐 Deploy to Vercel

1. Push this repository to your **GitHub** account.
2. Go to [vercel.com/new](https://vercel.com/new).
3. Import your `AEROP` or `aeroprep-dgca` repository.
4. Add the environment variables from `.env.example` in the Vercel dashboard.
5. Click **Deploy**. Vercel will build and deploy the Next.js application automatically with 100% static & dynamic route support.

---

## 📄 License
Proprietary & Confidential — © 2026 CloudAero DGCA India. All rights reserved.
