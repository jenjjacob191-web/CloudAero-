@echo off
title CloudAero DGCA - GitHub Deployer
color 0b
echo ======================================================================
echo           CLOUDAERO DGCA - PUSH TO GITHUB
echo ======================================================================
echo.
cd /d "C:\Users\jenjj\.gemini\antigravity\scratch\aeroprep-dgca"

echo Setting branch to main...
git branch -M main

echo Staging all project files...
git add .

echo Committing updates...
git commit -m "Production release: Clean CloudAero DGCA codebase"

echo Pushing directly to GitHub...
git push -u origin main

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ======================================================================
    echo  SUCCESS! All project files have been pushed to GitHub!
    echo.
    echo  Vercel is now automatically rebuilding your project.
    echo  Open your Vercel dashboard to watch it deploy live!
    echo ======================================================================
) else (
    echo.
    echo ======================================================================
    echo  Push encountered an issue. If Git prompted you to sign in,
    echo  please sign in via your browser window to authenticate.
    echo ======================================================================
)

echo.
pause
