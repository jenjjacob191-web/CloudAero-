-- ============================================================================
-- AEROPREP DGCA — COMPLETE SUPABASE DATABASE SETUP SCRIPT
-- ============================================================================
-- Version: 2.0.0 (Production Master)
-- Compatible with: Supabase PostgreSQL (15+)
-- Description: Run this entire script in Supabase SQL Editor in one click.
-- It initializes all extensions, database tables, auth hooks, Row-Level
-- Security (RLS) policies, and initial DGCA syllabus & mock exam seed data.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- STEP 0: ENABLE REQUIRED POSTGRESQL EXTENSIONS
-- ----------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- User role ENUM ('student', 'admin') enables interactive dropdown in Supabase Table Editor
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_role') THEN
        CREATE TYPE public.user_role AS ENUM ('student', 'admin');
    END IF;
END $$;

-- ----------------------------------------------------------------------------
-- STEP 1: PROFILES & USER ACCOUNTS (Linked to Supabase Auth)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    role public.user_role NOT NULL DEFAULT 'student'::public.user_role,
    avatar_url TEXT,
    phone_number TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(role);

-- Automatic Profile Creation Trigger on Supabase Auth Signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, email, full_name, role)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', 'Student Aviator'),
        COALESCE(NEW.raw_user_meta_data->>'role', 'student')
    )
    ON CONFLICT (id) DO UPDATE
    SET email = EXCLUDED.email,
        full_name = COALESCE(EXCLUDED.full_name, public.profiles.full_name);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ----------------------------------------------------------------------------
-- STEP 2: SUBSCRIPTION PLANS & BILLING
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.subscription_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code TEXT NOT NULL UNIQUE CHECK (code IN ('monthly', 'six_month')),
    name TEXT NOT NULL,
    price_inr NUMERIC(10, 2) NOT NULL,
    duration_months INT NOT NULL,
    description TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.user_subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    plan_id UUID NOT NULL REFERENCES public.subscription_plans(id),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('active', 'expired', 'cancelled', 'pending')),
    starts_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_user_subscriptions_user ON public.user_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_subscriptions_status ON public.user_subscriptions(status, expires_at);

CREATE TABLE IF NOT EXISTS public.payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    subscription_id UUID REFERENCES public.user_subscriptions(id) ON DELETE SET NULL,
    gateway_provider TEXT NOT NULL DEFAULT 'razorpay',
    gateway_order_id TEXT NOT NULL UNIQUE,
    gateway_payment_id TEXT UNIQUE,
    gateway_signature TEXT,
    amount_inr NUMERIC(10, 2) NOT NULL,
    currency TEXT NOT NULL DEFAULT 'INR',
    status TEXT NOT NULL DEFAULT 'created' CHECK (status IN ('created', 'captured', 'failed', 'refunded')),
    error_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    verified_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_payments_user ON public.payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_order ON public.payments(gateway_order_id);

-- ----------------------------------------------------------------------------
-- STEP 3: DGCA SYLLABUS HIERARCHY (Subjects -> Chapters -> Topics)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.subjects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL UNIQUE,
    code TEXT NOT NULL UNIQUE,
    slug TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL,
    icon_name TEXT NOT NULL DEFAULT 'Plane',
    display_order INT NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.chapters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    subject_id UUID NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    slug TEXT NOT NULL,
    chapter_number INT NOT NULL,
    revision_notes TEXT,
    display_order INT NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(subject_id, slug),
    UNIQUE(subject_id, chapter_number)
);

CREATE INDEX IF NOT EXISTS idx_chapters_subject ON public.chapters(subject_id);

CREATE TABLE IF NOT EXISTS public.topics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    chapter_id UUID NOT NULL REFERENCES public.chapters(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    slug TEXT NOT NULL,
    display_order INT NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(chapter_id, slug)
);

CREATE INDEX IF NOT EXISTS idx_topics_chapter ON public.topics(chapter_id);

-- ----------------------------------------------------------------------------
-- STEP 4: QUESTION BANK & MULTIPLE CHOICE OPTIONS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.questions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    chapter_id UUID NOT NULL REFERENCES public.chapters(id) ON DELETE CASCADE,
    topic_id UUID REFERENCES public.topics(id) ON DELETE SET NULL,
    question_text TEXT NOT NULL,
    explanation TEXT NOT NULL,
    difficulty TEXT NOT NULL DEFAULT 'medium' CHECK (difficulty IN ('easy', 'medium', 'hard')),
    question_source TEXT NOT NULL DEFAULT 'AeroPrep Question Bank',
    exam_year INT,
    image_url TEXT,
    is_demo BOOLEAN NOT NULL DEFAULT FALSE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_questions_chapter ON public.questions(chapter_id);
CREATE INDEX IF NOT EXISTS idx_questions_demo ON public.questions(is_demo);

CREATE TABLE IF NOT EXISTS public.question_options (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    question_id UUID NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
    option_text TEXT NOT NULL,
    is_correct BOOLEAN NOT NULL DEFAULT FALSE,
    display_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_question_options_question ON public.question_options(question_id);

-- ----------------------------------------------------------------------------
-- STEP 5: MOCK EXAMINATIONS & CBT SIMULATION
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.mock_exams (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    subject_id UUID REFERENCES public.subjects(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 120,
    total_questions INT NOT NULL DEFAULT 70,
    passing_percentage NUMERIC(5, 2) NOT NULL DEFAULT 70.00,
    marks_per_question NUMERIC(4, 2) NOT NULL DEFAULT 1.00,
    negative_marking NUMERIC(4, 2) NOT NULL DEFAULT 0.00,
    is_premium BOOLEAN NOT NULL DEFAULT TRUE,
    is_published BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.mock_exam_questions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    mock_exam_id UUID NOT NULL REFERENCES public.mock_exams(id) ON DELETE CASCADE,
    question_id UUID NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
    question_order INT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(mock_exam_id, question_id),
    UNIQUE(mock_exam_id, question_order)
);

CREATE INDEX IF NOT EXISTS idx_mock_exam_questions_exam ON public.mock_exam_questions(mock_exam_id);

CREATE TABLE IF NOT EXISTS public.exam_attempts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    mock_exam_id UUID NOT NULL REFERENCES public.mock_exams(id) ON DELETE CASCADE,
    score NUMERIC(6, 2) DEFAULT 0.00,
    percentage NUMERIC(5, 2) DEFAULT 0.00,
    total_questions INT NOT NULL,
    correct_count INT DEFAULT 0,
    incorrect_count INT DEFAULT 0,
    unattempted_count INT DEFAULT 0,
    marked_review_count INT DEFAULT 0,
    time_spent_seconds INT DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'completed', 'abandoned')),
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_exam_attempts_user ON public.exam_attempts(user_id);
CREATE INDEX IF NOT EXISTS idx_exam_attempts_exam ON public.exam_attempts(mock_exam_id);

CREATE TABLE IF NOT EXISTS public.exam_responses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    attempt_id UUID NOT NULL REFERENCES public.exam_attempts(id) ON DELETE CASCADE,
    question_id UUID NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
    selected_option_id UUID REFERENCES public.question_options(id) ON DELETE SET NULL,
    is_correct BOOLEAN DEFAULT FALSE,
    is_marked_for_review BOOLEAN DEFAULT FALSE,
    response_time_seconds INT DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(attempt_id, question_id)
);

CREATE INDEX IF NOT EXISTS idx_exam_responses_attempt ON public.exam_responses(attempt_id);

-- ----------------------------------------------------------------------------
-- STEP 6: STUDENT PROGRESS, REVISION BOOKMARKS & REPORTS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.chapter_progress (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    chapter_id UUID NOT NULL REFERENCES public.chapters(id) ON DELETE CASCADE,
    questions_attempted INT NOT NULL DEFAULT 0,
    questions_correct INT NOT NULL DEFAULT 0,
    is_completed BOOLEAN NOT NULL DEFAULT FALSE,
    last_practiced_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(user_id, chapter_id)
);

CREATE TABLE IF NOT EXISTS public.bookmarks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    question_id UUID NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(user_id, question_id)
);

CREATE TABLE IF NOT EXISTS public.question_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    question_id UUID NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
    report_type TEXT NOT NULL CHECK (report_type IN ('incorrect_answer', 'ambiguous_wording', 'typo', 'outdated_regulation', 'other')),
    description TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'resolved', 'dismissed')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ
);

-- ----------------------------------------------------------------------------
-- STEP 7: ROW-LEVEL SECURITY (RLS) POLICIES
-- ----------------------------------------------------------------------------
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscription_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.topics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.question_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mock_exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mock_exam_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chapter_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookmarks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.question_reports ENABLE ROW LEVEL SECURITY;

-- Helper: Check if current user is an administrator
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND role = 'admin'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Profiles Policies
DROP POLICY IF EXISTS "Users can read own profile" ON public.profiles;
CREATE POLICY "Users can read own profile" ON public.profiles
    FOR SELECT USING (auth.uid() = id OR public.is_admin());

DROP POLICY IF EXISTS "Users can update own non-sensitive profile info" ON public.profiles;
CREATE POLICY "Users can update own non-sensitive profile info" ON public.profiles
    FOR UPDATE USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id AND role = (SELECT role FROM public.profiles WHERE id = auth.uid()));

-- Public Catalog Policies
DROP POLICY IF EXISTS "Anyone can view active subjects" ON public.subjects;
CREATE POLICY "Anyone can view active subjects" ON public.subjects
    FOR SELECT USING (is_active = TRUE OR public.is_admin());

DROP POLICY IF EXISTS "Anyone can view active chapters" ON public.chapters;
CREATE POLICY "Anyone can view active chapters" ON public.chapters
    FOR SELECT USING (is_active = TRUE OR public.is_admin());

DROP POLICY IF EXISTS "Anyone can view active topics" ON public.topics;
CREATE POLICY "Anyone can view active topics" ON public.topics
    FOR SELECT USING (is_active = TRUE OR public.is_admin());

DROP POLICY IF EXISTS "Anyone can view active subscription plans" ON public.subscription_plans;
CREATE POLICY "Anyone can view active subscription plans" ON public.subscription_plans
    FOR SELECT USING (is_active = TRUE);

DROP POLICY IF EXISTS "Anyone can view active questions" ON public.questions;
CREATE POLICY "Anyone can view active questions" ON public.questions
    FOR SELECT USING (is_active = TRUE OR public.is_admin());

DROP POLICY IF EXISTS "Anyone can view question options" ON public.question_options;
CREATE POLICY "Anyone can view question options" ON public.question_options
    FOR SELECT USING (TRUE);

DROP POLICY IF EXISTS "Anyone can view published mock exams" ON public.mock_exams;
CREATE POLICY "Anyone can view published mock exams" ON public.mock_exams
    FOR SELECT USING (is_published = TRUE OR public.is_admin());

DROP POLICY IF EXISTS "Authenticated users can view mock exam questions" ON public.mock_exam_questions;
CREATE POLICY "Authenticated users can view mock exam questions" ON public.mock_exam_questions
    FOR SELECT USING (auth.role() = 'authenticated' OR public.is_admin());

-- Private Candidate Data Policies
DROP POLICY IF EXISTS "Users can read own subscriptions" ON public.user_subscriptions;
CREATE POLICY "Users can read own subscriptions" ON public.user_subscriptions
    FOR SELECT USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "Users can read own payment receipts" ON public.payments;
CREATE POLICY "Users can read own payment receipts" ON public.payments
    FOR SELECT USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "Users can view and manage own exam attempts" ON public.exam_attempts;
CREATE POLICY "Users can view and manage own exam attempts" ON public.exam_attempts
    FOR ALL USING (auth.uid() = user_id OR public.is_admin())
    WITH CHECK (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "Users can view and manage own exam responses" ON public.exam_responses;
CREATE POLICY "Users can view and manage own exam responses" ON public.exam_responses
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.exam_attempts
            WHERE exam_attempts.id = exam_responses.attempt_id
            AND (exam_attempts.user_id = auth.uid() OR public.is_admin())
        )
    );

DROP POLICY IF EXISTS "Users can view and manage own chapter progress" ON public.chapter_progress;
CREATE POLICY "Users can view and manage own chapter progress" ON public.chapter_progress
    FOR ALL USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can view and manage own bookmarks" ON public.bookmarks;
CREATE POLICY "Users can view and manage own bookmarks" ON public.bookmarks
    FOR ALL USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can file question reports" ON public.question_reports;
CREATE POLICY "Users can file question reports" ON public.question_reports
    FOR INSERT WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can view own reports, admins view all" ON public.question_reports;
CREATE POLICY "Users can view own reports, admins view all" ON public.question_reports
    FOR SELECT USING (auth.uid() = user_id OR public.is_admin());

-- Admin Permissions
DROP POLICY IF EXISTS "Admins full access on subjects" ON public.subjects;
CREATE POLICY "Admins full access on subjects" ON public.subjects FOR ALL USING (public.is_admin());

DROP POLICY IF EXISTS "Admins full access on chapters" ON public.chapters;
CREATE POLICY "Admins full access on chapters" ON public.chapters FOR ALL USING (public.is_admin());

DROP POLICY IF EXISTS "Admins full access on topics" ON public.topics;
CREATE POLICY "Admins full access on topics" ON public.topics FOR ALL USING (public.is_admin());

DROP POLICY IF EXISTS "Admins full access on questions" ON public.questions;
CREATE POLICY "Admins full access on questions" ON public.questions FOR ALL USING (public.is_admin());

DROP POLICY IF EXISTS "Admins full access on question_options" ON public.question_options;
CREATE POLICY "Admins full access on question_options" ON public.question_options FOR ALL USING (public.is_admin());

DROP POLICY IF EXISTS "Admins full access on mock_exams" ON public.mock_exams;
CREATE POLICY "Admins full access on mock_exams" ON public.mock_exams FOR ALL USING (public.is_admin());

DROP POLICY IF EXISTS "Admins full access on mock_exam_questions" ON public.mock_exam_questions;
CREATE POLICY "Admins full access on mock_exam_questions" ON public.mock_exam_questions FOR ALL USING (public.is_admin());

DROP POLICY IF EXISTS "Admins full access on question_reports" ON public.question_reports;
CREATE POLICY "Admins full access on question_reports" ON public.question_reports FOR ALL USING (public.is_admin());

-- ----------------------------------------------------------------------------
-- STEP 8: SEED DATA (Subscription Plans, DGCA Subjects, Chapters, Questions, Mocks)
-- ----------------------------------------------------------------------------

-- 1. Subscription Plans
INSERT INTO public.subscription_plans (code, name, price_inr, duration_months, description, is_active)
VALUES
('monthly', 'Monthly Preparation Pass', 300.00, 1, 'Full 1 calendar month access to all DGCA subject mock exams and chapter practice.', TRUE),
('six_month', 'Six-Month Complete Pilot Pass', 1500.00, 6, 'Full 6 calendar months uninterrupted access (Save ₹300 compared to monthly billing).', TRUE)
ON CONFLICT (code) DO UPDATE
SET price_inr = EXCLUDED.price_inr, description = EXCLUDED.description;

-- 2. DGCA Core Subjects
INSERT INTO public.subjects (id, name, code, slug, description, icon_name, display_order, is_active)
VALUES
('a0000001-0000-0000-0000-000000000001', 'Air Regulations', 'AIR-REG', 'air-regulations', 'Aircraft Act 1934, Aircraft Rules 1937, Civil Aviation Requirements (CAR), ICAO Annexes, Rules of the Air, Airspace classifications, and ATC procedures.', 'ShieldAlert', 1, TRUE),
('a0000001-0000-0000-0000-000000000002', 'Aviation Meteorology', 'AV-MET', 'aviation-meteorology', 'Atmospheric structure, pressure altimetry, temperature lapse rates, cloud classifications, fog, thunderstorms, jet streams, monsoon systems, METAR and TAF decoding.', 'CloudSun', 2, TRUE),
('a0000001-0000-0000-0000-000000000003', 'Air Navigation', 'AIR-NAV', 'air-navigation', 'Earth coordinates, great circles and rhumb lines, 1:60 rule calculations, triangle of velocities, dead reckoning, VOR, DME, ILS, GNSS, and Lambert conformal charts.', 'Compass', 3, TRUE),
('a0000001-0000-0000-0000-000000000004', 'Technical General', 'TECH-GEN', 'technical-general', 'Principles of flight, subsonic aerodynamics, flight controls, piston engines, gas turbine engines, aircraft systems, hydraulic, electrical buses, and instruments.', 'Gauge', 4, TRUE),
('a0000001-0000-0000-0000-000000000005', 'Technical Specific', 'TECH-SPEC', 'technical-specific', 'Aircraft flight manuals, operational limits, normal and emergency procedures, engine power curves, weight and balance for designated flight training aircraft.', 'Plane', 5, TRUE)
ON CONFLICT (code) DO NOTHING;

-- 3. Core Chapters
-- Meteorology
INSERT INTO public.chapters (id, subject_id, title, slug, chapter_number, revision_notes, display_order, is_active)
VALUES
('b0000001-0000-0000-0000-000000000001', 'a0000001-0000-0000-0000-000000000002', 'The Atmosphere & ISA Standards', 'the-atmosphere', 1, 'Standard ISA sea-level temperature is 15°C, pressure is 1013.25 hPa (29.92 inHg), and lapse rate is 1.98°C/1000ft up to 11km.', 1, TRUE),
('b0000001-0000-0000-0000-000000000002', 'a0000001-0000-0000-0000-000000000002', 'Atmospheric Pressure & Altimetry', 'pressure-and-altimetry', 2, 'Aviation memory rule: "High to low, look out below". 1 hPa corresponds to approx 27-30 feet in lower atmosphere.', 2, TRUE),
('b0000001-0000-0000-0000-000000000003', 'a0000001-0000-0000-0000-000000000002', 'Wind Systems & Jet Streams', 'wind-systems', 3, 'Geostrophic wind balance between pressure gradient and Coriolis force.', 3, TRUE)
ON CONFLICT (subject_id, slug) DO NOTHING;

-- Air Regulations
INSERT INTO public.chapters (id, subject_id, title, slug, chapter_number, revision_notes, display_order, is_active)
VALUES
('b0000001-0000-0000-0000-000000000010', 'a0000001-0000-0000-0000-000000000001', 'Aircraft Act 1934 & Rules 1937', 'aircraft-act-and-rules', 1, 'Covers statutory powers of DGCA, licensing requirements, logbook maintenance, and legal obligations.', 1, TRUE),
('b0000001-0000-0000-0000-000000000011', 'a0000001-0000-0000-0000-000000000001', 'Rules of the Air & Airspace', 'rules-of-the-air', 2, 'Right-of-way rules and Airspace classes A through G.', 2, TRUE)
ON CONFLICT (subject_id, slug) DO NOTHING;

-- Air Navigation
INSERT INTO public.chapters (id, subject_id, title, slug, chapter_number, revision_notes, display_order, is_active)
VALUES
('b0000001-0000-0000-0000-000000000020', 'a0000001-0000-0000-0000-000000000003', 'Earth Coordinates & Convergency', 'earth-coordinates', 1, '1 minute of latitude equals 1 nautical mile (6080 ft).', 1, TRUE),
('b0000001-0000-0000-0000-000000000021', 'a0000001-0000-0000-0000-000000000003', 'The 1:60 Rule & Triangle of Velocities', '1-60-rule', 2, 'Track error angle = (Distance off track / Distance flown) * 60.', 2, TRUE)
ON CONFLICT (subject_id, slug) DO NOTHING;

-- 4. Sample Practice Questions
INSERT INTO public.questions (id, chapter_id, question_text, explanation, difficulty, question_source, is_demo, is_active)
VALUES
('d0000001-0000-0000-0000-000000000001', 'b0000001-0000-0000-0000-000000000001',
'According to the ICAO Standard Atmosphere (ISA), what is the standard temperature lapse rate in the troposphere up to 11 km (approx. 36,000 ft)?',
'Under the ICAO Standard Atmosphere (ISA), temperature decreases at a uniform rate of approximately 1.98°C per 1,000 feet (approx. 2°C / 1,000 ft) from sea-level (15°C) up to the tropopause at 11,000 meters (-56.5°C).',
'easy', 'AeroPrep DGCA Practice Module', TRUE, TRUE),

('d0000001-0000-0000-0000-000000000002', 'b0000001-0000-0000-0000-000000000002',
'An aircraft flies from a region of high atmospheric pressure into a region of lower atmospheric pressure without resetting the subscale on its barometric altimeter. The altimeter will read:',
'When flying from high pressure to low pressure without resetting the subscale, the altimeter senses lower external air pressure and interprets it as an increase in altitude. Therefore, the altimeter will indicate a HIGHER altitude than actual true altitude ("High to low, look out below").',
'medium', 'AeroPrep DGCA Practice Module', TRUE, TRUE),

('d0000001-0000-0000-0000-000000000003', 'b0000001-0000-0000-0000-000000000021',
'An aircraft has flown 60 nautical miles and is found to be 3 nautical miles to the right of its planned track. What is the Track Error Angle (TEA)?',
'According to the 1:60 rule formula: Track Error Angle (degrees) = (Distance Off Track / Distance Flown) * 60. Here, TEA = (3 NM / 60 NM) * 60 = 3° Right.',
'easy', 'AeroPrep DGCA Practice Module', TRUE, TRUE),

('d0000001-0000-0000-0000-000000000004', 'b0000001-0000-0000-0000-000000000011',
'When two power-driven heavier-than-air aircraft are converging at approximately the same altitude, which aircraft has the right-of-way under ICAO Annex 2 / DGCA Rules of the Air?',
'Under ICAO Annex 2 (Rules of the Air) and DGCA Rule 68: When two aircraft are converging at approximately the same level, the aircraft that has the other on its right shall give way. Therefore, the aircraft on the right has the right-of-way.',
'medium', 'AeroPrep DGCA Practice Module', TRUE, TRUE)
ON CONFLICT (id) DO NOTHING;

-- Options for Question 1
INSERT INTO public.question_options (question_id, option_text, is_correct, display_order)
VALUES
('d0000001-0000-0000-0000-000000000001', '1.98°C per 1,000 feet (approx. 2°C / 1,000 ft)', TRUE, 1),
('d0000001-0000-0000-0000-000000000001', '3.00°C per 1,000 feet', FALSE, 2),
('d0000001-0000-0000-0000-000000000001', '0.50°C per 1,000 feet', FALSE, 3),
('d0000001-0000-0000-0000-000000000001', 'Isothermal (temperature remains constant)', FALSE, 4)
ON CONFLICT DO NOTHING;

-- Options for Question 2
INSERT INTO public.question_options (question_id, option_text, is_correct, display_order)
VALUES
('d0000001-0000-0000-0000-000000000002', 'Higher than the true altitude of the aircraft', TRUE, 1),
('d0000001-0000-0000-0000-000000000002', 'Lower than the true altitude of the aircraft', FALSE, 2),
('d0000001-0000-0000-0000-000000000002', 'Exactly equal to the true altitude', FALSE, 3),
('d0000001-0000-0000-0000-000000000002', 'Zero until re-calibrated by ATC', FALSE, 4)
ON CONFLICT DO NOTHING;

-- Options for Question 3
INSERT INTO public.question_options (question_id, option_text, is_correct, display_order)
VALUES
('d0000001-0000-0000-0000-000000000003', '3° Right', TRUE, 1),
('d0000001-0000-0000-0000-000000000003', '6° Right', FALSE, 2),
('d0000001-0000-0000-0000-000000000003', '1° Right', FALSE, 3),
('d0000001-0000-0000-0000-000000000003', '9° Right', FALSE, 4)
ON CONFLICT DO NOTHING;

-- Options for Question 4
INSERT INTO public.question_options (question_id, option_text, is_correct, display_order)
VALUES
('d0000001-0000-0000-0000-000000000004', 'The aircraft that has the other on its left (the aircraft on the right)', TRUE, 1),
('d0000001-0000-0000-0000-000000000004', 'The faster aircraft always has right-of-way', FALSE, 2),
('d0000001-0000-0000-0000-000000000004', 'The heavier commercial aircraft has right-of-way', FALSE, 3),
('d0000001-0000-0000-0000-000000000004', 'Both aircraft must immediately execute a left turn', FALSE, 4)
ON CONFLICT DO NOTHING;

-- 5. Sample Mock Exams
INSERT INTO public.mock_exams (id, subject_id, title, slug, description, duration_minutes, total_questions, passing_percentage, marks_per_question, negative_marking, is_premium, is_published)
VALUES
('e0000001-0000-0000-0000-000000000001', 'a0000001-0000-0000-0000-000000000002',
'Aviation Meteorology — Free Diagnostic Paper', 'av-met-diagnostic-sample',
'Sample diagnostic test covering the atmosphere, pressure altimetry, cloud types, and lapse rates.',
45, 25, 70.00, 1.00, 0.00, FALSE, TRUE),
('e0000001-0000-0000-0000-000000000002', 'a0000001-0000-0000-0000-000000000003',
'Air Navigation — CPL Full Standard Mock Exam', 'air-nav-cpl-full-mock',
'Comprehensive CPL standard mock examination simulating full DGCA CBT timing and question distribution.',
120, 70, 70.00, 1.00, 0.00, TRUE, TRUE)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO public.mock_exam_questions (mock_exam_id, question_id, question_order)
VALUES
('e0000001-0000-0000-0000-000000000001', 'd0000001-0000-0000-0000-000000000001', 1),
('e0000001-0000-0000-0000-000000000001', 'd0000001-0000-0000-0000-000000000002', 2)
ON CONFLICT DO NOTHING;

-- ============================================================================
-- SETUP COMPLETE
-- Your Supabase PostgreSQL database is now fully initialized for AeroPrep DGCA!
-- ============================================================================
