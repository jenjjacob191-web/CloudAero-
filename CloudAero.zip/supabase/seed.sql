-- ============================================================================
-- AeroPrep DGCA — Initial Syllabus & Practice Seed Data
-- ============================================================================

-- 1. SUBSCRIPTION PLANS
INSERT INTO public.subscription_plans (code, name, price_inr, duration_months, description, is_active)
VALUES
('monthly', 'Monthly Preparation Pass', 300.00, 1, 'Full 1 calendar month access to all DGCA subject mock exams and chapter practice.', TRUE),
('six_month', 'Six-Month Complete Pilot Pass', 1500.00, 6, 'Full 6 calendar months uninterrupted access (Save ₹300 compared to monthly billing).', TRUE)
ON CONFLICT (code) DO UPDATE
SET price_inr = EXCLUDED.price_inr, description = EXCLUDED.description;

-- 2. DGCA SUBJECTS
INSERT INTO public.subjects (id, name, code, slug, description, icon_name, display_order, is_active)
VALUES
('a0000001-0000-0000-0000-000000000001', 'Air Regulations', 'AIR-REG', 'air-regulations', 'Aircraft Act 1934, Aircraft Rules 1937, Civil Aviation Requirements (CAR), ICAO Annexes, Rules of the Air, Airspace classifications, and ATC procedures.', 'ShieldAlert', 1, TRUE),
('a0000001-0000-0000-0000-000000000002', 'Aviation Meteorology', 'AV-MET', 'aviation-meteorology', 'Atmospheric structure, pressure altimetry, temperature lapse rates, cloud classifications, fog, thunderstorms, jet streams, monsoon systems, METAR and TAF decoding.', 'CloudSun', 2, TRUE),
('a0000001-0000-0000-0000-000000000003', 'Air Navigation', 'AIR-NAV', 'air-navigation', 'Earth coordinates, great circles and rhumb lines, 1:60 rule calculations, triangle of velocities, dead reckoning, VOR, DME, ILS, GNSS, and Lambert conformal charts.', 'Compass', 3, TRUE),
('a0000001-0000-0000-0000-000000000004', 'Technical General', 'TECH-GEN', 'technical-general', 'Principles of flight, subsonic aerodynamics, flight controls, piston engines, gas turbine engines, aircraft systems, hydraulic, electrical buses, and instruments.', 'Gauge', 4, TRUE),
('a0000001-0000-0000-0000-000000000005', 'Technical Specific', 'TECH-SPEC', 'technical-specific', 'Aircraft flight manuals, operational limits, normal and emergency procedures, engine power curves, weight and balance for designated flight training aircraft.', 'Plane', 5, TRUE)
ON CONFLICT (code) DO NOTHING;

-- 3. CHAPTERS (Selected Core Chapters for Demonstration)
-- Aviation Meteorology Chapters
INSERT INTO public.chapters (id, subject_id, title, slug, chapter_number, revision_notes, display_order, is_active)
VALUES
('b0000001-0000-0000-0000-000000000001', 'a0000001-0000-0000-0000-000000000002', 'The Atmosphere & ISA Standards', 'the-atmosphere', 1, 'Standard ISA sea-level temperature is 15°C, pressure is 1013.25 hPa (29.92 inHg), and lapse rate is 1.98°C/1000ft (approx 2°C/1000ft) up to 11km (Tropopause).', 1, TRUE),
('b0000001-0000-0000-0000-000000000002', 'a0000001-0000-0000-0000-000000000002', 'Atmospheric Pressure & Altimetry', 'pressure-and-altimetry', 2, 'Remember the rule: "High to low, look out below" and "Cold to warm, look out for storm". 1 hPa corresponds to roughly 27 to 30 feet in the lower atmosphere.', 2, TRUE),
('b0000001-0000-0000-0000-000000000003', 'a0000001-0000-0000-0000-000000000002', 'Wind Systems & Jet Streams', 'wind-systems', 3, 'Geostrophic wind results from balance between pressure gradient force and Coriolis force. Jet streams occur along frontal discontinuities near the tropopause.', 3, TRUE)
ON CONFLICT (subject_id, slug) DO NOTHING;

-- Air Regulations Chapters
INSERT INTO public.chapters (id, subject_id, title, slug, chapter_number, revision_notes, display_order, is_active)
VALUES
('b0000001-0000-0000-0000-000000000010', 'a0000001-0000-0000-0000-000000000001', 'Aircraft Act 1934 & Rules 1937', 'aircraft-act-and-rules', 1, 'Covers statutory powers of DGCA, licensing requirements, logbook maintenance, and legal obligations of pilot-in-command.', 1, TRUE),
('b0000001-0000-0000-0000-000000000011', 'a0000001-0000-0000-0000-000000000001', 'Rules of the Air & Airspace', 'rules-of-the-air', 2, 'Right-of-way rules (aircraft on the right has right-of-way in converging paths, landing aircraft has priority over aircraft in flight). Airspace classes A through G.', 2, TRUE)
ON CONFLICT (subject_id, slug) DO NOTHING;

-- Air Navigation Chapters
INSERT INTO public.chapters (id, subject_id, title, slug, chapter_number, revision_notes, display_order, is_active)
VALUES
('b0000001-0000-0000-0000-000000000020', 'a0000001-0000-0000-0000-000000000003', 'Earth Coordinates & Convergency', 'earth-coordinates', 1, 'Latitude lines are parallels; Longitude lines are meridians. 1 minute of latitude equals 1 nautical mile (6080 ft).', 1, TRUE),
('b0000001-0000-0000-0000-000000000021', 'a0000001-0000-0000-0000-000000000003', 'The 1:60 Rule & Triangle of Velocities', '1-60-rule', 2, 'Track error angle = (Distance off track / Distance flown) * 60. Closing angle = (Distance off track / Distance to go) * 60.', 2, TRUE)
ON CONFLICT (subject_id, slug) DO NOTHING;

-- 4. TOPICS
INSERT INTO public.topics (id, chapter_id, title, slug, display_order)
VALUES
('c0000001-0000-0000-0000-000000000001', 'b0000001-0000-0000-0000-000000000001', 'Troposphere & Tropopause Characteristics', 'troposphere-characteristics', 1),
('c0000001-0000-0000-0000-000000000002', 'b0000001-0000-0000-0000-000000000001', 'ICAO Standard Atmosphere (ISA) Constants', 'isa-constants', 2),
('c0000001-0000-0000-0000-000000000003', 'b0000001-0000-0000-0000-000000000002', 'Altimeter Setting (QNH, QFE, Standard 1013)', 'altimeter-settings', 1)
ON CONFLICT (chapter_id, slug) DO NOTHING;

-- 5. DEMO QUESTIONS & MULTIPLE CHOICE OPTIONS
-- Question 1: Meteorology - ISA Temperature Lapse Rate
INSERT INTO public.questions (id, chapter_id, question_text, explanation, difficulty, question_source, is_demo, is_active)
VALUES
('d0000001-0000-0000-0000-000000000001', 'b0000001-0000-0000-0000-000000000001',
'According to the ICAO Standard Atmosphere (ISA), what is the standard temperature lapse rate in the troposphere up to 11 km (approx. 36,000 ft)?',
'Under the ICAO Standard Atmosphere (ISA), temperature decreases at a uniform rate of approximately 1.98°C per 1,000 feet (often rounded to 2°C / 1,000 ft or 0.65°C per 100 meters) from sea-level (15°C) up to the tropopause at 11,000 meters (-56.5°C), above which temperature remains isothermal.',
'easy', 'AeroPrep DGCA Practice Module (Demo)', TRUE, TRUE)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.question_options (question_id, option_text, is_correct, display_order)
VALUES
('d0000001-0000-0000-0000-000000000001', '1.98°C per 1,000 feet (approx. 2°C / 1,000 ft)', TRUE, 1),
('d0000001-0000-0000-0000-000000000001', '3.00°C per 1,000 feet', FALSE, 2),
('d0000001-0000-0000-0000-000000000001', '0.50°C per 1,000 feet', FALSE, 3),
('d0000001-0000-0000-0000-000000000001', 'Isothermal (temperature remains constant)', FALSE, 4)
ON CONFLICT DO NOTHING;

-- Question 2: Meteorology - Altimeter Setting Rule
INSERT INTO public.questions (id, chapter_id, question_text, explanation, difficulty, question_source, is_demo, is_active)
VALUES
('d0000001-0000-0000-0000-000000000002', 'b0000001-0000-0000-0000-000000000002',
'An aircraft flies from a region of high atmospheric pressure into a region of lower atmospheric pressure without resetting the subscale on its barometric altimeter. The altimeter will read:',
'When flying from high pressure to low pressure without resetting the subscale, the altimeter senses lower external air pressure and interprets it as an increase in altitude. Therefore, the altimeter will indicate a HIGHER altitude than the aircraft is actually flying (i.e. True Altitude is lower than Indicated Altitude). Aviation memory aid: "High to low, look out below."',
'medium', 'AeroPrep DGCA Practice Module (Demo)', TRUE, TRUE)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.question_options (question_id, option_text, is_correct, display_order)
VALUES
('d0000001-0000-0000-0000-000000000002', 'Higher than the true altitude of the aircraft', TRUE, 1),
('d0000001-0000-0000-0000-000000000002', 'Lower than the true altitude of the aircraft', FALSE, 2),
('d0000001-0000-0000-0000-000000000002', 'Exactly equal to the true altitude', FALSE, 3),
('d0000001-0000-0000-0000-000000000002', 'Zero until re-calibrated by ATC', FALSE, 4)
ON CONFLICT DO NOTHING;

-- Question 3: Air Navigation - 1:60 Rule Calculation
INSERT INTO public.questions (id, chapter_id, question_text, explanation, difficulty, question_source, is_demo, is_active)
VALUES
('d0000001-0000-0000-0000-000000000003', 'b0000001-0000-0000-0000-000000000021',
'An aircraft has flown 60 nautical miles and is found to be 3 nautical miles to the right of its planned track. What is the Track Error Angle (TEA)?',
'According to the 1:60 rule formula: Track Error Angle (degrees) = (Distance Off Track / Distance Flown) * 60. Here, TEA = (3 NM / 60 NM) * 60 = 3° Right. To parallel the track, alter heading 3° left; to intercept destination, also compute the closing angle.',
'easy', 'AeroPrep DGCA Practice Module (Demo)', TRUE, TRUE)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.question_options (question_id, option_text, is_correct, display_order)
VALUES
('d0000001-0000-0000-0000-000000000003', '3° Right', TRUE, 1),
('d0000001-0000-0000-0000-000000000003', '6° Right', FALSE, 2),
('d0000001-0000-0000-0000-000000000003', '1° Right', FALSE, 3),
('d0000001-0000-0000-0000-000000000003', '9° Right', FALSE, 4)
ON CONFLICT DO NOTHING;

-- Question 4: Air Regulations - Right of Way
INSERT INTO public.questions (id, chapter_id, question_text, explanation, difficulty, question_source, is_demo, is_active)
VALUES
('d0000001-0000-0000-0000-000000000004', 'b0000001-0000-0000-0000-000000000011',
'When two power-driven heavier-than-air aircraft are converging at approximately the same altitude, which aircraft has the right-of-way under ICAO Annex 2 / DGCA Rules of the Air?',
'Under ICAO Annex 2 (Rules of the Air) and DGCA Rule 68: When two aircraft are converging at approximately the same level, the aircraft that has the other on its right shall give way. Therefore, the aircraft on the right has the right-of-way.',
'medium', 'AeroPrep DGCA Practice Module (Demo)', TRUE, TRUE)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.question_options (question_id, option_text, is_correct, display_order)
VALUES
('d0000001-0000-0000-0000-000000000004', 'The aircraft that has the other on its left (the aircraft on the right)', TRUE, 1),
('d0000001-0000-0000-0000-000000000004', 'The faster aircraft always has right-of-way', FALSE, 2),
('d0000001-0000-0000-0000-000000000004', 'The heavier commercial aircraft has right-of-way', FALSE, 3),
('d0000001-0000-0000-0000-000000000004', 'Both aircraft must immediately execute a left turn', FALSE, 4)
ON CONFLICT DO NOTHING;

-- 6. SAMPLE MOCK EXAMINATIONS
INSERT INTO public.mock_exams (id, subject_id, title, slug, description, duration_minutes, total_questions, passing_percentage, marks_per_question, negative_marking, is_premium, is_published)
VALUES
('e0000001-0000-0000-0000-000000000001', 'a0000001-0000-0000-0000-000000000002',
'Aviation Meteorology — Free Diagnostic Paper', 'av-met-diagnostic-sample',
'Sample diagnostic test covering the atmosphere, pressure altimetry, cloud types, and lapse rates. Free for all registered candidates.',
45, 25, 70.00, 1.00, 0.00, FALSE, TRUE),
('e0000001-0000-0000-0000-000000000002', 'a0000001-0000-0000-0000-000000000003',
'Air Navigation — CPL Full Standard Mock Exam', 'air-nav-cpl-full-mock',
'Comprehensive 70-question CPL standard mock examination simulating full DGCA CBT timing and question distribution.',
120, 70, 70.00, 1.00, 0.00, TRUE, TRUE)
ON CONFLICT (slug) DO NOTHING;

-- Link questions to the sample mock exam
INSERT INTO public.mock_exam_questions (mock_exam_id, question_id, question_order)
VALUES
('e0000001-0000-0000-0000-000000000001', 'd0000001-0000-0000-0000-000000000001', 1),
('e0000001-0000-0000-0000-000000000001', 'd0000001-0000-0000-0000-000000000002', 2)
ON CONFLICT DO NOTHING;
