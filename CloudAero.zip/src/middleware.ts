import { NextRequest, NextResponse } from "next/server";

// ==============================================================================
// CloudAero Edge Web Application Firewall (WAF) & Rate Limiter Middleware
// ==============================================================================

// In-memory sliding window rate limiter
interface RateLimitRecord {
  count: number;
  resetAt: number;
}

const rateLimitMap = new Map<string, RateLimitRecord>();

// Clean up expired rate limit entries every 60 seconds
let lastCleanup = Date.now();
function cleanupRateLimitMap() {
  const now = Date.now();
  if (now - lastCleanup > 60000) {
    lastCleanup = now;
    rateLimitMap.forEach((val, key) => {
      if (val.resetAt < now) {
        rateLimitMap.delete(key);
      }
    });
  }
}

// Known malicious user-agent signatures and automated vulnerability scanners
const MALICIOUS_USER_AGENTS = [
  "sqlmap",
  "nikto",
  "masscan",
  "wpscan",
  "dirbuster",
  "gobuster",
  "acunetix",
  "havij",
  "zaproxy",
  "burpcollaborator",
  "python-requests/2.1",
  "scrapy",
  "curl/7.2",
];

// Suspicious patterns: Path Traversal, SQL Injection, Remote Code Execution
const SUSPICIOUS_PATH_PATTERNS = [
  /\.\./,                  // Path traversal: ..
  /%2e%2e/i,              // URL-encoded path traversal
  /\/\.env/i,             // Environment secrets probe
  /\/\.git/i,             // Git repository probe
  /\/wp-admin/i,          // WordPress probe on non-WP stack
  /\/wp-login/i,
  /\/phpinfo/i,           // PHP probe on Next.js stack
  /\/xmlrpc\.php/i,
  /\/etc\/passwd/i,       // Unix password file probe
  /\/win\.ini/i,          // Windows ini probe
  /<script>/i,            // Reflected XSS attempt
  /union\s+select/i,      // SQLi attempt
  /;\s*drop\s+table/i,    // SQLi attempt
  /eval\s*\(/i,           // Arbitrary code execution
  /javascript:/i,         // JavaScript URI scheme injection
];

export async function middleware(req: NextRequest) {
  const { pathname, search } = req.nextUrl;
  const method = req.method.toUpperCase();

  // 1. Extract real client IP behind Cloudflare or proxy
  const clientIp =
    req.headers.get("cf-connecting-ip") ||
    req.headers.get("x-real-ip") ||
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    "127.0.0.1";

  const userAgent = (req.headers.get("user-agent") || "").toLowerCase();

  // 2. WAF Rule 1: Block known automated attack scanners
  for (const scanner of MALICIOUS_USER_AGENTS) {
    if (userAgent.includes(scanner)) {
      console.warn(`[WAF Block] Malicious User-Agent detected: ${scanner} from ${clientIp}`);
      return new NextResponse(
        JSON.stringify({ error: "Access Denied by CloudAero Edge Firewall: Automated scanner blocked." }),
        { status: 403, headers: { "Content-Type": "application/json", "X-Firewall-Status": "BLOCKED" } }
      );
    }
  }

  // 3. WAF Rule 2: Inspect Path and Query parameters for injection and traversal
  const fullUrlDecoded = decodeURIComponent(pathname + search);
  for (const pattern of SUSPICIOUS_PATH_PATTERNS) {
    if (pattern.test(fullUrlDecoded)) {
      console.warn(`[WAF Block] Suspicious payload detected (${pattern}) on path: ${pathname} from ${clientIp}`);
      return new NextResponse(
        JSON.stringify({ error: "Access Denied by CloudAero Edge Firewall: Suspicious payload or traversal pattern detected." }),
        { status: 400, headers: { "Content-Type": "application/json", "X-Firewall-Status": "BLOCKED" } }
      );
    }
  }

  // 4. WAF Rule 3: Sliding Window Rate Limiting
  cleanupRateLimitMap();
  const now = Date.now();
  const windowMs = 60 * 1000; // 1-minute window

  // Determine rate limit thresholds based on route sensitivity
  let maxRequests = 120; // Default: 120 requests/minute
  if (pathname.startsWith("/api/auth/") || pathname.startsWith("/api/payments/")) {
    maxRequests = 25; // Strict: 25 requests/minute on payment and auth endpoints to prevent brute-force
  } else if (pathname.startsWith("/api/")) {
    maxRequests = 80; // Moderate: 80 requests/minute on general API
  }

  const rateLimitKey = `${clientIp}:${pathname.startsWith("/api/auth/") || pathname.startsWith("/api/payments/") ? "auth_pay" : "gen"}`;
  const record = rateLimitMap.get(rateLimitKey);

  if (!record || record.resetAt < now) {
    rateLimitMap.set(rateLimitKey, { count: 1, resetAt: now + windowMs });
  } else {
    record.count++;
    if (record.count > maxRequests) {
      console.warn(`[WAF Rate Limit] IP ${clientIp} exceeded limit (${record.count}/${maxRequests}) on ${pathname}`);
      return new NextResponse(
        JSON.stringify({
          error: "Too many requests. Please slow down your request rate to protect system availability.",
          retryAfterSeconds: Math.ceil((record.resetAt - now) / 1000),
        }),
        {
          status: 429,
          headers: {
            "Content-Type": "application/json",
            "Retry-After": Math.ceil((record.resetAt - now) / 1000).toString(),
            "X-Firewall-Status": "RATE_LIMITED",
          },
        }
      );
    }
  }

  // 5. WAF Rule 4: CSRF & Origin Validation for sensitive API mutations
  if (pathname.startsWith("/api/") && ["POST", "PUT", "DELETE", "PATCH"].includes(method)) {
    const origin = req.headers.get("origin");
    const host = req.headers.get("host");

    if (origin && host) {
      try {
        const originUrl = new URL(origin);
        // Allow origin if hostname matches current host, or is trycloudflare, vercel, or localhost
        const isAllowedOrigin =
          originUrl.host === host ||
          originUrl.hostname.endsWith("trycloudflare.com") ||
          originUrl.hostname.endsWith("vercel.app") ||
          originUrl.hostname === "localhost" ||
          originUrl.hostname === "127.0.0.1";

        if (!isAllowedOrigin) {
          console.warn(`[WAF Block] Cross-Origin mutation blocked from untrusted origin: ${origin} against host: ${host}`);
          return new NextResponse(
            JSON.stringify({ error: "Cross-Origin request blocked by CloudAero Security Firewall." }),
            { status: 403, headers: { "Content-Type": "application/json", "X-Firewall-Status": "BLOCKED" } }
          );
        }
      } catch {
        // Badly formatted origin header
        return new NextResponse(
          JSON.stringify({ error: "Malformed origin header." }),
          { status: 400, headers: { "Content-Type": "application/json" } }
        );
      }
    }
  }

  // 6. Request passes all WAF rules: Append firewall pass headers & proceed
  const response = NextResponse.next();
  response.headers.set("X-Firewall-Status", "PASS");
  response.headers.set("X-Content-Type-Options", "nosniff");
  response.headers.set("X-Frame-Options", "SAMEORIGIN");

  return response;
}

// Specify matcher to run firewall on all pages and API endpoints (excluding Next.js internal static assets)
export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - images/* (public images)
     */
    "/((?!_next/static|_next/image|favicon.ico|images/).*)",
  ],
};
