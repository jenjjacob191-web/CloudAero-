"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";

interface ReportedIssue {
  id: string;
  source?: "contact_form" | "question_dispute";
  ticketCode?: string;
  questionId?: string;
  questionCode?: string;
  subject: string;
  chapter?: string;
  questionText?: string;
  currentAnswer?: string;
  reporterName: string;
  reporterLicense?: string;
  reporterEmail: string;
  category?: string;
  reportType?: string;
  description: string;
  status: "pending" | "resolved" | "dismissed";
  createdAt: string;
  resolvedAt?: string;
  adminNotes?: string;
}

export default function AdminReportsPage() {
  const [reports, setReports] = useState<ReportedIssue[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedReport, setSelectedReport] = useState<ReportedIssue | null>(null);
  const [actionNotes, setActionNotes] = useState("");
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const loadTickets = async () => {
    try {
      setIsLoading(true);
      const res = await fetch("/api/support/tickets");
      if (res.ok) {
        const data = await res.json();
        if (data.tickets) {
          setReports(data.tickets);
        }
      }
    } catch (e) {
      console.warn("Could not load support tickets:", e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadTickets();
  }, []);

  const filteredReports = reports.filter((r) => {
    const matchStatus = filterStatus === "all" || r.status === filterStatus;
    const cat = r.category || r.reportType || "general";
    const matchCat = filterCategory === "all" || cat === filterCategory;
    const q = searchQuery.toLowerCase();
    const matchSearch =
      !searchQuery ||
      (r.questionText && r.questionText.toLowerCase().includes(q)) ||
      (r.description && r.description.toLowerCase().includes(q)) ||
      (r.reporterName && r.reporterName.toLowerCase().includes(q)) ||
      (r.reporterEmail && r.reporterEmail.toLowerCase().includes(q)) ||
      (r.ticketCode && r.ticketCode.toLowerCase().includes(q)) ||
      (r.questionCode && r.questionCode.toLowerCase().includes(q)) ||
      (r.subject && r.subject.toLowerCase().includes(q));
    return matchStatus && matchCat && matchSearch;
  });

  const pendingCount = reports.filter((r) => r.status === "pending").length;
  const resolvedCount = reports.filter((r) => r.status === "resolved").length;
  const dismissedCount = reports.filter((r) => r.status === "dismissed").length;

  const handleUpdateStatus = async (
    id: string,
    newStatus: "pending" | "resolved" | "dismissed",
    notes?: string
  ) => {
    const defaultNote =
      newStatus === "resolved"
        ? "Resolved by Administrator."
        : newStatus === "dismissed"
        ? "Dismissed by Administrator."
        : "Reopened by Administrator.";
    const finalNotes = notes || defaultNote;

    try {
      await fetch("/api/support/tickets", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id,
          status: newStatus,
          adminNotes: finalNotes,
        }),
      });
    } catch (e) {
      console.warn("Failed to update status on server:", e);
    }

    setReports((prev) =>
      prev.map((r) =>
        r.id === id
          ? {
              ...r,
              status: newStatus,
              resolvedAt: new Date().toLocaleString(),
              adminNotes: finalNotes,
            }
          : r
      )
    );
    setSelectedReport(null);
    setActionNotes("");
    showToast(`Ticket marked as ${newStatus.toUpperCase()}`);
  };

  const handleDeleteTicket = async (id: string, code?: string) => {
    if (!window.confirm(`Are you sure you want to permanently delete ticket ${code || id}?`)) {
      return;
    }
    try {
      const res = await fetch("/api/support/tickets", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      if (res.ok) {
        setReports((prev) => prev.filter((r) => r.id !== id));
        if (selectedReport?.id === id) setSelectedReport(null);
        showToast("Ticket deleted permanently.");
      }
    } catch (e) {
      console.warn("Failed to delete ticket:", e);
    }
  };

  const handleClearAll = async () => {
    if (
      !window.confirm(
        "Are you sure you want to delete ALL tickets? This will permanently remove all tickets from the database."
      )
    ) {
      return;
    }
    try {
      const res = await fetch("/api/support/tickets", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clearAll: true }),
      });
      if (res.ok) {
        setReports([]);
        setSelectedReport(null);
        showToast("All tickets cleared.");
      }
    } catch (e) {
      console.warn("Failed to clear tickets:", e);
    }
  };

  const getBadgeForCategory = (cat?: string) => {
    switch (cat) {
      case "billing":
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">💳 Billing / Payment</span>;
      case "exam_dispute":
      case "incorrect_answer":
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">🚩 Question Dispute</span>;
      case "syllabus":
      case "outdated_regulation":
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">📚 Syllabus Inquiry</span>;
      case "technical":
      case "typo":
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200">⚙️ Technical Support</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200">✉️ General Inquiry</span>;
    }
  };

  const getStatusBadge = (status: ReportedIssue["status"]) => {
    switch (status) {
      case "pending":
        return <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-300 flex items-center space-x-1"><span>⚠️</span><span>Pending Review</span></span>;
      case "resolved":
        return <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center space-x-1"><span>✅</span><span>Resolved</span></span>;
      case "dismissed":
        return <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700 border border-slate-300 flex items-center space-x-1"><span>✖️</span><span>Dismissed</span></span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 bg-aviation-950 text-white px-5 py-3 rounded-xl shadow-2xl border border-skyAccent-500/40 text-xs font-semibold flex items-center space-x-2 animate-bounce">
          <span>✈️</span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-aviation-950 flex items-center space-x-2">
            <span>🚩</span>
            <span>Support Tickets &amp; Candidate Disputes</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Live tickets submitted by registered candidates and student pilots. Demo / AI mock tickets have been purged.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {reports.length > 0 && (
            <button
              onClick={handleClearAll}
              className="px-3 py-2 rounded-xl text-xs font-semibold bg-rose-50 border border-rose-200 text-rose-700 hover:bg-rose-100 transition-colors flex items-center space-x-1.5 shadow-xs"
              title="Permanently remove all tickets"
            >
              <span>🗑️</span>
              <span>Clear All</span>
            </button>
          )}
          <button
            onClick={loadTickets}
            className="px-3 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors flex items-center space-x-1.5 shadow-xs"
          >
            <span>🔄</span>
            <span>Refresh</span>
          </button>
          <Link
            href="/admin/questions"
            className="px-3.5 py-2 rounded-xl text-xs font-bold bg-aviation-900 text-white hover:bg-aviation-800 shadow-sm transition-colors flex items-center space-x-1.5"
          >
            <span>📝</span>
            <span>Question Bank</span>
          </Link>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Total Live Tickets</div>
          <div className="text-2xl font-black text-aviation-950 mt-1">{reports.length}</div>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-amber-200 shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-amber-600">Pending Review</div>
          <div className="text-2xl font-black text-amber-700 mt-1">{pendingCount}</div>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-emerald-200 shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-600">Resolved</div>
          <div className="text-2xl font-black text-emerald-700 mt-1">{resolvedCount}</div>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Dismissed</div>
          <div className="text-2xl font-black text-slate-700 mt-1">{dismissedCount}</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
        <div className="w-full md:w-80">
          <input
            type="text"
            placeholder="Search by ticket code, student, email, or keyword..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-skyAccent-500"
          />
        </div>

        <div className="flex items-center space-x-2 w-full md:w-auto">
          {/* Status filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 bg-white font-semibold text-slate-700 focus:outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="pending">⚠️ Pending Review ({pendingCount})</option>
            <option value="resolved">✅ Resolved ({resolvedCount})</option>
            <option value="dismissed">✖️ Dismissed ({dismissedCount})</option>
          </select>

          {/* Category filter */}
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 bg-white font-semibold text-slate-700 focus:outline-none"
          >
            <option value="all">All Categories</option>
            <option value="billing">Billing &amp; Payments</option>
            <option value="exam_dispute">Question Disputes</option>
            <option value="syllabus">Syllabus &amp; Regulations</option>
            <option value="technical">Technical Support</option>
            <option value="general">General Inquiries</option>
          </select>
        </div>
      </div>

      {/* Reports & Tickets List */}
      <div className="space-y-3">
        {isLoading ? (
          <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center animate-pulse">
            <div className="text-sm font-bold text-slate-500">Loading support tickets...</div>
          </div>
        ) : filteredReports.length === 0 ? (
          <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center max-w-lg mx-auto">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-sky-50 flex items-center justify-center text-3xl text-sky-600 border border-sky-100">
              📬
            </div>
            <h3 className="text-base font-bold text-aviation-950">No Tickets Found</h3>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              All AI / demo tickets have been completely removed. Only real tickets submitted by actual users via the Contact Support form or Question Disputes will be displayed here.
            </p>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <Link
                href="/contact"
                target="_blank"
                className="px-4 py-2 rounded-xl text-xs font-bold bg-aviation-900 text-white hover:bg-aviation-800 transition-all shadow-xs"
              >
                Open Student Contact Form ↗
              </Link>
              <button
                onClick={loadTickets}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 transition-all"
              >
                🔄 Refresh Desk
              </button>
            </div>
          </div>
        ) : (
          filteredReports.map((report) => (
            <div
              key={report.id}
              className={`bg-white rounded-2xl border transition-all p-5 ${
                report.status === "pending"
                  ? "border-amber-200 hover:border-amber-300 shadow-xs"
                  : "border-slate-200 hover:border-slate-300"
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="space-y-2.5 flex-grow">
                  {/* Tags & Metadata */}
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-[11px] font-bold text-aviation-900 bg-aviation-50 px-2 py-0.5 rounded border border-aviation-200">
                      {report.ticketCode || report.questionCode || report.id}
                    </span>
                    <span className="text-[11px] font-semibold text-slate-700">
                      {report.subject}
                    </span>
                    {getBadgeForCategory(report.category || report.reportType)}
                    {getStatusBadge(report.status)}
                  </div>

                  {/* Question preview if attached */}
                  {report.questionText && (
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-800">
                      <span className="font-bold text-aviation-950 block mb-1">
                        Question Reference {report.questionCode ? `(${report.questionCode})` : ""}:
                      </span>
                      <p className="italic">{report.questionText}</p>
                      {report.currentAnswer && (
                        <div className="mt-1.5 text-[11px] text-slate-600">
                          <span className="font-semibold text-emerald-800">Current Key:</span> {report.currentAnswer}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Candidate description / message */}
                  <div className="text-xs bg-slate-50/70 p-3.5 rounded-xl border border-slate-200">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-bold text-slate-900 flex items-center space-x-1.5">
                        <span>👤</span>
                        <span>
                          {report.reporterName}{" "}
                          {report.reporterLicense ? `• ${report.reporterLicense}` : ""}{" "}
                          <span className="font-normal text-slate-500 font-mono">({report.reporterEmail})</span>
                        </span>
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">{report.createdAt}</span>
                    </div>
                    <p className="text-slate-700 leading-relaxed font-sans">{report.description}</p>
                  </div>

                  {/* Admin notes if resolved/dismissed */}
                  {report.adminNotes && (
                    <div className="text-[11px] bg-emerald-50/60 p-2.5 rounded-lg border border-emerald-200 text-emerald-900 flex items-start space-x-2">
                      <span className="font-bold">Admin Resolution:</span>
                      <span>{report.adminNotes} {report.resolvedAt ? `(at ${report.resolvedAt})` : ""}</span>
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex-shrink-0 flex md:flex-col items-center md:items-end gap-2">
                  {report.status === "pending" ? (
                    <>
                      <button
                        onClick={() => setSelectedReport(report)}
                        className="w-full md:w-36 py-2 px-3 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-colors flex items-center justify-center space-x-1"
                      >
                        <span>✅</span>
                        <span>Take Action</span>
                      </button>
                      <button
                        onClick={() => handleUpdateStatus(report.id, "dismissed", "Dismissed by Administrator.")}
                        className="w-full md:w-36 py-2 px-3 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-colors flex items-center justify-center space-x-1"
                      >
                        <span>✖️</span>
                        <span>Dismiss</span>
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => handleUpdateStatus(report.id, "pending", "")}
                      className="text-[11px] font-semibold text-sky-700 hover:text-sky-900 underline"
                    >
                      Reopen Ticket
                    </button>
                  )}
                  <button
                    onClick={() => handleDeleteTicket(report.id, report.ticketCode)}
                    className="w-full md:w-36 py-1.5 px-3 rounded-xl text-[11px] font-semibold text-rose-600 hover:text-rose-800 hover:bg-rose-50 border border-rose-200 transition-colors flex items-center justify-center space-x-1"
                    title="Permanently delete ticket"
                  >
                    <span>🗑️</span>
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Action Resolution Modal */}
      {selectedReport && (
        <div className="fixed inset-0 z-50 bg-aviation-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-aviation-950 text-base flex items-center space-x-2">
                <span>🛠️</span>
                <span>Resolve Ticket {selectedReport.ticketCode || selectedReport.id}</span>
              </h3>
              <button
                onClick={() => setSelectedReport(null)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="text-xs space-y-2">
              <p className="text-slate-600 font-medium">
                Candidate <span className="font-bold text-slate-900">{selectedReport.reporterName}</span> ({selectedReport.reporterEmail}):
              </p>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs leading-relaxed font-sans">
                "{selectedReport.description}"
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-aviation-950 mb-1">
                Resolution Note / Action Taken:
              </label>
              <textarea
                rows={3}
                placeholder="E.g. Sent GST invoice to student email, verified question against CAR Section 7, updated explanation..."
                value={actionNotes}
                onChange={(e) => setActionNotes(e.target.value)}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-skyAccent-500 font-sans"
              />
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2">
              <button
                onClick={() => setSelectedReport(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleUpdateStatus(selectedReport.id, "dismissed", actionNotes || "Dismissed: Inquiry reviewed.")}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors border border-slate-200"
              >
                Dismiss
              </button>
              <button
                onClick={() => handleUpdateStatus(selectedReport.id, "resolved", actionNotes || "Resolved and verified by Chief Ground Instructor.")}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white transition-colors"
              >
                Confirm &amp; Mark Resolved
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
