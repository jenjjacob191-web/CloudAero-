"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth-context";

interface StudentRecord {
  id: string;
  name: string;
  email: string;
  role?: string;
  is_premium?: boolean;
  joined: string;
  plan: string;
  starts: string;
  expires: string;
  status: string;
  daysLeft: number;
}

export default function AdminStudentsPage() {
  const { user, profile } = useAuth();
  const [searchStudent, setSearchStudent] = useState("");
  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const loadStudents = async () => {
    try {
      setIsLoading(true);
      const adminEmail = user?.email || profile?.email || "admin@cloudaero.in";
      const res = await fetch("/api/admin/students", {
        headers: { "x-admin-email": adminEmail },
      });
      if (res.ok) {
        const data = await res.json();
        if (data.students) {
          setStudents(data.students);
        }
      }
    } catch (e) {
      console.warn("Could not load registered students:", e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadStudents();
  }, []);

  const handleTogglePremium = async (s: StudentRecord) => {
    try {
      setActionLoadingId(s.id);
      const targetState = !s.is_premium;
      const adminEmail = user?.email || profile?.email || "admin@cloudaero.in";
      const res = await fetch("/api/admin/students/toggle-premium", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-email": adminEmail,
        },
        body: JSON.stringify({
          userId: s.id,
          email: s.email,
          isPremium: targetState,
        }),
      });

      if (res.ok) {
        setStudents((prev) =>
          prev.map((item) =>
            item.id === s.id
              ? {
                  ...item,
                  is_premium: targetState,
                  status: targetState ? "Active" : "Free Cadet",
                  plan: targetState ? "Cadet Premium Pass (Supabase)" : "Free Pilot Account",
                  daysLeft: targetState ? 365 : 0,
                  expires: targetState ? "Active" : "-",
                }
              : item
          )
        );
        setToastMessage(`✓ Premium access ${targetState ? "granted" : "revoked"} in Supabase for ${s.name}!`);
        setTimeout(() => setToastMessage(null), 4000);
      } else {
        const err = await res.json();
        alert(`Failed to update premium access: ${err.error || "Unknown error"}`);
      }
    } catch (err: unknown) {
      alert(`Network error: ${err instanceof Error ? err.message : "Failed to update"}`);
    } finally {
      setActionLoadingId(null);
    }
  };

  const filtered = students.filter(
    (s) =>
      s.name.toLowerCase().includes(searchStudent.toLowerCase()) ||
      s.email.toLowerCase().includes(searchStudent.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="bg-emerald-50 border border-emerald-300 text-emerald-800 px-5 py-3.5 rounded-2xl text-xs font-bold shadow-md flex items-center justify-between animate-fadeIn">
          <div className="flex items-center space-x-2">
            <span>⭐</span>
            <span>{toastMessage}</span>
          </div>
          <button
            onClick={() => setToastMessage(null)}
            className="text-emerald-700 hover:text-emerald-900 font-bold"
          >
            ✕
          </button>
        </div>
      )}

      {/* Header */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-aviation-900 tracking-tight flex items-center space-x-2">
            <span>👨‍✈️</span>
            <span>Registered Student Pilots &amp; Subscriptions</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Real registered student profiles from Supabase. You can enable or revoke Premium CBT access directly using the buttons below or in the Supabase Table Editor.
          </p>
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <div className="relative flex-grow sm:w-72">
            <input
              type="text"
              value={searchStudent}
              onChange={(e) => setSearchStudent(e.target.value)}
              placeholder="Search candidates by name or email..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-aviation-800"
            />
            <svg
              className="w-4 h-4 text-slate-400 absolute left-3 top-3"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
          </div>
          <button
            onClick={loadStudents}
            className="px-3 py-2.5 rounded-xl text-xs font-semibold bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors shadow-xs"
            title="Refresh student list"
          >
            🔄
          </button>
        </div>
      </div>

      {/* Supabase SQL Instructions Info Card */}
      <div className="bg-sky-50/70 border border-sky-200 rounded-2xl p-5 text-xs text-slate-700">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2 text-sky-950 font-bold">
            <span>⚡</span>
            <span>How to Enable Premium Access via Supabase Directly:</span>
          </div>
          <span className="text-[10px] font-mono text-sky-700 bg-sky-100 px-2 py-0.5 rounded font-bold">
            Supabase SQL / Table Editor
          </span>
        </div>
        <p className="text-slate-600 leading-relaxed mb-3">
          Every candidate has an <code className="bg-sky-100 px-1 py-0.5 rounded text-sky-900 font-mono">is_premium</code> column in the Supabase <code className="bg-sky-100 px-1 py-0.5 rounded text-sky-900 font-mono">profiles</code> table. You can toggle it directly in the Supabase Table Editor, use the quick buttons below, or run the SQL command:
        </p>
        <div className="bg-aviation-950 text-sky-300 p-3 rounded-xl font-mono text-[11px] overflow-x-auto select-all">
          UPDATE public.profiles SET is_premium = TRUE WHERE email = &apos;candidate@gmail.com&apos;;
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 uppercase font-semibold">
                <th className="pb-3">Candidate</th>
                <th className="pb-3">Registered Date</th>
                <th className="pb-3">Subscription Tier</th>
                <th className="pb-3">Start Date</th>
                <th className="pb-3">Expiry Date</th>
                <th className="pb-3">Validity</th>
                <th className="pb-3 text-center">Status</th>
                <th className="pb-3 text-right">Supabase Premium Control</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {isLoading ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400 text-xs animate-pulse">
                    Connecting to Supabase and loading student roster...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400 text-xs">
                    {searchStudent
                      ? `No candidates found matching "${searchStudent}".`
                      : "No students registered yet. Real candidate accounts will appear here in real time as pilots register."}
                  </td>
                </tr>
              ) : (
                filtered.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50">
                    <td className="py-3.5">
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-aviation-900 block">{s.name}</span>
                        {s.role === "admin" && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-sky-100 text-sky-800 border border-sky-300 uppercase">
                            Admin
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 font-mono">{s.email}</span>
                    </td>
                    <td className="py-3.5 text-slate-500">{s.joined}</td>
                    <td className="py-3.5 font-semibold text-aviation-900">{s.plan}</td>
                    <td className="py-3.5 text-slate-500">{s.starts}</td>
                    <td className="py-3.5 font-mono text-slate-800">{s.expires}</td>
                    <td className="py-3.5">
                      {s.daysLeft > 0 ? (
                        <span className="font-bold text-emerald-600">{s.daysLeft} Days Left</span>
                      ) : (
                        <span className="text-slate-400">None</span>
                      )}
                    </td>
                    <td className="py-3.5 text-center">
                      <span
                        className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                          s.status === "Active"
                            ? "bg-emerald-100 text-emerald-800 border border-emerald-300"
                            : "bg-slate-100 text-slate-600 border border-slate-200"
                        }`}
                      >
                        {s.status}
                      </span>
                    </td>
                    <td className="py-3.5 text-right">
                      {s.role === "admin" ? (
                        <span className="text-[11px] font-bold text-sky-600">Full System Access</span>
                      ) : (
                        <button
                          type="button"
                          disabled={actionLoadingId === s.id}
                          onClick={() => handleTogglePremium(s)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs ${
                            s.is_premium
                              ? "bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200"
                              : "bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-500/20"
                          } ${actionLoadingId === s.id ? "opacity-50 cursor-not-allowed" : ""}`}
                        >
                          {actionLoadingId === s.id
                            ? "Saving..."
                            : s.is_premium
                            ? "Revoke Premium"
                            : "⭐ Grant 1-Yr Premium"}
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
