"use client";

import React, { useState } from "react";
import { DETAILED_SUBJECTS, DetailedSubject } from "@/data/syllabusData";

export default function AdminSubjectsPage() {
  const [subjectsList, setSubjectsList] = useState<DetailedSubject[]>(DETAILED_SUBJECTS);
  const [activeSubject, setActiveSubject] = useState<DetailedSubject>(DETAILED_SUBJECTS[0]);
  const [isAddChapterOpen, setIsAddChapterOpen] = useState(false);
  const [newChapterTitle, setNewChapterTitle] = useState("");
  const [newChapterDesc, setNewChapterDesc] = useState("");
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const handleAddChapter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChapterTitle.trim()) return;

    const newChNumber = activeSubject.chapters.length + 1;
    const newCh = {
      id: `ch-${Date.now()}`,
      subjectSlug: activeSubject.slug,
      chapterNumber: newChNumber,
      title: newChapterTitle,
      slug: newChapterTitle.toLowerCase().replace(/[^a-z0-9]/g, "-"),
      description: newChapterDesc || "Standard DGCA examination chapter.",
      topics: ["Fundamental Theory", "Regulatory Context", "Practice Drills"],
      questionCount: 0,
      completedPercent: 0,
      revisionNotes: "Chapter revision concepts.",
    };

    const updatedChapters = [...activeSubject.chapters, newCh];
    const updatedSubject = { ...activeSubject, chapters: updatedChapters, totalChapters: updatedChapters.length };

    setActiveSubject(updatedSubject);
    setSubjectsList((prev) => prev.map((s) => (s.id === updatedSubject.id ? updatedSubject : s)));

    setNewChapterTitle("");
    setNewChapterDesc("");
    setIsAddChapterOpen(false);
    setSuccessToast(`Chapter #${newChNumber} added to ${activeSubject.name}!`);
    setTimeout(() => setSuccessToast(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-aviation-900 tracking-tight">
            Syllabus & Chapter Organization
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Organize DGCA subject units, add or reorder chapters, and update syllabus parameters in real time.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsAddChapterOpen(true)}
          className="py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-sm transition-colors flex-shrink-0"
        >
          + Add Chapter to Current Subject
        </button>
      </div>

      {successToast && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold">
          ✓ {successToast}
        </div>
      )}

      {/* Two Column Layout: Subject Selector & Chapter Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Subject List */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">
            Active DGCA Subjects ({subjectsList.length})
          </span>

          {subjectsList.map((sub) => {
            const isSelected = sub.id === activeSubject.id;
            return (
              <button
                key={sub.id}
                type="button"
                onClick={() => setActiveSubject(sub)}
                className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-center justify-between ${
                  isSelected
                    ? "bg-aviation-900 border-aviation-900 text-white font-bold shadow-md"
                    : "bg-white border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold"
                }`}
              >
                <div>
                  <span className="text-xs block leading-snug">{sub.name}</span>
                  <span className={`text-[10px] block mt-0.5 ${isSelected ? "text-skyAccent-300" : "text-slate-400"}`}>
                    {sub.code} • {sub.chapters.length} Chapters
                  </span>
                </div>
                <span className="text-xs">→</span>
              </button>
            );
          })}
        </div>

        {/* Right 2 Columns: Selected Subject Chapters Table */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-aviation-900">{activeSubject.name} Chapters</h2>
              <p className="text-xs text-slate-400">Total {activeSubject.chapters.length} chapters configured</p>
            </div>
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
              {activeSubject.code}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 uppercase font-semibold">
                  <th className="pb-3">#</th>
                  <th className="pb-3">Chapter Title</th>
                  <th className="pb-3">Topics Count</th>
                  <th className="pb-3">Question Bank</th>
                  <th className="pb-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {activeSubject.chapters.map((ch) => (
                  <tr key={ch.id} className="hover:bg-slate-50">
                    <td className="py-3 font-mono font-bold text-aviation-900">{ch.chapterNumber}</td>
                    <td className="py-3">
                      <span className="font-semibold text-aviation-900 block">{ch.title}</span>
                      <span className="text-[11px] text-slate-400 font-mono">slug: {ch.slug}</span>
                    </td>
                    <td className="py-3">{ch.topics.length} Key Topics</td>
                    <td className="py-3 font-semibold text-skyAccent-600">{ch.questionCount} Questions</td>
                    <td className="py-3 text-right space-x-2">
                      <button type="button" className="text-skyAccent-700 font-semibold hover:underline">
                        Edit
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add Chapter Modal */}
      {isAddChapterOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-aviation-900">
                Add Chapter to {activeSubject.name}
              </h3>
              <button
                type="button"
                onClick={() => setIsAddChapterOpen(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddChapter} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Chapter Title
                </label>
                <input
                  type="text"
                  required
                  value={newChapterTitle}
                  onChange={(e) => setNewChapterTitle(e.target.value)}
                  placeholder="e.g. Jet Streams & Clear Air Turbulence"
                  className="w-full p-3 rounded-xl border border-slate-200 text-xs text-slate-900 focus:ring-2 focus:ring-aviation-800"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Description
                </label>
                <textarea
                  rows={3}
                  value={newChapterDesc}
                  onChange={(e) => setNewChapterDesc(e.target.value)}
                  placeholder="Brief synopsis of topics covered in this syllabus chapter..."
                  className="w-full p-3 rounded-xl border border-slate-200 text-xs text-slate-900 focus:ring-2 focus:ring-aviation-800"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddChapterOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800"
                >
                  Add Chapter
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
