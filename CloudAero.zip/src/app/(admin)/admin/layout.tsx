"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "@/lib/auth-context";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { user, profile, isAdmin, isLoading } = useAuth();

  const navLinks = [
    { label: "Dashboard Overview", href: "/admin", icon: "📊" },
    { label: "Syllabus & Chapters", href: "/admin/subjects", icon: "📚" },
    { label: "Questions & Bulk CSV", href: "/admin/questions", icon: "📝" },
    { label: "Mock Exam Builder", href: "/admin/mock-exams", icon: "⏱️" },
    { label: "Students & Billing", href: "/admin/students", icon: "👥" },
    { label: "Reported Issues", href: "/admin/reports", icon: "🚩" },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-aviation-950 flex items-center justify-center text-white">
        <div className="animate-pulse text-sm font-semibold text-slate-300">
          Verifying Administrator Credentials...
        </div>
      </div>
    );
  }

  // If visitor is not authenticated as an admin
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center text-3xl mx-auto font-bold">
            🛡️
          </div>
          <h2 className="text-xl font-extrabold text-aviation-950">
            CloudAero Admin Access Required
          </h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            {user
              ? `You are signed in as ${user.email}, which does not have administrator privileges. Please sign in with an authorized admin email.`
              : "This control deck is restricted to DGCA Chief Ground Instructors and authorized administrators."}
          </p>

          <div className="pt-2 flex flex-col gap-2.5">
            <Link
              href="/login"
              className="py-3 px-4 rounded-xl text-xs font-bold bg-aviation-900 hover:bg-aviation-800 text-white transition-colors text-center shadow-md"
            >
              Log In with Admin Account →
            </Link>
            <Link
              href="/"
              className="py-2 px-4 rounded-xl text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors text-center"
            >
              ← Return to Main Website
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-aviation-950 text-white flex-shrink-0 flex flex-col justify-between border-r border-aviation-900">
        <div>
          {/* Header */}
          <div className="p-6 border-b border-aviation-900">
            <Link href="/" className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-lg bg-skyAccent-500 text-aviation-950 flex items-center justify-center font-bold text-sm">
                ✈️
              </div>
              <div>
                <span className="font-extrabold text-sm tracking-tight text-white block">
                  CloudAero DGCA
                </span>
                <span className="text-[10px] font-bold text-skyAccent-400 uppercase tracking-wider block">
                  Admin Control Deck
                </span>
              </div>
            </Link>
          </div>

          {/* Navigation Links */}
          <nav className="p-4 space-y-1 text-xs font-semibold">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`flex items-center space-x-3 px-3.5 py-3 rounded-xl transition-all ${
                    isActive
                      ? "bg-skyAccent-400 text-aviation-950 font-bold shadow-md shadow-skyAccent-400/20"
                      : "text-slate-300 hover:bg-aviation-900 hover:text-white"
                  }`}
                >
                  <span className="text-base">{link.icon}</span>
                  <span>{link.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Admin User Info & Exit */}
        <div className="p-4 border-t border-aviation-900/80 bg-aviation-900/40">
          <div className="flex items-center justify-between text-xs mb-3">
            <div>
              <span className="font-bold text-white block truncate">
                {profile?.full_name || "Chief Ground Instructor"}
              </span>
              <span className="text-[10px] text-skyAccent-400 block">Super Administrator</span>
            </div>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          </div>

          <Link
            href="/"
            className="w-full inline-block text-center py-2 px-3 rounded-lg text-xs font-semibold text-slate-300 hover:text-white bg-aviation-900 hover:bg-aviation-800 transition-colors"
          >
            ← Return to Student Website
          </Link>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-grow flex flex-col min-w-0">
        <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs">
            <span className="text-slate-400">Admin Control</span>
            <span className="text-slate-300">/</span>
            <span className="text-aviation-900 font-bold capitalize">
              {pathname.replace("/admin", "").replace("/", "") || "Overview"}
            </span>
          </div>

          <div className="flex items-center space-x-3">
            <span className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 font-semibold">
              Live Database Connected
            </span>
          </div>
        </header>

        <main className="p-6 sm:p-8 flex-grow">{children}</main>
      </div>
    </div>
  );
}
