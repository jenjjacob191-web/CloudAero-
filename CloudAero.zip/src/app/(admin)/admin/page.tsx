"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";

interface StudentRecord {
  id: string;
  name: string;
  email: string;
  role?: string;
  joined: string;
  plan: string;
  starts: string;
  expires: string;
  status: string;
  daysLeft: number;
}

export default function AdminDashboardPage() {
  const { user, profile } = useAuth();
  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [ticketCount, setTicketCount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadDashboardData() {
      try {
        setIsLoading(true);
        const adminEmail = user?.email || profile?.email || "admin@cloudaero.in";
        const [studRes, tktRes] = await Promise.all([
          fetch("/api/admin/students", {
            headers: { "x-admin-email": adminEmail },
          }),
          fetch("/api/support/tickets"),
        ]);

        if (studRes.ok) {
          const data = await studRes.json();
          if (data.students) setStudents(data.students);
        }
        if (tktRes.ok) {
          const data = await tktRes.json();
          if (data.tickets) {
            const pending = data.tickets.filter((t: any) => t.status === "pending").length;
            setTicketCount(pending);
          }
        }
      } catch (e) {
        console.warn("Could not load admin stats:", e);
      } finally {
        setIsLoading(false);
      }
    }
    loadDashboardData();
  }, []);

  const activeSubsCount = students.filter((s) => s.status === "Active").length;
  const estimatedRevenue = activeSubsCount * 300;

  const kpis = [
    {
      title: "Registered Pilots",
      value: isLoading ? "..." : String(students.length),
      subtext: students.length > 0 ? `${students.length} real pilot accounts` : "Ready for enrollments",
      icon: "👥",
      color: "text-blue-600 bg-blue-50",
    },
    {
      title: "Active Subscriptions",
      value: isLoading ? "..." : String(activeSubsCount),
      subtext: activeSubsCount > 0 ? `${activeSubsCount} active cadet passes` : "Razorpay gateway ready",
      icon: "💎",
      color: "text-emerald-600 bg-emerald-50",
    },
    {
      title: "Estimated Revenue",
      value: isLoading ? "..." : `₹${estimatedRevenue.toLocaleString("en-IN")}`,
      subtext: "Razorpay audit active",
      icon: "₹",
      color: "text-indigo-600 bg-indigo-50",
    },
    {
      title: "Pending Tickets",
      value: isLoading ? "..." : String(ticketCount),
      subtext: ticketCount > 0 ? "Requires admin review" : "All issues resolved",
      icon: "🚩",
      color: ticketCount > 0 ? "text-amber-600 bg-amber-50" : "text-slate-600 bg-slate-50",
    },
  ];

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-skyAccent-700 bg-skyAccent-50 px-3 py-1 rounded-full border border-skyAccent-200">
            Platform Command Center
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-aviation-900 tracking-tight mt-2">
            CloudAero DGCA Operations
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Real-time management of DGCA syllabus questions, mock exams, student subscriptions, and revenue audit.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <Link
            href="/admin/questions"
            className="py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-sm transition-colors"
          >
            + Add / Import Questions
          </Link>
          <Link
            href="/admin/mock-exams"
            className="py-2.5 px-4 rounded-xl text-xs font-semibold text-aviation-800 bg-aviation-50 hover:bg-aviation-100 border border-aviation-200 transition-colors"
          >
            + Create Mock Exam
          </Link>
        </div>
      </div>

      {/* 4 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi, idx) => (
          <div key={idx} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-400 block uppercase">{kpi.title}</span>
              <span className="text-3xl font-extrabold text-aviation-900 my-1 block">{kpi.value}</span>
              <span className="text-xs text-emerald-600 font-semibold">{kpi.subtext}</span>
            </div>
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl font-bold ${kpi.color}`}>
              {kpi.icon}
            </div>
          </div>
        ))}
      </div>

      {/* Two Column Grid: Transactions & Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Recent Subscriptions & Students */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-aviation-900">Recent Registered Candidates</h2>
              <p className="text-xs text-slate-400">Live pilot accounts registered in Supabase</p>
            </div>
            <Link href="/admin/students" className="text-xs font-semibold text-skyAccent-700 hover:underline">
              View All Students ({students.length}) →
            </Link>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-semibold">
                  <th className="pb-3">Candidate</th>
                  <th className="pb-3">Tier</th>
                  <th className="pb-3">Joined Date</th>
                  <th className="pb-3">Valid Until</th>
                  <th className="pb-3 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {isLoading ? (
                  <tr>
                    <td colSpan={5} className="py-10 text-center text-slate-400 text-xs animate-pulse">
                      Loading registered students...
                    </td>
                  </tr>
                ) : students.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-12 text-center text-slate-400 text-xs">
                      No candidate pilots registered yet. Real accounts will appear here automatically upon signup.
                    </td>
                  </tr>
                ) : (
                  students.slice(0, 5).map((s) => (
                    <tr key={s.id}>
                      <td className="py-3.5">
                        <span className="font-bold text-aviation-900 block">{s.name}</span>
                        <span className="text-[11px] text-slate-400 font-mono">{s.email}</span>
                      </td>
                      <td className="py-3.5 font-medium">{s.plan}</td>
                      <td className="py-3.5 text-slate-500">{s.joined}</td>
                      <td className="py-3.5 font-semibold text-aviation-900">{s.expires}</td>
                      <td className="py-3.5 text-right">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            s.status === "Active"
                              ? "bg-emerald-100 text-emerald-800"
                              : "bg-slate-100 text-slate-600"
                          }`}
                        >
                          {s.status}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 1 Col: Pending Reports & Quick Actions */}
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-aviation-900">Support &amp; Dispute Desk</h3>
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  ticketCount > 0 ? "bg-amber-500 animate-ping" : "bg-emerald-500"
                }`}
              />
            </div>
            <p className="text-xs text-slate-500 leading-relaxed mb-4">
              Real-time ticket queue for student pilot queries, billing receipts, and question disputes.
            </p>
            <div
              className={`p-3 rounded-xl border text-xs mb-4 ${
                ticketCount > 0
                  ? "bg-amber-50 border-amber-200 text-amber-900"
                  : "bg-slate-50 border-slate-200 text-slate-600"
              }`}
            >
              <strong>Status:</strong>{" "}
              {ticketCount > 0
                ? `${ticketCount} ticket(s) pending your review.`
                : "Zero pending dispute reports. Desk is all clear."}
            </div>
            <Link
              href="/admin/reports"
              className="w-full inline-block text-center py-2.5 rounded-xl text-xs font-bold text-aviation-900 bg-aviation-50 hover:bg-aviation-100 border border-aviation-200 transition-colors"
            >
              Open Resolution Desk ({ticketCount} Pending) →
            </Link>
          </div>

          <div className="bg-gradient-to-br from-aviation-900 to-aviation-950 text-white rounded-2xl p-6 shadow-md">
            <span className="text-xs font-bold uppercase text-skyAccent-300">Quick Actions</span>
            <div className="mt-3 space-y-2">
              <Link
                href="/admin/questions"
                className="block p-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white transition-colors"
              >
                📥 Upload Questions CSV Template
              </Link>
              <Link
                href="/admin/subjects"
                className="block p-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white transition-colors"
              >
                ⚙️ Configure Subject Syllabi
              </Link>
              <Link
                href="/admin/mock-exams"
                className="block p-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white transition-colors"
              >
                📝 Configure 70-Q CPL Mock Papers
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
