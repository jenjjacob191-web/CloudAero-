"use client";

import React, { useState } from "react";
import { MOCK_EXAMS_CATALOG, MockExamDefinition } from "@/data/mockExamsData";
import { DETAILED_SUBJECTS } from "@/data/syllabusData";

export default function AdminMockExamsPage() {
  const [exams, setExams] = useState<MockExamDefinition[]>(MOCK_EXAMS_CATALOG);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [examTitle, setExamTitle] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("Aviation Meteorology");
  const [durationMinutes, setDurationMinutes] = useState(120);
  const [totalQuestions, setTotalQuestions] = useState(70);
  const [negativeMarking, setNegativeMarking] = useState(0);
  const [isPremium, setIsPremium] = useState(true);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleCreateExam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!examTitle.trim()) return;

    const newExam: MockExamDefinition = {
      id: `mock-${Date.now()}`,
      slug: examTitle.toLowerCase().replace(/[^a-z0-9]/g, "-"),
      title: examTitle,
      subjectName: selectedSubject,
      subjectSlug: selectedSubject.toLowerCase().replace(/[^a-z0-9]/g, "-"),
      difficulty: "DGCA Standard",
      durationMinutes,
      totalQuestions,
      marksPerQuestion: 1,
      negativeMarking,
      passingPercentage: 70,
      isPremium,
      description: `Configured simulated CBT mock examination for ${selectedSubject}.`,
      questions: [],
    };

    setExams([newExam, ...exams]);
    setIsCreateModalOpen(false);
    setExamTitle("");
    setToastMessage(`Mock Exam "${newExam.title}" created successfully!`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const togglePremium = (id: string) => {
    setExams((prev) =>
      prev.map((e) => (e.id === id ? { ...e, isPremium: !e.isPremium } : e))
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-aviation-900 tracking-tight">
            Mock Examination Builder
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Configure examination timing, question volumes, negative marking rules, and premium CBT access parameters.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsCreateModalOpen(true)}
          className="py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-sm transition-colors flex-shrink-0"
        >
          + Build New Mock Paper
        </button>
      </div>

      {toastMessage && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold">
          ✓ {toastMessage}
        </div>
      )}

      {/* Table of Configured Mocks */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <h2 className="text-base font-bold text-aviation-900 mb-4 pb-2 border-b border-slate-100">
          Published Examination Papers ({exams.length})
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 uppercase font-semibold">
                <th className="pb-3">Exam Title</th>
                <th className="pb-3">Subject</th>
                <th className="pb-3">Duration</th>
                <th className="pb-3">Questions</th>
                <th className="pb-3">Negative Mark</th>
                <th className="pb-3">Access Tier</th>
                <th className="pb-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {exams.map((ex) => (
                <tr key={ex.id} className="hover:bg-slate-50">
                  <td className="py-3.5 font-bold text-aviation-900">{ex.title}</td>
                  <td className="py-3.5 text-slate-500">{ex.subjectName}</td>
                  <td className="py-3.5 font-semibold">{ex.durationMinutes} Mins</td>
                  <td className="py-3.5 font-semibold text-aviation-900">{ex.totalQuestions} Qs</td>
                  <td className="py-3.5 font-mono text-slate-600">
                    {ex.negativeMarking > 0 ? `-${ex.negativeMarking}` : "Nil"}
                  </td>
                  <td className="py-3.5">
                    <button
                      type="button"
                      onClick={() => togglePremium(ex.id)}
                      className={`px-2.5 py-1 rounded-full text-[10px] font-bold border transition-colors ${
                        ex.isPremium
                          ? "bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100"
                          : "bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100"
                      }`}
                    >
                      {ex.isPremium ? "🔒 Premium Lock" : "🆓 Free Sample"}
                    </button>
                  </td>
                  <td className="py-3.5 text-right space-x-2">
                    <button type="button" className="text-skyAccent-700 font-semibold hover:underline">
                      Configure
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-aviation-900">
                Configure New Mock Examination
              </h3>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateExam} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Examination Title
                </label>
                <input
                  type="text"
                  required
                  value={examTitle}
                  onChange={(e) => setExamTitle(e.target.value)}
                  placeholder="e.g. Air Navigation — CPL Standard Mock Paper #4"
                  className="w-full p-3 rounded-xl border border-slate-200 text-xs text-slate-900 focus:ring-2 focus:ring-aviation-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Subject
                  </label>
                  <select
                    value={selectedSubject}
                    onChange={(e) => setSelectedSubject(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-aviation-800"
                  >
                    {DETAILED_SUBJECTS.map((s) => (
                      <option key={s.id} value={s.name}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Duration (Minutes)
                  </label>
                  <input
                    type="number"
                    value={durationMinutes}
                    onChange={(e) => setDurationMinutes(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-aviation-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Total Questions
                  </label>
                  <input
                    type="number"
                    value={totalQuestions}
                    onChange={(e) => setTotalQuestions(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-aviation-800"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Negative Marking
                  </label>
                  <input
                    type="number"
                    step="0.25"
                    value={negativeMarking}
                    onChange={(e) => setNegativeMarking(Number(e.target.value))}
                    placeholder="0 or 0.25"
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-aviation-800"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2 pt-2">
                <input
                  type="checkbox"
                  id="premium-toggle"
                  checked={isPremium}
                  onChange={(e) => setIsPremium(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-aviation-900"
                />
                <label htmlFor="premium-toggle" className="text-xs font-semibold text-slate-700">
                  Require Active Paid Subscription (Premium Tier)
                </label>
              </div>

              <div className="flex justify-end space-x-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800"
                >
                  Save & Publish Mock Exam
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
