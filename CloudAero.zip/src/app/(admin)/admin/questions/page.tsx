"use client";

import React, { useState } from "react";
import { DETAILED_SUBJECTS } from "@/data/syllabusData";

interface ParsedRow {
  questionText: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  correctOption: string;
  explanation: string;
  difficulty: string;
  subject: string;
  chapter: string;
  isValid: boolean;
  validationError?: string;
}

export default function AdminQuestionsPage() {
  const [activeTab, setActiveTab] = useState<"csv" | "manual" | "list">("csv");

  // CSV State
  const [csvRawText, setCsvRawText] = useState("");
  const [parsedRows, setParsedRows] = useState<ParsedRow[]>([]);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Manual Form State
  const [manualSubject, setManualSubject] = useState("Air Regulations");
  const [manualChapter, setManualChapter] = useState("Aircraft Act 1934 & Statutory Authorities");
  const [manualQuestionText, setManualQuestionText] = useState("");
  const [optionA, setOptionA] = useState("");
  const [optionB, setOptionB] = useState("");
  const [optionC, setOptionC] = useState("");
  const [optionD, setOptionD] = useState("");
  const [correctOption, setCorrectOption] = useState<"A" | "B" | "C" | "D">("A");
  const [manualExplanation, setManualExplanation] = useState("");
  const [manualDifficulty, setManualDifficulty] = useState<"Easy" | "Medium" | "Hard">("Medium");
  const [manualYear, setManualYear] = useState("");
  const [manualSource, setManualSource] = useState("DGCA Authorized Training Manual");
  const [manualSavedMessage, setManualSavedMessage] = useState<string | null>(null);

  // Download Sample CSV
  const handleDownloadSampleCSV = () => {
    const csvContent =
      "question_text,option_a,option_b,option_c,option_d,correct_option,explanation,difficulty,subject,chapter\n" +
      '"What is standard ISA sea-level temperature?","15°C","20°C","0°C","25°C","A","Under ICAO ISA baseline standards, sea-level temperature is +15°C.","Easy","Aviation Meteorology","The Atmosphere & International Standard Atmosphere (ISA)"\n' +
      '"An aircraft converges from the right. Who has right of way?","Aircraft on the right","Aircraft on the left","Faster aircraft","Heavier aircraft","A","Under DGCA Rule 68 and ICAO Annex 2, the aircraft on the right has right-of-way.","Medium","Air Regulations","Rules of the Air & Airspace Classification"\n' +
      '"What is the emergency transponder squawk code for hijacking?","7500","7600","7700","7000","A","Squawk 7500 denotes unlawful interference / hijack.","Easy","Air Regulations","Aerodrome Operations & Emergency Signals"';

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "cloudaero_dgca_questions_sample_template.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Parse CSV Text
  const handleParseCSV = (rawText: string) => {
    setCsvRawText(rawText);
    setImportStatus(null);
    if (!rawText.trim()) {
      setParsedRows([]);
      return;
    }

    const lines = rawText.split("\n").filter((l) => l.trim().length > 0);
    if (lines.length <= 1) {
      setParsedRows([]);
      return;
    }

    // Skip header line
    const rows: ParsedRow[] = [];
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      // Basic CSV splitter respecting simple commas/quotes
      const parts = line.split(",").map((p) => p.replace(/^"|"$/g, "").trim());

      const questionText = parts[0] || "";
      const optA = parts[1] || "";
      const optB = parts[2] || "";
      const optC = parts[3] || "";
      const optD = parts[4] || "";
      const correct = (parts[5] || "").toUpperCase();
      const expl = parts[6] || "";
      const diff = parts[7] || "Medium";
      const sub = parts[8] || "Air Regulations";
      const ch = parts[9] || "General";

      let isValid = true;
      let error = "";

      if (!questionText) {
        isValid = false;
        error = "Missing question text";
      } else if (!optA || !optB || !optC || !optD) {
        isValid = false;
        error = "All 4 options (A,B,C,D) required";
      } else if (!["A", "B", "C", "D"].includes(correct)) {
        isValid = false;
        error = "Correct option must be A, B, C, or D";
      }

      rows.push({
        questionText,
        optionA: optA,
        optionB: optB,
        optionC: optC,
        optionD: optD,
        correctOption: correct,
        explanation: expl,
        difficulty: diff,
        subject: sub,
        chapter: ch,
        isValid,
        validationError: error,
      });
    }

    setParsedRows(rows);
  };

  // Commit CSV Upload
  const handleCommitImport = () => {
    const validCount = parsedRows.filter((r) => r.isValid).length;
    setImportStatus(`Successfully validated and imported ${validCount} questions into the DGCA question bank!`);
  };

  // Handle Manual Save
  const handleSaveManualQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    setManualSavedMessage(
      `Question successfully authored and added to ${manualSubject} — ${manualChapter}!`
    );
    setManualQuestionText("");
    setOptionA("");
    setOptionB("");
    setOptionC("");
    setOptionD("");
    setManualExplanation("");
    setTimeout(() => setManualSavedMessage(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-aviation-900 tracking-tight">
            Question Authoring & Bulk Importer
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Author single questions manually or import hundreds of verified questions using standard CSV templates.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center space-x-1.5 bg-slate-100 p-1.5 rounded-2xl">
          <button
            type="button"
            onClick={() => setActiveTab("csv")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === "csv" ? "bg-white text-aviation-950 shadow-sm" : "text-slate-600 hover:text-slate-900"
            }`}
          >
            📥 CSV Bulk Uploader
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("manual")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === "manual" ? "bg-white text-aviation-950 shadow-sm" : "text-slate-600 hover:text-slate-900"
            }`}
          >
            ✍️ Manual Authoring
          </button>
        </div>
      </div>

      {/* Tab 1: CSV Bulk Uploader */}
      {activeTab === "csv" && (
        <div className="space-y-6">
          {/* Instructions & Template Download Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-bold text-aviation-900">Standard Question Import Template</h2>
              <p className="text-xs text-slate-500 mt-1">
                Ensure your CSV has columns: <code className="bg-slate-100 px-1 py-0.5 rounded text-aviation-800">question_text, option_a, option_b, option_c, option_d, correct_option, explanation, difficulty, subject, chapter</code>.
              </p>
            </div>
            <button
              type="button"
              onClick={handleDownloadSampleCSV}
              className="py-2.5 px-4 rounded-xl text-xs font-bold text-aviation-900 bg-aviation-50 hover:bg-aviation-100 border border-aviation-200 transition-colors flex items-center space-x-2 flex-shrink-0"
            >
              <span>📥 Download Sample CSV</span>
            </button>
          </div>

          {/* CSV Input Area */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-aviation-900 uppercase tracking-wider">
                Paste CSV Text or Upload File
              </label>
              <button
                type="button"
                onClick={() =>
                  handleParseCSV(
                    "question_text,option_a,option_b,option_c,option_d,correct_option,explanation,difficulty,subject,chapter\n" +
                      '"What is standard ISA sea-level temperature?","15°C","20°C","0°C","25°C","A","Under ICAO ISA standards, sea-level temperature is +15°C.","Easy","Aviation Meteorology","The Atmosphere"\n' +
                      '"An aircraft converges from the right. Who has right of way?","Aircraft on the right","Aircraft on the left","Faster aircraft","Heavier aircraft","A","DGCA Rule 68: Aircraft on right has right-of-way.","Medium","Air Regulations","Rules of the Air"\n' +
                      '"Emergency transponder squawk code for hijacking?","7500","7600","7700","7000","A","Squawk 7500 denotes hijack.","Easy","Air Regulations","Aerodromes and Signals"'
                  )
                }
                className="text-xs font-semibold text-skyAccent-700 hover:underline"
              >
                Insert Sample Demo Rows
              </button>
            </div>

            <textarea
              rows={5}
              value={csvRawText}
              onChange={(e) => handleParseCSV(e.target.value)}
              placeholder="Paste comma-separated rows here or click 'Insert Sample Demo Rows' above..."
              className="w-full p-4 rounded-xl border border-slate-200 font-mono text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-aviation-800"
            />
          </div>

          {importStatus && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center space-x-2">
              <span>✓</span>
              <span>{importStatus}</span>
            </div>
          )}

          {/* Validation & Preview Table */}
          {parsedRows.length > 0 && (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-aviation-900">
                    Parsed Questions Preview ({parsedRows.length} Rows)
                  </h3>
                  <p className="text-xs text-slate-500">
                    {parsedRows.filter((r) => r.isValid).length} Valid rows •{" "}
                    {parsedRows.filter((r) => !r.isValid).length} Errors detected
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleCommitImport}
                  className="py-2.5 px-6 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md transition-colors"
                >
                  Import {parsedRows.filter((r) => r.isValid).length} Valid Questions
                </button>
              </div>

              <div className="overflow-x-auto max-h-96">
                <table className="w-full text-left text-xs">
                  <thead className="sticky top-0 bg-white">
                    <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase">
                      <th className="pb-3">Status</th>
                      <th className="pb-3">Question Text</th>
                      <th className="pb-3">Key</th>
                      <th className="pb-3">Difficulty</th>
                      <th className="pb-3">Subject</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {parsedRows.map((row, rIdx) => (
                      <tr key={rIdx} className={row.isValid ? "hover:bg-slate-50" : "bg-red-50/40"}>
                        <td className="py-3">
                          {row.isValid ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                              Valid
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-800">
                              {row.validationError}
                            </span>
                          )}
                        </td>
                        <td className="py-3 font-semibold text-aviation-900 max-w-sm truncate">
                          {row.questionText}
                        </td>
                        <td className="py-3 font-mono font-bold text-aviation-900">{row.correctOption}</td>
                        <td className="py-3 text-slate-500">{row.difficulty}</td>
                        <td className="py-3 text-slate-500">{row.subject}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Manual Authoring */}
      {activeTab === "manual" && (
        <form onSubmit={handleSaveManualQuestion} className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-base font-bold text-aviation-900">Author Multiple Choice Question</h2>
            <p className="text-xs text-slate-500">Add an individual question with detailed flight explanation and regulatory references.</p>
          </div>

          {manualSavedMessage && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold">
              ✓ {manualSavedMessage}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Target Subject
              </label>
              <select
                value={manualSubject}
                onChange={(e) => setManualSubject(e.target.value)}
                className="w-full p-3 rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-aviation-800"
              >
                {DETAILED_SUBJECTS.map((s) => (
                  <option key={s.id} value={s.name}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Chapter
              </label>
              <input
                type="text"
                value={manualChapter}
                onChange={(e) => setManualChapter(e.target.value)}
                placeholder="e.g. Altimetry & Atmospheric Pressure"
                className="w-full p-3 rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-aviation-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Difficulty Level
              </label>
              <select
                value={manualDifficulty}
                onChange={(e) => setManualDifficulty(e.target.value as "Easy" | "Medium" | "Hard")}
                className="w-full p-3 rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-aviation-800"
              >
                <option value="Easy">Easy</option>
                <option value="Medium">Medium</option>
                <option value="Hard">Hard</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Question Text
            </label>
            <textarea
              rows={3}
              required
              value={manualQuestionText}
              onChange={(e) => setManualQuestionText(e.target.value)}
              placeholder="e.g. An aircraft is flying on standard pressure setting of 1013.25 hPa from high to low pressure..."
              className="w-full p-3.5 rounded-xl border border-slate-200 text-xs text-slate-900 focus:ring-2 focus:ring-aviation-800"
            />
          </div>

          {/* 4 Options Grid */}
          <div className="space-y-3">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
              Four Answer Options & Correct Key Selection
            </label>

            {[
              { label: "A", val: optionA, setter: setOptionA },
              { label: "B", val: optionB, setter: setOptionB },
              { label: "C", val: optionC, setter: setOptionC },
              { label: "D", val: optionD, setter: setOptionD },
            ].map((opt) => (
              <div key={opt.label} className="flex items-center space-x-3">
                <input
                  type="radio"
                  name="correctOption"
                  checked={correctOption === opt.label}
                  onChange={() => setCorrectOption(opt.label as "A" | "B" | "C" | "D")}
                  className="h-4 w-4 text-emerald-600 focus:ring-emerald-500"
                  title="Mark as correct answer"
                />
                <span className="w-7 h-7 rounded-lg bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center flex-shrink-0">
                  {opt.label}
                </span>
                <input
                  type="text"
                  required
                  value={opt.val}
                  onChange={(e) => opt.setter(e.target.value)}
                  placeholder={`Option ${opt.label} text`}
                  className="w-full p-3 rounded-xl border border-slate-200 text-xs text-slate-900 focus:ring-2 focus:ring-aviation-800"
                />
              </div>
            ))}
          </div>

          {/* Detailed Explanation */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Detailed Mathematical / Regulatory Explanation
            </label>
            <textarea
              rows={3}
              required
              value={manualExplanation}
              onChange={(e) => setManualExplanation(e.target.value)}
              placeholder="Explain the aerodynamic or meteorological principle, including formulas and memory aids..."
              className="w-full p-3.5 rounded-xl border border-slate-200 text-xs text-slate-900 focus:ring-2 focus:ring-aviation-800"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Verified Exam Year (Optional)
              </label>
              <input
                type="number"
                value={manualYear}
                onChange={(e) => setManualYear(e.target.value)}
                placeholder="e.g. 2024 (leave blank if general bank question)"
                className="w-full p-3 rounded-xl border border-slate-200 text-xs text-slate-900 focus:ring-2 focus:ring-aviation-800"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Verified Material Citation
              </label>
              <input
                type="text"
                value={manualSource}
                onChange={(e) => setManualSource(e.target.value)}
                className="w-full p-3 rounded-xl border border-slate-200 text-xs text-slate-900 focus:ring-2 focus:ring-aviation-800"
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="py-3 px-8 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-md transition-colors"
            >
              Save Question to DGCA Question Bank
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
