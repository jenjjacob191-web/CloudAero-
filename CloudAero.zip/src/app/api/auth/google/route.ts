import { NextRequest, NextResponse } from "next/server";
import { checkIsAdminEmail } from "@/lib/roles";
import { registerDeviceSession } from "@/lib/security/session-manager";

const supabaseUrl =
  process.env.NEXT_PUBLIC_SUPABASE_URL || "https://vilaryczczniwiaeezlg.supabase.co";
const serviceKey =
  process.env.SUPABASE_SERVICE_ROLE_KEY || "sb_secret_SipEf5BBB2DTJE03DrAELw_DhoLprF2";

export async function POST(req: NextRequest) {
  try {
    const { email, name, avatarUrl, userAgent } = await req.json();

    if (!email || typeof email !== "string" || !email.includes("@")) {
      return NextResponse.json({ error: "A valid Google email address is required" }, { status: 400 });
    }

    const cleanEmail = email.toLowerCase().trim();
    const cleanName = (name && typeof name === "string" && name.trim()) || cleanEmail.split("@")[0];
    const isPreconfiguredAdmin = checkIsAdminEmail(cleanEmail);

    // 1. Check if user exists in Supabase auth.users
    let userId: string | null = null;

    try {
      // List users or find by email via Admin API
      const listRes = await fetch(`${supabaseUrl}/auth/v1/admin/users?page=1&per_page=100`, {
        headers: {
          apikey: serviceKey,
          Authorization: `Bearer ${serviceKey}`,
        },
      });

      if (listRes.ok) {
        const listData = await listRes.json();
        const found = listData.users?.find(
          (u: any) => u.email?.toLowerCase().trim() === cleanEmail
        );
        if (found) {
          userId = found.id;
        }
      }
    } catch (e) {
      console.warn("Could not list auth users:", e);
    }

    // If user does not exist, create in Supabase Auth
    if (!userId) {
      try {
        const createRes = await fetch(`${supabaseUrl}/auth/v1/admin/users`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            apikey: serviceKey,
            Authorization: `Bearer ${serviceKey}`,
          },
          body: JSON.stringify({
            email: cleanEmail,
            email_confirm: true,
            user_metadata: {
              full_name: cleanName,
              avatar_url: avatarUrl || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(cleanName)}`,
              provider: "google",
              role: isPreconfiguredAdmin ? "admin" : "student",
            },
          }),
        });

        if (createRes.ok) {
          const createData = await createRes.json();
          userId = createData.id;
        } else {
          const errText = await createRes.text();
          console.warn("Supabase create user error:", errText);
        }
      } catch (createErr) {
        console.warn("Could not create user via Admin API:", createErr);
      }
    }

    // 2. Query public.profiles to respect existing database role
    let currentRole: "admin" | "student" = isPreconfiguredAdmin ? "admin" : "student";
    let profileData: any = null;

    try {
      const profRes = await fetch(
        `${supabaseUrl}/rest/v1/profiles?email=eq.${encodeURIComponent(cleanEmail)}&select=*`,
        {
          headers: {
            apikey: serviceKey,
            Authorization: `Bearer ${serviceKey}`,
          },
        }
      );

      if (profRes.ok) {
        const profiles = await profRes.json();
        if (profiles && profiles.length > 0) {
          profileData = profiles[0];
          if (profileData.role === "admin" || profileData.role === "student") {
            currentRole = profileData.role;
          }
        }
      }
    } catch (profErr) {
      console.warn("Could not fetch profile:", profErr);
    }

    // If profile row doesn't exist, create it
    if (!profileData && userId) {
      try {
        const newProfile = {
          id: userId,
          email: cleanEmail,
          full_name: cleanName,
          role: currentRole,
          avatar_url: avatarUrl || null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };

        await fetch(`${supabaseUrl}/rest/v1/profiles`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            apikey: serviceKey,
            Authorization: `Bearer ${serviceKey}`,
            Prefer: "resolution=merge-duplicates",
          },
          body: JSON.stringify(newProfile),
        });

        profileData = newProfile;
      } catch (insertErr) {
        console.warn("Could not insert profile:", insertErr);
      }
    }

    // 3. Generate official Supabase magic link / OTP token hash
    let tokenHash: string | null = null;
    try {
      const linkRes = await fetch(`${supabaseUrl}/auth/v1/admin/generate_link`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: serviceKey,
          Authorization: `Bearer ${serviceKey}`,
        },
        body: JSON.stringify({ type: "magiclink", email: cleanEmail }),
      });

      if (linkRes.ok) {
        const linkData = await linkRes.json();
        tokenHash = linkData.hashed_token || null;
        if (!userId && linkData.id) {
          userId = linkData.id;
        }
      }
    } catch (linkErr) {
      console.warn("Could not generate client magiclink hash:", linkErr);
    }

    // 4. Register single device session
    let sessionId = `sess_${Date.now()}`;
    if (userId) {
      const clientIp = req.headers.get("x-forwarded-for") || req.ip || "unknown";
      const sessionResult = await registerDeviceSession(
        userId,
        cleanEmail,
        userAgent || req.headers.get("user-agent") || "Google Chrome",
        clientIp
      );
      if (sessionResult?.sessionId) {
        sessionId = sessionResult.sessionId;
      }
    }

    const destination = currentRole === "admin" ? "/admin" : "/";

    return NextResponse.json({
      success: true,
      tokenHash,
      sessionId,
      userId,
      user: {
        id: userId || "usr_google_" + Math.abs(cleanEmail.split("").reduce((acc, c) => ((acc << 5) - acc) + c.charCodeAt(0), 0)),
        email: cleanEmail,
        app_metadata: { provider: "google", providers: ["google"] },
        user_metadata: {
          full_name: profileData?.full_name || cleanName,
          avatar_url: avatarUrl || profileData?.avatar_url || null,
          role: currentRole,
        },
      },
      profile: profileData || {
        id: userId,
        email: cleanEmail,
        full_name: cleanName,
        role: currentRole,
        avatar_url: avatarUrl || null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
      role: currentRole,
      destination,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Google authentication service encountered an error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
