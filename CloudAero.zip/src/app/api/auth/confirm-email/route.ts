import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";

export async function POST(req: NextRequest) {
  try {
    const { email } = await req.json();

    if (!email || typeof email !== "string") {
      return NextResponse.json({ error: "Valid email is required" }, { status: 400 });
    }

    // List users using admin API
    const { data, error: listError } = await supabaseAdmin.auth.admin.listUsers();

    if (listError) {
      console.error("Admin listUsers error:", listError);
      return NextResponse.json({ error: listError.message }, { status: 500 });
    }

    const user = data.users.find(
      (u) => u.email?.toLowerCase().trim() === email.toLowerCase().trim()
    );

    if (!user) {
      return NextResponse.json({ error: "User not found in auth catalog" }, { status: 404 });
    }

    // Auto-confirm the user's email
    const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(
      user.id,
      { email_confirm: true }
    );

    if (updateError) {
      console.error("Admin updateUserById error:", updateError);
      return NextResponse.json({ error: updateError.message }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      message: `User ${email} email has been confirmed successfully.`,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to confirm user email";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
