import { NextRequest, NextResponse } from "next/server";
import { generateAndSendLoginOtp } from "@/lib/security/session-manager";

export async function POST(req: NextRequest) {
  try {
    const { email } = await req.json();

    if (!email || typeof email !== "string" || !email.includes("@")) {
      return NextResponse.json({ error: "A valid email address is required" }, { status: 400 });
    }

    const clientIp = req.headers.get("x-forwarded-for") || req.ip || "unknown";
    const result = await generateAndSendLoginOtp(email, clientIp);

    return NextResponse.json({
      success: true,
      message: result.message,
      // devHint is provided so candidate/admin can complete verification instantly during testing
      devHint: result.devHint,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to generate verification code";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
