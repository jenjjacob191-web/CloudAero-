import { NextRequest, NextResponse } from "next/server";
import { verifyLoginOtp, registerDeviceSession } from "@/lib/security/session-manager";

export async function POST(req: NextRequest) {
  try {
    const { email, code, userId, userAgent } = await req.json();

    if (!email || !code) {
      return NextResponse.json({ error: "Email and verification code are required" }, { status: 400 });
    }

    const verification = await verifyLoginOtp(email, code);
    if (!verification.success) {
      return NextResponse.json({ error: verification.error }, { status: 400 });
    }

    // Generate client auth token so Supabase browser session establishes automatically
    let tokenHash: string | null = null;
    let resolvedUserId: string | null = userId || null;

    try {
      const supabaseUrl =
        process.env.NEXT_PUBLIC_SUPABASE_URL || "https://vilaryczczniwiaeezlg.supabase.co";
      const serviceKey =
        process.env.SUPABASE_SERVICE_ROLE_KEY || "sb_secret_SipEf5BBB2DTJE03DrAELw_DhoLprF2";

      const linkRes = await fetch(`${supabaseUrl}/auth/v1/admin/generate_link`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: serviceKey,
          Authorization: `Bearer ${serviceKey}`,
        },
        body: JSON.stringify({ type: "magiclink", email: email.toLowerCase().trim() }),
      });

      if (linkRes.ok) {
        const linkData = await linkRes.json();
        tokenHash = linkData.hashed_token || null;
        if (!resolvedUserId && linkData.id) {
          resolvedUserId = linkData.id;
        }
      }
    } catch (tokenErr) {
      console.warn("Could not generate client magiclink hash:", tokenErr);
    }

    // OTP matched! Register this new device as the SINGLE active session for this user
    let sessionData = { sessionId: `sess_${Date.now()}`, previousSessionTerminated: false };
    if (resolvedUserId) {
      const clientIp = req.headers.get("x-forwarded-for") || req.ip || "unknown";
      sessionData = await registerDeviceSession(
        resolvedUserId,
        email,
        userAgent || req.headers.get("user-agent") || "Web Browser",
        clientIp
      );
    }

    return NextResponse.json({
      success: true,
      message: "Verification successful. Active session established.",
      sessionId: sessionData.sessionId,
      tokenHash,
      userId: resolvedUserId,
      previousSessionTerminated: sessionData.previousSessionTerminated,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Verification failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
