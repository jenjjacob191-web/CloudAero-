import { NextRequest, NextResponse } from "next/server";
import { registerDeviceSession, terminateDeviceSession } from "@/lib/security/session-manager";

export async function POST(req: NextRequest) {
  try {
    const { userId, email, action, userAgent } = await req.json();

    if (action === "terminate") {
      terminateDeviceSession(userId, email);
      return NextResponse.json({ success: true, message: "Session terminated" });
    }

    if (!userId && !email) {
      return NextResponse.json({ error: "userId or email is required" }, { status: 400 });
    }

    const effectiveUserId = userId || email;
    const clientIp = req.headers.get("x-forwarded-for") || req.ip || "unknown";
    const session = await registerDeviceSession(
      effectiveUserId,
      email || effectiveUserId,
      userAgent || req.headers.get("user-agent") || "Web Browser",
      clientIp
    );

    return NextResponse.json({
      success: true,
      sessionId: session.sessionId,
      previousSessionTerminated: session.previousSessionTerminated,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Session registration failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
