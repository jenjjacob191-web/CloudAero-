import { NextRequest, NextResponse } from "next/server";
import { validateDeviceSession } from "@/lib/security/session-manager";

export async function POST(req: NextRequest) {
  try {
    const { userId, sessionId, email } = await req.json();

    if (!userId && !email) {
      return NextResponse.json({ valid: true });
    }

    const check = validateDeviceSession(userId, sessionId, email);

    if (!check.isValid) {
      return NextResponse.json({
        valid: false,
        reason: "CONCURRENT_DEVICE_LOGIN",
        message:
          "Your CloudAero account was signed into on another device. For security and exam license protection, only one device may be active at a time.",
      });
    }

    return NextResponse.json({ valid: true });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Session heartbeat failed";
    return NextResponse.json({ valid: true, warning: message });
  }
}
