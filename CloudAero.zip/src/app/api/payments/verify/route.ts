import { NextRequest, NextResponse } from "next/server";
import { verifyRazorpaySignature } from "@/lib/razorpay";
import { calculateCalendarExpiryDate } from "@/lib/date-utils";
import { supabaseAdmin } from "@/lib/supabase/admin";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { orderId, paymentId, signature, planId, userId, isSimulation } = body;

    if (!orderId || !paymentId || !planId) {
      return NextResponse.json({ error: "Missing required payment verification payload." }, { status: 400 });
    }

    const secret = process.env.RAZORPAY_KEY_SECRET;
    let isValid = false;

    // Security Check: If this is an authentic gateway order (not order_sim_), enforce strict HMAC-SHA256 signature verification
    const isAuthenticRazorpayOrder = orderId.startsWith("order_") && !orderId.startsWith("order_sim_");

    if (isAuthenticRazorpayOrder) {
      if (!secret || !signature || signature === "simulated_hmac_sha256_sig") {
        return NextResponse.json(
          { error: "Payment verification failed. Authentic Razorpay signature required." },
          { status: 400 }
        );
      }
      isValid = verifyRazorpaySignature({
        orderId,
        paymentId,
        signature,
        secret,
      });
    } else if (orderId.startsWith("order_sim_") || isSimulation) {
      // Local development test activation
      isValid = true;
    }

    if (!isValid) {
      return NextResponse.json(
        { error: "Payment verification failed. Invalid gateway signature detected." },
        { status: 400 }
      );
    }

    // Calculate exact calendar expiry date
    const monthsToAdd = planId === "monthly" ? 1 : 6;
    const startDate = new Date();
    const expiryDate = calculateCalendarExpiryDate(startDate, monthsToAdd);

    // Save active subscription in Supabase if valid UUID userId provided
    let subscriptionRecordId = `sub_${Date.now()}`;
    const isUUID = (str?: string) => !!str && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str);

    if (userId && isUUID(userId)) {
      try {
        // Fetch plan id
        const { data: planData } = await (supabaseAdmin.from("subscription_plans") as any)
          .select("id")
          .eq("code", planId)
          .single();

        if (planData) {
          const { data: subData } = await (supabaseAdmin.from("user_subscriptions") as any)
            .insert({
              user_id: userId,
              plan_id: planData.id,
              status: "active",
              starts_at: startDate.toISOString(),
              expires_at: expiryDate.toISOString(),
            })
            .select("id")
            .single();

          if (subData) {
            subscriptionRecordId = subData.id;
          }

          // Update payment record to captured
          await (supabaseAdmin.from("payments") as any)
            .update({
              gateway_payment_id: paymentId,
              gateway_signature: signature || "simulated_sig",
              status: "captured",
              subscription_id: subscriptionRecordId,
              verified_at: new Date().toISOString(),
            })
            .eq("gateway_order_id", orderId);

          // Activate Premium status in user's Supabase profile
          await (supabaseAdmin.from("profiles") as any)
            .update({
              is_premium: true,
              updated_at: new Date().toISOString(),
            })
            .eq("id", userId);
        }
      } catch (dbErr) {
        console.warn("Could not save live database subscription (using local return):", dbErr);
      }
    }

    return NextResponse.json({
      success: true,
      message: "Payment successfully verified and subscription activated.",
      subscription: {
        id: subscriptionRecordId,
        planId,
        status: "active",
        startsAt: startDate.toISOString(),
        expiresAt: expiryDate.toISOString(),
        amountINR: planId === "monthly" ? 300 : 1500,
        paymentId,
      },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Verification error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
