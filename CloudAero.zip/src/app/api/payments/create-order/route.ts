import { NextRequest, NextResponse } from "next/server";
import { createRazorpayOrder } from "@/lib/razorpay";
import { supabaseAdmin } from "@/lib/supabase/admin";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { planId, userId } = body;

    if (!planId || !["monthly", "six_month"].includes(planId)) {
      return NextResponse.json({ error: "Invalid subscription plan specified." }, { status: 400 });
    }

    const priceINR = planId === "monthly" ? 300 : 1500;
    const receiptId = `rcpt_${planId}_${Date.now()}`;

    // Create Razorpay order
    const order = await createRazorpayOrder({
      amountINR: priceINR,
      receiptId,
      notes: {
        planId,
        userId: userId || "guest_student",
      },
    });

    if (!order) {
      return NextResponse.json({ error: "Failed to generate gateway payment order." }, { status: 500 });
    }

    // Attempt to log payment row in Supabase if userId is provided and valid UUID
    const isUUID = (str?: string) => !!str && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str);
    if (userId && isUUID(userId)) {
      try {
        await (supabaseAdmin.from("payments") as any).insert({
          user_id: userId,
          gateway_provider: "razorpay",
          gateway_order_id: order.id,
          amount_inr: priceINR,
          currency: "INR",
          status: "created",
        });
      } catch (dbErr) {
        console.warn("Could not record initial payment log in Supabase:", dbErr);
      }
    }

    return NextResponse.json({
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      keyId: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || "rzp_test_placeholder",
      planId,
      priceINR,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to generate gateway payment order.";
    console.error("Payment order generation error:", err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
