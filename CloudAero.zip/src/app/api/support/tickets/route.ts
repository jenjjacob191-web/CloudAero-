import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export interface SupportTicket {
  id: string;
  source: "contact_form" | "question_dispute";
  ticketCode: string;
  reporterName: string;
  reporterEmail: string;
  reporterLicense?: string;
  category: "general" | "billing" | "syllabus" | "technical" | "exam_dispute";
  subject: string;
  description: string;
  questionCode?: string;
  status: "pending" | "resolved" | "dismissed";
  createdAt: string;
  resolvedAt?: string;
  adminNotes?: string;
}

const TICKETS_FILE = path.join(process.cwd(), "src", "data", "tickets.json");

// Helper to load tickets from file
function loadTicketsFromFile(): SupportTicket[] {
  try {
    if (fs.existsSync(TICKETS_FILE)) {
      const data = fs.readFileSync(TICKETS_FILE, "utf-8");
      const parsed: SupportTicket[] = JSON.parse(data);
      // Strictly purge any legacy demo / mock AI tickets
      const realOnly = parsed.filter(
        (t) =>
          !["tkt_101", "tkt_102", "tkt_103"].includes(t.id) &&
          !["TCK-2026-001", "TCK-2026-002", "TCK-2026-003"].includes(t.ticketCode)
      );
      return realOnly;
    }
  } catch (err) {
    console.error("Error reading tickets file:", err);
  }
  return [];
}

function saveTicketsToFile(tickets: SupportTicket[]) {
  try {
    const dir = path.dirname(TICKETS_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(TICKETS_FILE, JSON.stringify(tickets, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving tickets file:", err);
  }
}

// In-memory persistent registry across requests in Node server runtime
declare global {
  // eslint-disable-next-line no-var
  var __aeroprep_tickets: SupportTicket[] | undefined;
}

// Strictly purge any legacy demo / mock AI tickets from runtime memory
if (globalThis.__aeroprep_tickets) {
  globalThis.__aeroprep_tickets = globalThis.__aeroprep_tickets.filter(
    (t) =>
      !["tkt_101", "tkt_102", "tkt_103"].includes(t.id) &&
      !["TCK-2026-001", "TCK-2026-002", "TCK-2026-003"].includes(t.ticketCode)
  );
}

let ticketStore: SupportTicket[] = globalThis.__aeroprep_tickets || loadTicketsFromFile();
globalThis.__aeroprep_tickets = ticketStore;
saveTicketsToFile(ticketStore);

export async function GET() {
  try {
    // Re-verify file sync
    ticketStore = globalThis.__aeroprep_tickets || loadTicketsFromFile();
    return NextResponse.json({ tickets: ticketStore });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to load tickets";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, email, licenseType, category, subject, message, questionCode, source } = body;

    if (!email || !message) {
      return NextResponse.json({ error: "Email and message are required" }, { status: 400 });
    }

    const newTicket: SupportTicket = {
      id: `tkt_${Date.now()}`,
      source: source || "contact_form",
      ticketCode: `TCK-${new Date().getFullYear()}-${String(ticketStore.length + 1).padStart(3, "0")}`,
      reporterName: name || email.split("@")[0],
      reporterEmail: email.toLowerCase().trim(),
      reporterLicense: licenseType || "CPL",
      category: category || "general",
      subject: subject || "General Pilot Support Inquiry",
      description: message,
      questionCode: questionCode || undefined,
      status: "pending",
      createdAt: new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }),
    };

    ticketStore.unshift(newTicket);
    globalThis.__aeroprep_tickets = ticketStore;
    saveTicketsToFile(ticketStore);

    return NextResponse.json({
      success: true,
      ticket: newTicket,
      message: `Your ticket (${newTicket.ticketCode}) has been registered with Chief Ground Dispatch.`,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to create ticket";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const { id, status, adminNotes } = await req.json();

    if (!id || !status) {
      return NextResponse.json({ error: "Ticket ID and status are required" }, { status: 400 });
    }

    const ticket = ticketStore.find((t) => t.id === id);
    if (!ticket) {
      return NextResponse.json({ error: "Ticket not found" }, { status: 404 });
    }

    ticket.status = status;
    ticket.resolvedAt =
      status === "resolved" ? new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }) : undefined;
    ticket.adminNotes =
      adminNotes || (status === "resolved" ? "Resolved by Administrator." : "Dismissed by Administrator.");

    globalThis.__aeroprep_tickets = ticketStore;
    saveTicketsToFile(ticketStore);

    return NextResponse.json({
      success: true,
      ticket,
      message: `Ticket ${ticket.ticketCode} marked as ${status.toUpperCase()}.`,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to update ticket";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { id, clearAll } = await req.json();

    if (clearAll) {
      ticketStore = [];
      globalThis.__aeroprep_tickets = ticketStore;
      saveTicketsToFile(ticketStore);
      return NextResponse.json({
        success: true,
        message: "All tickets cleared successfully.",
      });
    }

    if (!id) {
      return NextResponse.json({ error: "Ticket ID is required" }, { status: 400 });
    }

    ticketStore = ticketStore.filter((t) => t.id !== id);
    globalThis.__aeroprep_tickets = ticketStore;
    saveTicketsToFile(ticketStore);

    return NextResponse.json({
      success: true,
      message: "Ticket permanently deleted.",
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to delete ticket";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
