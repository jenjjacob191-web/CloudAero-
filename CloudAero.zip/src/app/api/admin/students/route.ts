import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { checkIsAdminEmail } from "@/lib/roles";

export async function GET(req: NextRequest) {
  try {
    const adminEmail = req.headers.get("x-admin-email");
    if (!checkIsAdminEmail(adminEmail)) {
      return NextResponse.json(
        { error: "Access Denied: Administrator authentication required." },
        { status: 403 }
      );
    }

    // 1. Fetch all registered profiles from Supabase
    const { data: profiles, error: profErr } = await (supabaseAdmin.from("profiles") as any)
      .select("*")
      .order("created_at", { ascending: false });

    if (profErr) {
      return NextResponse.json({ error: profErr.message }, { status: 500 });
    }

    // 2. Fetch all subscriptions to match validity
    const { data: subscriptions } = await (supabaseAdmin.from("user_subscriptions") as any)
      .select("*");

    const subsByUserId: Record<string, any> = {};
    if (subscriptions) {
      subscriptions.forEach((s: any) => {
        subsByUserId[s.user_id] = s;
      });
    }

    const students = (profiles || []).map((p: any) => {
      const sub = subsByUserId[p.id];
      const hasActive = sub?.status === "active" || p.is_premium !== false || p.role === "admin";
      let daysLeft = 0;
      if (sub?.expires_at) {
        const diffMs = new Date(sub.expires_at).getTime() - Date.now();
        daysLeft = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
      } else if (hasActive) {
        daysLeft = 365;
      }

      const planName = p.role === "admin"
        ? "Administrator Access"
        : sub?.status === "active"
        ? "Cadet Pass (Razorpay)"
        : p.is_premium !== false
        ? "Cadet Premium Pass (Supabase)"
        : "Free Pilot Account";

      return {
        id: p.id,
        name: p.full_name || p.email?.split("@")[0] || "Cadet Pilot",
        email: p.email,
        role: p.role,
        is_premium: Boolean(hasActive),
        joined: p.created_at ? new Date(p.created_at).toLocaleDateString("en-IN") : "Recent",
        plan: planName,
        starts: sub?.starts_at ? new Date(sub.starts_at).toLocaleDateString("en-IN") : (hasActive ? "Supabase Enabled" : "-"),
        expires: sub?.expires_at ? new Date(sub.expires_at).toLocaleDateString("en-IN") : (hasActive ? "Active" : "-"),
        status: hasActive ? "Active" : "Free Cadet",
        daysLeft,
      };
    });

    return NextResponse.json({ students });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to load students";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
