import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { checkIsAdminEmail } from "@/lib/roles";

export async function POST(request: NextRequest) {
  try {
    const adminEmail = request.headers.get("x-admin-email");
    if (!checkIsAdminEmail(adminEmail)) {
      return NextResponse.json(
        { error: "Access Denied: Administrator authentication required to modify student access." },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { userId, email, isPremium } = body;

    if (!userId && !email) {
      return NextResponse.json({ error: "Missing candidate userId or email" }, { status: 400 });
    }

    const targetPremiumState = Boolean(isPremium);

    let query = (supabaseAdmin.from("profiles") as any).update({
      is_premium: targetPremiumState,
      updated_at: new Date().toISOString(),
    });

    if (userId) {
      query = query.eq("id", userId);
    } else if (email) {
      query = query.eq("email", email.toLowerCase().trim());
    }

    const { error } = await query;
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      message: `Premium access in Supabase successfully ${targetPremiumState ? "granted" : "revoked"}.`,
      isPremium: targetPremiumState,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to update premium state in Supabase";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
