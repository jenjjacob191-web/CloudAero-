import type { Metadata, Viewport } from "next";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { AuthProvider } from "@/lib/auth-context";
import AuthGuard from "@/components/auth/AuthGuard";
import AntiScreenshotGuard from "@/components/security/AntiScreenshotGuard";

export const viewport: Viewport = {
  themeColor: "#0ea5e9",
  width: "device-width",
  initialScale: 1,
};

export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"
  ),
  title: "CloudAero — Aviation Examination Preparation Platform",
  description:
    "India's dedicated DGCA CPL, ATPL, and PPL pilot exam preparation platform. Practice chapter-wise question banks, attempt timed computer-based mock examinations, and track flight theory progress.",
  manifest: "/manifest.json",
  icons: {
    icon: "/images/logo.jpg",
    apple: "/images/logo.jpg",
    shortcut: "/images/logo.jpg",
  },
  openGraph: {
    title: "CloudAero — Aviation Examination Preparation Platform",
    description:
      "India's dedicated DGCA CPL, ATPL, and PPL pilot exam preparation platform. Practice chapter-wise question banks, attempt timed computer-based mock examinations, and track flight theory progress.",
    images: [
      {
        url: "/images/logo.jpg",
        width: 1024,
        height: 1024,
        alt: "CloudAero Official Logo",
      },
    ],
  },
  keywords: [
    "DGCA Exam Preparation",
    "DGCA CPL",
    "DGCA ATPL",
    "Air Regulations",
    "Aviation Meteorology",
    "Air Navigation",
    "Technical General",
    "Pilot Exam Mock Tests India",
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="scroll-smooth bg-white">
      <body className="min-h-screen flex flex-col bg-white text-slate-900 font-sans selection:bg-sky-500/20 selection:text-sky-900">
        <AuthProvider>
          <AntiScreenshotGuard />
          <AuthGuard>
            <Navbar />
            <main className="flex-grow">{children}</main>
            <Footer />
          </AuthGuard>
        </AuthProvider>
      </body>
    </html>
  );
}
