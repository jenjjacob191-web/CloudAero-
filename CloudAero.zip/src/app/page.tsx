"use client";

import React from "react";
import { useAuth } from "@/lib/auth-context";
import AcademyHero from "@/components/home/AcademyHero";
import SubjectModulesShowcase from "@/components/home/SubjectModulesShowcase";
import CoreFeatures from "@/components/home/CoreFeatures";
import ExamReadinessCalculator from "@/components/home/ExamReadinessCalculator";
import ParikshaComparison from "@/components/home/ParikshaComparison";
import PricingPreview from "@/components/home/PricingPreview";
import DashboardPreview from "@/components/home/DashboardPreview";

export default function HomePage() {
  const { user, isAdmin, isLoading } = useAuth();

  return (
    <div className="flex flex-col min-h-screen bg-white">
      {/* 1. Executive Aviator Hero with Live Pariksha Question Simulator */}
      <AcademyHero />

      {/* 2. Official DGCA 5-Subject Command Deck */}
      <SubjectModulesShowcase />

      {/* 3. 4 Core Pillars of Aviation Ground School */}
      <CoreFeatures />

      {/* 4. Interactive Exam Readiness & Pass Probability Calculator */}
      <ExamReadinessCalculator />

      {/* 5. CBT Simulator vs Outdated Coaching Comparison */}
      <ParikshaComparison />

      {/* 6. Transparent Cadet Pricing */}
      <PricingPreview />

      {/* 7. Student Flight Deck Dashboard Preview */}
      <DashboardPreview />
    </div>
  );
}
