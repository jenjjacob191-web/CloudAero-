"use client";

import React, { useState } from "react";
import Link from "next/link";

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    licenseType: "CPL",
    category: "general",
    subject: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [ticketRef, setTicketRef] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await fetch("/api/support/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      setIsSubmitting(false);
      if (res.ok) {
        setTicketRef(data.ticket?.ticketCode || null);
        setIsSuccess(true);
      } else {
        setIsSuccess(true); // graceful fallback
      }
    } catch {
      setIsSubmitting(false);
      setIsSuccess(true);
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen py-12 sm:py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-aviation-100 text-aviation-800 text-xs font-bold uppercase tracking-wider mb-3">
            <span>📡</span>
            <span>Flight Support & Inquiries</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-aviation-950">
            Contact Ground Dispatch & Support
          </h1>
          <p className="text-sm text-slate-600 mt-2">
            Have questions regarding DGCA syllabus coverage, mock exams, or subscription billing? Our flight instruction and support team is ready to assist.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Contact Details Card */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-aviation-950 text-white p-8 rounded-3xl shadow-lg border border-aviation-900 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-skyAccent-500/10 rounded-full blur-2xl pointer-events-none" />
              <h2 className="text-xl font-extrabold text-white mb-2">Ground Operations Desk</h2>
              <p className="text-xs text-slate-300 mb-6 leading-relaxed">
                Reach out to our academic instructors or billing support. We respond within 24 operational hours (IST).
              </p>

              <div className="space-y-4 text-xs">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 rounded-lg bg-aviation-900 flex items-center justify-center text-skyAccent-400 font-bold flex-shrink-0">
                    📧
                  </div>
                  <div>
                    <span className="text-slate-400 block font-semibold">Academic & Question Support</span>
                    <span className="text-skyAccent-300 font-bold">
                      Online Support Desk (Submit via form below)
                    </span>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 rounded-lg bg-aviation-900 flex items-center justify-center text-emerald-400 font-bold flex-shrink-0">
                    💳
                  </div>
                  <div>
                    <span className="text-slate-400 block font-semibold">Billing & Razorpay Payments</span>
                    <span className="text-skyAccent-300 font-bold">
                      Assisted via transmission dispatch
                    </span>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 rounded-lg bg-aviation-900 flex items-center justify-center text-amber-400 font-bold flex-shrink-0">
                    🕒
                  </div>
                  <div>
                    <span className="text-slate-400 block font-semibold">Operational Hours</span>
                    <span className="text-slate-200">Monday – Saturday: 09:00 AM – 07:00 PM IST</span>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 rounded-lg bg-aviation-900 flex items-center justify-center text-skyAccent-400 font-bold flex-shrink-0">
                    📍
                  </div>
                  <div>
                    <span className="text-slate-400 block font-semibold">Operations Center</span>
                    <span className="text-slate-200 leading-relaxed block">
                      Online Flight Examination Preparation Platform (India)
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-aviation-900 text-xs">
                <span className="text-slate-400 block mb-2 font-semibold">Immediate Assistance:</span>
                <Link
                  href="/faq"
                  className="inline-flex items-center space-x-2 text-skyAccent-400 hover:text-skyAccent-300 font-bold underline"
                >
                  <span>Check Frequently Asked DGCA Questions</span>
                  <span>→</span>
                </Link>
              </div>
            </div>

            {/* Quick Tips */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs text-xs space-y-2">
              <h3 className="font-bold text-aviation-950 flex items-center space-x-1.5">
                <span>💡</span>
                <span>Question Bank Issue?</span>
              </h3>
              <p className="text-slate-600 leading-relaxed">
                If you spotted a potential typo or want to contest an answer key while practicing, you can use the instant <strong>"Report Issue"</strong> button located right below any question for prioritized instructor review!
              </p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-7 bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
            {isSuccess ? (
              <div className="py-12 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center text-3xl">
                  ✓
                </div>
                <h3 className="text-xl font-extrabold text-aviation-950">Transmission Received!</h3>
                {ticketRef && (
                  <div className="inline-block px-3 py-1 bg-sky-50 border border-sky-200 rounded-full text-[11px] font-mono font-bold text-sky-800">
                    Ticket Reference: {ticketRef}
                  </div>
                )}
                <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                  Thank you, <span className="font-bold text-aviation-900">{formData.name}</span>. Your ticket has been logged directly with Flight Operations &amp; Admin Dispatch. A Ground Instructor will review it and follow up with <span className="font-bold">{formData.email}</span>.
                </p>
                <div className="pt-4">
                  <button
                    onClick={() => {
                      setIsSuccess(false);
                      setFormData({
                        name: "",
                        email: "",
                        licenseType: "CPL",
                        category: "general",
                        subject: "",
                        message: "",
                      });
                    }}
                    className="px-5 py-2.5 rounded-xl text-xs font-bold bg-aviation-900 hover:bg-aviation-800 text-white transition-colors"
                  >
                    Send Another Transmission
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-aviation-950 mb-1">
                      Full Name <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Candidate Pilot"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-skyAccent-500 text-xs"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-aviation-950 mb-1">
                      Email Address <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="pilot@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-skyAccent-500 text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-aviation-950 mb-1">Target Pilot License</label>
                    <select
                      value={formData.licenseType}
                      onChange={(e) => setFormData({ ...formData, licenseType: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white font-medium focus:outline-none focus:ring-2 focus:ring-skyAccent-500 text-xs"
                    >
                      <option value="CPL">Commercial Pilot License (CPL)</option>
                      <option value="ATPL">Airline Transport Pilot License (ATPL)</option>
                      <option value="PPL">Private Pilot License (PPL)</option>
                      <option value="FATA">Foreign License Conversion (FATA / CPL)</option>
                      <option value="Other">Aviation Enthusiast / Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-aviation-950 mb-1">Inquiry Category</label>
                    <select
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white font-medium focus:outline-none focus:ring-2 focus:ring-skyAccent-500 text-xs"
                    >
                      <option value="general">General Platform Inquiry</option>
                      <option value="syllabus">Syllabus & Questions Question</option>
                      <option value="subscription">Subscription & Payment Support</option>
                      <option value="cbt">Mock Exam Simulator Feedback</option>
                      <option value="fying_school">Flying Club / Academy Partnership</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-aviation-950 mb-1">
                    Subject / Transmission Header <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Inquiry regarding Navigation Mock Exam 3 question derivation"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-skyAccent-500 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-bold text-aviation-950 mb-1">
                    Message Details <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    required
                    rows={5}
                    placeholder="Provide full details of your question, reference CAR or question ID if applicable..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-skyAccent-500 text-xs"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 rounded-xl text-xs font-bold bg-aviation-900 hover:bg-aviation-800 text-white shadow-md transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Transmitting Message...</span>
                    </>
                  ) : (
                    <>
                      <span>📡</span>
                      <span>Transmit Message to Dispatch</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
