"use client";

import React, { useState } from "react";
import Link from "next/link";
import { DETAILED_SUBJECTS } from "@/data/syllabusData";

interface BankQuestion {
  id: string;
  subjectName: string;
  chapterTitle: string;
  chapterSlug: string;
  questionText: string;
  options: { id: string; text: string; isCorrect: boolean }[];
  explanation: string;
  difficulty: "Easy" | "Medium" | "Hard";
  source: string;
  year?: number;
  tags: string[];
}

// All sample/fake questions cleared. Real questions will be uploaded by administrators.
const SAMPLE_BANK_QUESTIONS: BankQuestion[] = [];

export default function QuestionBankPage() {
  const [practiceMode, setPracticeMode] = useState<string>("chapter-wise");
  const [selectedSubject, setSelectedSubject] = useState<string>("All");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [revealedExplanations, setRevealedExplanations] = useState<Record<string, boolean>>({});

  const modes = [
    { id: "chapter-wise", label: "Chapter-Wise Practice", icon: "📖" },
    { id: "subject-wise", label: "Subject-Wise Drills", icon: "🌐" },
    { id: "random", label: "Random Drill (50 Qs)", icon: "🎲" },
    { id: "bookmarks", label: "Bookmarked Questions", icon: "🔖" },
    { id: "unattempted", label: "Unattempted Questions", icon: "⚡" },
  ];

  const toggleExplanation = (questionId: string) => {
    setRevealedExplanations((prev) => ({
      ...prev,
      [questionId]: !prev[questionId],
    }));
  };

  const filteredQuestions = SAMPLE_BANK_QUESTIONS.filter((q) => {
    const matchesSubject = selectedSubject === "All" || q.subjectName === selectedSubject;
    const matchesDifficulty = selectedDifficulty === "All" || q.difficulty === selectedDifficulty;
    const matchesSearch =
      q.questionText.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.chapterTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesSubject && matchesDifficulty && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-slate-50/70 pb-20">
      {/* Banner */}
      <section className="bg-aviation-950 text-white py-12 px-4 sm:px-6 lg:px-8 border-b border-aviation-900">
        <div className="max-w-7xl mx-auto">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-skyAccent-300 text-xs font-bold uppercase tracking-wider mb-3">
            <span>DGCA Question Bank & Practice Drills</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight font-sans">
            Interactive Aviation Question Bank
          </h1>
          <p className="mt-2 text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
            Practice topic-by-topic with detailed mathematical derivations, regulatory references, and instant answer rationales.
          </p>

          {/* Practice Mode Selector Tabs */}
          <div className="mt-6 flex flex-wrap gap-2">
            {modes.map((mode) => (
              <button
                key={mode.id}
                type="button"
                onClick={() => setPracticeMode(mode.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
                  practiceMode === mode.id
                    ? "bg-skyAccent-400 text-aviation-950 shadow-md shadow-skyAccent-400/20"
                    : "bg-aviation-900 hover:bg-aviation-800 text-slate-300 border border-aviation-800"
                }`}
              >
                <span>{mode.icon}</span>
                <span>{mode.label}</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6">
        {/* Filters Card */}
        <div className="bg-white rounded-2xl border border-aviation-100 p-5 shadow-aviation flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Keyword Search */}
          <div className="relative w-full md:w-80">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by formula, rule, or concept..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-aviation-800"
            />
            <svg
              className="w-4 h-4 text-slate-400 absolute left-3 top-3"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            {/* Subject Selector */}
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-aviation-800"
            >
              <option value="All">All Subjects</option>
              {DETAILED_SUBJECTS.map((s) => (
                <option key={s.id} value={s.name}>
                  {s.name}
                </option>
              ))}
            </select>

            {/* Difficulty Selector */}
            <select
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
              className="px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-aviation-800"
            >
              <option value="All">All Difficulties</option>
              <option value="Easy">Easy</option>
              <option value="Medium">Medium</option>
              <option value="Hard">Hard</option>
            </select>

            <span className="text-xs text-slate-400 font-medium">
              {filteredQuestions.length} Questions Displayed
            </span>
          </div>
        </div>

        {/* Questions Stream */}
        <div className="mt-8 space-y-6">
          {filteredQuestions.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-sm max-w-2xl mx-auto space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-skyAccent-50 text-skyAccent-600 border border-skyAccent-200 flex items-center justify-center text-3xl mx-auto">
                📚
              </div>
              <h3 className="text-xl font-bold text-aviation-900">DGCA Question Bank Under Preparation</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                The question bank has been cleared for administrative loading. Authentic syllabus questions will appear here once added or imported via the Admin Console.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <Link
                  href="/subjects"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 transition shadow-sm"
                >
                  Browse Syllabus Outline
                </Link>
                <Link
                  href="/admin/questions"
                  className="px-5 py-2.5 rounded-xl text-xs font-semibold text-aviation-800 bg-aviation-50 hover:bg-aviation-100 border border-aviation-200 transition"
                >
                  Upload Questions (Admin Deck)
                </Link>
              </div>
            </div>
          ) : (
            filteredQuestions.map((q, idx) => {
              const isExplRevealed = !!revealedExplanations[q.id];
              return (
                <div
                  key={q.id}
                  className="bg-white rounded-2xl border border-aviation-100 p-6 sm:p-7 shadow-sm hover:border-aviation-200 transition-all"
                >
                  {/* Top Badges */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                        #{idx + 1}
                      </span>
                      <span className="text-xs font-bold px-2.5 py-0.5 rounded bg-aviation-50 text-aviation-800 border border-aviation-100">
                        {q.subjectName}
                      </span>
                      <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                        • {q.chapterTitle}
                      </span>
                    </div>

                    <div className="flex items-center space-x-2">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                          q.difficulty === "Easy"
                            ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                            : q.difficulty === "Medium"
                            ? "bg-amber-50 text-amber-700 border border-amber-200"
                            : "bg-red-50 text-red-700 border border-red-200"
                        }`}
                      >
                        {q.difficulty}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono bg-slate-50 px-2 py-0.5 rounded border border-slate-100">
                        {q.source}
                      </span>
                    </div>
                  </div>

                  {/* Question Text */}
                  <h3 className="text-base sm:text-lg font-bold text-aviation-900 leading-snug">
                    {q.questionText}
                  </h3>

                  {/* Answer Options */}
                  <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-3">
                    {q.options.map((opt, oIdx) => (
                      <div
                        key={opt.id}
                        className={`p-3.5 rounded-xl border text-xs flex items-center space-x-3 transition-colors ${
                          isExplRevealed && opt.isCorrect
                            ? "bg-emerald-50 border-emerald-300 text-emerald-900 font-bold"
                            : "bg-slate-50/70 border-slate-200/80 text-slate-700"
                        }`}
                      >
                        <span className="w-5 h-5 rounded-full bg-white border border-slate-300 flex items-center justify-center font-bold text-[10px] text-slate-600 flex-shrink-0">
                          {String.fromCharCode(65 + oIdx)}
                        </span>
                        <span className="leading-relaxed">{opt.text}</span>
                      </div>
                    ))}
                  </div>

                  {/* Explanation Accordion & Practice CTA */}
                  <div className="mt-5 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={() => toggleExplanation(q.id)}
                        className="text-xs font-bold text-skyAccent-700 hover:text-aviation-900 flex items-center space-x-1"
                      >
                        <span>{isExplRevealed ? "Hide Explanation" : "Reveal Answer & Explanation"}</span>
                        <svg
                          className={`w-3.5 h-3.5 transform transition-transform ${isExplRevealed ? "rotate-180" : ""}`}
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                      </button>
                    </div>

                    <div className="flex items-center space-x-3">
                      <Link
                        href={`/practice/${q.chapterSlug}`}
                        className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 transition-colors"
                      >
                        Practice Entire Chapter Drill →
                      </Link>
                    </div>
                  </div>

                  {/* Detailed Explanation Box */}
                  {isExplRevealed && (
                    <div className="mt-4 p-4 rounded-xl bg-aviation-50 border border-aviation-200 text-xs text-aviation-950 leading-relaxed animate-fadeIn">
                      <div className="flex items-center space-x-2 text-aviation-900 font-bold mb-1.5">
                        <svg className="w-4 h-4 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>Detailed Answer Explanation:</span>
                      </div>
                      <p>{q.explanation}</p>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </main>
    </div>
  );
}
