"use client";

import React, { useState } from "react";
import Link from "next/link";

interface FAQItem {
  question: string;
  answer: string;
  category: "exam" | "platform" | "billing" | "syllabus";
}

const FAQ_LIST: FAQItem[] = [
  {
    category: "exam",
    question: "What is the qualifying passing mark for DGCA pilot theory examinations?",
    answer:
      "Under DGCA guidelines (Rule 42 of Aircraft Rules 1937 and Civil Aviation Requirements), candidate pilots must achieve a minimum of 70% in each subject to pass. A score of 69% or below constitutes a fail, requiring re-examination in the subsequent session.",
  },
  {
    category: "exam",
    question: "Does DGCA have negative marking in pilot license computer-based exams?",
    answer:
      "Most DGCA CPL exams have historically operated without negative marking (1 mark per correct answer). However, specific sessions or specialized papers (such as ATPL or technical type ratings) may announce specific marking structures. CloudAero's mock exam builder allows you to toggle negative marking on or off so you are prepared for all examination policies.",
  },
  {
    category: "exam",
    question: "How often are DGCA theoretical knowledge examinations conducted?",
    answer:
      "DGCA conducts regular quarterly examinations across Indian test centers (typically in March, June, September, and December), in addition to On-Demand Examinations (OLABS) conducted at regional centers throughout the year via the DGCA Pariksha examination portal.",
  },
  {
    category: "syllabus",
    question: "Which subjects are required for Commercial Pilot License (CPL) in India?",
    answer:
      "For Indian CPL issue, students must clear five major theory examinations: 1) Air Regulations, 2) Aviation Meteorology, 3) Air Navigation, 4) Technical General (aircraft, engines, instruments & systems), and 5) Technical Specific (for the specific training aircraft flown, e.g., Cessna 172 or DA42). Foreign license conversion candidates (FATA) typically appear for Air Regulations and Aviation Meteorology (Composite).",
  },
  {
    category: "syllabus",
    question: "How frequently is the CloudAero question bank updated?",
    answer:
      "Our team of flight instructors and ground school specialists continually reviews Civil Aviation Requirements (CAR), Aeronautical Information Publications (AIP India), circulars, and student exam debriefs. When regulations update (such as transition altitude defaults, FDTL norms, or airspace classifications), our questions and explanations are promptly revised.",
  },
  {
    category: "platform",
    question: "How closely does the CloudAero CBT Mock Exam simulator mirror the real exam?",
    answer:
      "Our simulator is specifically built to reproduce the DGCA computer-based testing interface: strict countdown timer, question status palette (Answered in green, Marked for Review in amber, Not Visited in slate), quick question jumping, clear response options, and automatic submission when time expires.",
  },
  {
    category: "platform",
    question: "Can I use CloudAero on my iPad, tablet, or smartphone?",
    answer:
      "Yes! CloudAero is 100% responsive and optimized for mobile devices, iPads, tablets, and desktop computers. You can practice chapter questions during airport downtime or layovers, and take full CBT mock exams on your laptop or tablet.",
  },
  {
    category: "platform",
    question: "Can I bookmark questions or re-attempt only the questions I got wrong?",
    answer:
      "Yes. The practice engine allows you to bookmark challenging questions with one click. Your personal Student Dashboard tracks all attempted questions, allowing you to launch targeted drill sessions specifically focusing on bookmarked or incorrectly answered questions.",
  },
  {
    category: "billing",
    question: "What is included in the ₹300 Monthly and ₹1,500 Six-Month Pass?",
    answer:
      "Both subscription tiers grant full, unlimited access to all DGCA subjects, all 24+ chapters, thousands of high-yield practice questions, formula derivations, and all subject-wise CBT mock exams with unlimited attempts. The Six-Month Pass saves 17% and includes priority academic support.",
  },
  {
    category: "billing",
    question: "Which payment methods are supported in India?",
    answer:
      "We integrate with Razorpay, supporting all Indian payment methods including UPI (Google Pay, PhonePe, Paytm, BHIM), Indian credit and debit cards (RuPay, Visa, Mastercard), Netbanking across 50+ Indian banks, and digital wallets.",
  },
  {
    category: "billing",
    question: "Is CloudAero officially affiliated with the Directorate General of Civil Aviation?",
    answer:
      "No. CloudAero is an independent academic preparation and training resource developed by aviation professionals. It is not affiliated with, endorsed by, or sponsored by the Directorate General of Civil Aviation (DGCA), Government of India. Official regulatory notices, exam notifications, and admit cards must be accessed directly via dgca.gov.in and pariksha.dgca.gov.in.",
  },
];

export default function FAQPage() {
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredFaqs = FAQ_LIST.filter((faq) => {
    const matchCat = activeCategory === "all" || faq.category === activeCategory;
    const q = searchQuery.toLowerCase();
    const matchSearch =
      !searchQuery ||
      faq.question.toLowerCase().includes(q) ||
      faq.answer.toLowerCase().includes(q);
    return matchCat && matchSearch;
  });

  return (
    <div className="bg-slate-50 min-h-screen py-12 sm:py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-aviation-100 text-aviation-800 text-xs font-bold uppercase tracking-wider mb-3">
            <span>❓</span>
            <span>Flight Briefing & FAQs</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-aviation-950">
            Frequently Asked Questions
          </h1>
          <p className="text-sm text-slate-600 mt-2 max-w-xl mx-auto">
            Everything you need to know about DGCA CPL/ATPL exam formats, passing criteria, syllabus topics, and CloudAero features.
          </p>
        </div>

        {/* Search Bar */}
        <div className="relative max-w-lg mx-auto mb-8">
          <span className="absolute left-4 top-3 text-slate-400 text-sm">🔍</span>
          <input
            type="text"
            placeholder="Search questions (e.g. passing mark, negative marking, navigation)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-2xl border border-slate-200 bg-white text-xs font-medium focus:outline-none focus:ring-2 focus:ring-skyAccent-500 shadow-xs"
          />
        </div>

        {/* Categories */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
          {[
            { id: "all", label: "All Questions" },
            { id: "exam", label: "DGCA Exam Rules" },
            { id: "syllabus", label: "Syllabus & Subjects" },
            { id: "platform", label: "Mock CBT Simulator" },
            { id: "billing", label: "Subscriptions & Pricing" },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeCategory === cat.id
                  ? "bg-aviation-900 text-white shadow-sm"
                  : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* FAQ Accordion */}
        <div className="space-y-3">
          {filteredFaqs.length === 0 ? (
            <div className="bg-white p-10 rounded-2xl border border-slate-200 text-center">
              <p className="text-xs text-slate-500">No matching questions found for "{searchQuery}".</p>
              <button
                onClick={() => {
                  setSearchQuery("");
                  setActiveCategory("all");
                }}
                className="mt-3 text-xs font-bold text-skyAccent-600 hover:underline"
              >
                Reset Search Filters
              </button>
            </div>
          ) : (
            filteredFaqs.map((faq, index) => {
              const isOpen = openIndex === index;
              return (
                <div
                  key={index}
                  className={`bg-white rounded-2xl border transition-all overflow-hidden ${
                    isOpen ? "border-skyAccent-300 shadow-sm" : "border-slate-200"
                  }`}
                >
                  <button
                    onClick={() => setOpenIndex(isOpen ? null : index)}
                    className="w-full p-5 text-left flex items-center justify-between space-x-4 focus:outline-none"
                  >
                    <span className="font-bold text-aviation-950 text-sm">{faq.question}</span>
                    <span
                      className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs transition-transform flex-shrink-0 ${
                        isOpen ? "bg-aviation-900 text-white rotate-180" : "bg-slate-100 text-slate-500"
                      }`}
                    >
                      ▼
                    </span>
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 border-t border-slate-100 text-xs text-slate-600 leading-relaxed">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Still have questions? */}
        <div className="mt-12 bg-aviation-950 text-white p-8 rounded-3xl text-center space-y-3">
          <h3 className="text-base font-bold">Have a specific aviation exam query?</h3>
          <p className="text-xs text-slate-300 max-w-md mx-auto">
            Our flight instructors and ground dispatch are here to clarify any doubt regarding DGCA requirements.
          </p>
          <div className="pt-2">
            <Link
              href="/contact"
              className="inline-block px-5 py-2.5 rounded-xl text-xs font-bold bg-skyAccent-400 hover:bg-skyAccent-300 text-aviation-950 transition-colors shadow-sm"
            >
              Contact Ground Dispatch
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
