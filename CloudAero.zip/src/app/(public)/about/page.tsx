import React from "react";
import Link from "next/link";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "About CloudAero — Indian Pilot Exam Preparation Platform",
  description:
    "Learn about CloudAero, India's premier aviation exam platform built to empower student pilots preparing for DGCA CPL, ATPL, and PPL pilot examinations.",
};

export default function AboutPage() {
  const milestones = [
    {
      year: "2024",
      title: "Foundation & Flight Training Research",
      description:
        "Started by a team of active airline pilots, flight instructors (CFI/GI), and software engineers who noticed the lack of a standardized, modern CBT preparation platform for Indian pilot exams.",
    },
    {
      year: "2025",
      title: "Syllabus Harmonization & Question Bank Verification",
      description:
        "Mapped 10,000+ questions across Air Regulations, Meteorology, Navigation, Technical General, and Technical Specific directly to current DGCA CARs, AIP India, and ICAO annexes.",
    },
    {
      year: "2026",
      title: "CloudAero Launch",
      description:
        "Rolled out India's most realistic timed Computer-Based Testing (CBT) mock exam engine, real-time analytics, and instant feedback chapter drills with affordable student pricing.",
    },
  ];

  const values = [
    {
      icon: "🎯",
      title: "Exam Fidelity",
      description:
        "DGCA online examinations follow a strict CBT interface with tight time limits and negative marking rules. Our mock exam simulator mirrors this environment exactly.",
    },
    {
      icon: "📐",
      title: "Rigorous Derivations",
      description:
        "No rote learning without comprehension. Every navigation calculation, altimetry formula, and engine concept is backed by detailed step-by-step mathematical derivations.",
    },
    {
      icon: "📜",
      title: "Regulatory Accuracy",
      description:
        "Questions are continuously cross-checked against DGCA Civil Aviation Requirements (CARs), AIP India amendments, and ICAO standards to prevent outdated learning.",
    },
    {
      icon: "🇮🇳",
      title: "Affordable Indian Pricing",
      description:
        "High-quality pilot preparation should not be an expensive barrier. Transparent pricing at ₹300/month or ₹1,500/6-months with zero hidden fees.",
    },
  ];

  const subjects = [
    { name: "Air Regulations", code: "REG", desc: "Aircraft Rules 1937, CARs, ICAO Annexes, Airspace Classification, ATC procedures." },
    { name: "Aviation Meteorology", code: "MET", desc: "Atmospheric dynamics, altimetry, pressure systems, jet streams, monsoon, METAR/TAF." },
    { name: "Air Navigation", code: "NAV", desc: "1 in 60 rule, triangle of velocities, dead reckoning, radio aids, GNSS, charts." },
    { name: "Technical General", code: "TECH-GEN", desc: "Airframes, piston/gas turbine engines, hydraulics, electrics, flight instruments." },
    { name: "Technical Specific", code: "TECH-SPEC", desc: "Type-specific systems for training aircraft like Cessna 172R, Diamond DA40/42, Piper Seneca." },
  ];

  return (
    <div className="bg-slate-50 min-h-screen">
      {/* Hero Section */}
      <section className="bg-aviation-950 text-white py-16 sm:py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-skyAccent-500/20 via-aviation-950 to-aviation-950 pointer-events-none" />
        <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10 text-center">
          <div className="inline-flex items-center space-x-2 bg-aviation-900/80 border border-skyAccent-400/30 px-3.5 py-1.5 rounded-full text-xs font-semibold text-skyAccent-300 mb-6">
            <span>✈️</span>
            <span>Your Flight Deck to DGCA Success</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight max-w-3xl mx-auto leading-tight">
            Engineered for Aspiring Aviators. Built by Flight Instructors.
          </h1>
          <p className="mt-4 text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            CloudAero is India's dedicated aviation theory platform created to bridge the gap between heavy textbooks and high-pressure DGCA computer-based examinations.
          </p>
        </div>
      </section>

      {/* Mission & Purpose */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <span className="text-xs font-bold text-skyAccent-600 uppercase tracking-wider block mb-2">
              Our Flight Plan
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-aviation-950 leading-snug">
              Making Pilot Ground School Intuitive, Accessible, and Verifiably Accurate
            </h2>
            <p className="mt-4 text-sm text-slate-600 leading-relaxed">
              Clearing DGCA theory examinations (CPL / ATPL) is one of the most demanding phases of a commercial pilot's journey in India. Students often juggle flight hours, ground school lectures, and disjointed study materials while facing rigorous examinations with 70% passing criteria.
            </p>
            <p className="mt-3 text-sm text-slate-600 leading-relaxed">
              CloudAero was established to solve this challenge. By consolidating the DGCA syllabus into organized chapters, high-yield practice drills, and realistic CBT mock examinations, we provide candidate pilots with the exact tools needed to clear all theory papers on their first attempt.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link
                href="/subjects"
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-aviation-900 hover:bg-aviation-800 text-white shadow-md transition-colors"
              >
                Browse Syllabus
              </Link>
              <Link
                href="/mock-exams"
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-white hover:bg-slate-100 text-aviation-950 border border-slate-300 transition-colors"
              >
                Explore CBT Mock Exams
              </Link>
            </div>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm relative">
            <div className="space-y-4">
              <div className="flex items-center space-x-3 pb-4 border-b border-slate-100">
                <div className="w-10 h-10 rounded-xl bg-aviation-50 text-aviation-900 flex items-center justify-center font-bold text-lg">
                  📋
                </div>
                <div>
                  <h4 className="text-sm font-bold text-aviation-950">Comprehensive Syllabus Coverage</h4>
                  <p className="text-xs text-slate-500">DGCA CPL, ATPL, and PPL theoretical knowledge</p>
                </div>
              </div>
              <div className="flex items-center space-x-3 pb-4 border-b border-slate-100">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center font-bold text-lg">
                  ⏱️
                </div>
                <div>
                  <h4 className="text-sm font-bold text-aviation-950">Realistic CBT Exam Simulator</h4>
                  <p className="text-xs text-slate-500">Exact countdown timers, palette indicators, and auto-submit</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-skyAccent-50 text-skyAccent-700 flex items-center justify-center font-bold text-lg">
                  💡
                </div>
                <div>
                  <h4 className="text-sm font-bold text-aviation-950">Explanations & Memory Aids</h4>
                  <p className="text-xs text-slate-500">Aviation mnemonics, formula breakdowns, and CAR citations</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="bg-white border-y border-slate-200 py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold text-skyAccent-600 uppercase tracking-wider block mb-2">
              Our Core Principles
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-aviation-950">
              Why Indian Student Pilots Trust CloudAero
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((v, i) => (
              <div key={i} className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-skyAccent-300 transition-all">
                <div className="text-3xl mb-3">{v.icon}</div>
                <h3 className="text-base font-bold text-aviation-950 mb-2">{v.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{v.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Journey Timeline */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold text-skyAccent-600 uppercase tracking-wider block mb-2">
            Development Milestones
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-aviation-950">
            From Cockpit Briefing to Full Digital Flight Deck
          </h2>
        </div>

        <div className="space-y-6 max-w-3xl mx-auto">
          {milestones.map((m, idx) => (
            <div key={idx} className="flex items-start space-x-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
              <span className="px-3 py-1 rounded-lg text-xs font-bold bg-aviation-900 text-skyAccent-300 flex-shrink-0">
                {m.year}
              </span>
              <div>
                <h4 className="text-sm font-bold text-aviation-950">{m.title}</h4>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">{m.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Exam Subjects We Support */}
      <section className="bg-aviation-900 text-white py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <h2 className="text-2xl sm:text-3xl font-extrabold">Complete DGCA Syllabus Coverage</h2>
            <p className="text-xs text-slate-300 mt-2">
              Structured strictly in accordance with current DGCA examination guidelines and CAR regulations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {subjects.map((s, idx) => (
              <div key={idx} className="bg-aviation-950 p-5 rounded-2xl border border-aviation-800">
                <span className="font-mono text-[10px] text-skyAccent-400 bg-aviation-900 px-2 py-0.5 rounded font-bold">
                  {s.code}
                </span>
                <h3 className="text-sm font-bold text-white mt-2 mb-1">{s.name}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Official Disclaimer Banner */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 py-12">
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6 text-xs text-amber-950">
          <div className="flex items-center space-x-2 font-bold text-amber-900 mb-2">
            <span>⚠️</span>
            <span className="uppercase tracking-wider">Independent Preparation Platform Notice</span>
          </div>
          <p className="leading-relaxed">
            CloudAero is an independent educational training platform developed to assist students in preparing for Indian aviation theory exams. CloudAero is not affiliated with, associated with, authorized by, endorsed by, or in any way officially connected with the Directorate General of Civil Aviation (DGCA), Government of India, or any of its subsidiaries or affiliates. All official exam schedules, results, and regulatory issuances must be verified at the official DGCA portal (<a href="https://dgca.gov.in" target="_blank" rel="noreferrer" className="underline font-semibold">dgca.gov.in</a>).
          </p>
        </div>
      </section>
    </div>
  );
}
