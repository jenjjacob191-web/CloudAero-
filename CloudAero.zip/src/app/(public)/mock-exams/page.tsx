"use client";

import React, { useState } from "react";
import Link from "next/link";
import { MOCK_EXAMS_CATALOG } from "@/data/mockExamsData";
import { useAuth } from "@/lib/auth-context";

export default function MockExamsCatalogPage() {
  const { isPremium } = useAuth();
  const hasActiveSubscription = isPremium;

  const [selectedSubject, setSelectedSubject] = useState<string>("All");

  const subjects = ["All", "Aviation Meteorology", "Air Navigation", "Air Regulations", "Technical General"];

  const filteredExams = MOCK_EXAMS_CATALOG.filter((exam) => {
    return selectedSubject === "All" || exam.subjectName === selectedSubject;
  });

  return (
    <div className="min-h-screen bg-slate-50/70 pb-20">
      {/* Banner */}
      <section className="bg-aviation-950 text-white py-14 px-4 sm:px-6 lg:px-8 border-b border-aviation-900">
        <div className="max-w-7xl mx-auto">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-skyAccent-300 text-xs font-bold uppercase tracking-wider mb-4">
            <span>DGCA Computer-Based Testing (CBT) Simulator</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight font-sans">
            Subject-Wise Mock Examinations
          </h1>
          <p className="mt-3 text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
            Replicate authentic DGCA examination room conditions. Test yourself under strict countdown timers, negative marking protocols, and question review palettes.
          </p>

          {/* Filter Pills */}
          <div className="mt-8 flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
            <div className="flex flex-wrap gap-2">
              {subjects.map((sub) => (
                <button
                  key={sub}
                  type="button"
                  onClick={() => setSelectedSubject(sub)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                    selectedSubject === sub
                      ? "bg-skyAccent-400 text-aviation-950 shadow-md shadow-skyAccent-400/20"
                      : "bg-aviation-900 hover:bg-aviation-800 text-slate-300 border border-aviation-800"
                  }`}
                >
                  {sub}
                </button>
              ))}
            </div>

            <div className="flex items-center space-x-2 bg-aviation-900 px-4 py-2 rounded-xl border border-aviation-800">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-bold text-emerald-300">
                ✓ All CBT Mock Exams Unlocked
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredExams.map((exam) => (
            <div
              key={exam.id}
              className={`rounded-3xl p-8 bg-white border flex flex-col justify-between transition-all duration-300 shadow-aviation hover:shadow-aviation-hover ${
                exam.isPremium ? "border-slate-200 hover:border-amber-400" : "border-skyAccent-200 hover:border-skyAccent-400"
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-slate-100 text-slate-700">
                    {exam.subjectName}
                  </span>

                  <span className="inline-flex items-center space-x-1 text-xs font-bold text-amber-800 bg-amber-50 border border-amber-200 px-3 py-1 rounded-full">
                    <svg className="w-3.5 h-3.5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                    Premium Pass
                  </span>
                </div>

                <h3 className="text-xl font-bold text-aviation-900 mb-2 leading-snug">
                  {exam.title}
                </h3>
                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed mb-6">
                  {exam.description}
                </p>

                {/* Exam Parameters Grid */}
                <div className="grid grid-cols-2 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-100 text-xs mb-8">
                  <div>
                    <span className="text-slate-400 block font-medium">Duration</span>
                    <span className="font-bold text-aviation-900">{exam.durationMinutes} Minutes</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-medium">Questions</span>
                    <span className="font-bold text-aviation-900">
                      {exam.questions.length > 0 ? `${exam.questions.length} MCQs` : "Paper In Preparation"}
                    </span>
                  </div>
                  <div className="pt-2 border-t border-slate-200/60">
                    <span className="text-slate-400 block font-medium">Passing Score</span>
                    <span className="font-bold text-emerald-600">{exam.passingPercentage}% (DGCA Norm)</span>
                  </div>
                  <div className="pt-2 border-t border-slate-200/60">
                    <span className="text-slate-400 block font-medium">Negative Marking</span>
                    <span className="font-semibold text-slate-700">
                      {exam.negativeMarking > 0 ? `-${exam.negativeMarking} Marks` : "Nil"}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div>
                {hasActiveSubscription ? (
                  <Link
                    href={`/mock-exams/${exam.id}/instructions`}
                    className="w-full inline-flex items-center justify-center py-3.5 px-4 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-sm transition-all"
                  >
                    <span>Enter CBT Examination Room</span>
                    <svg className="w-4 h-4 ml-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                    </svg>
                  </Link>
                ) : (
                  <Link
                    href="/pricing"
                    className="w-full inline-flex items-center justify-center py-3.5 px-4 rounded-xl text-xs font-bold text-amber-950 bg-amber-100 hover:bg-amber-200 border border-amber-300 transition-colors shadow-sm"
                  >
                    <svg className="w-4 h-4 mr-1.5 text-amber-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                    Unlock with Premium Pass (₹300)
                  </Link>
                )}
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
