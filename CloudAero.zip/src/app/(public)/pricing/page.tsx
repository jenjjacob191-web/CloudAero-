"use client";

import React, { useState } from "react";
import Link from "next/link";
import { PRICING_PLANS } from "@/data/mockData";

export default function PricingPage() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "six_month">("six_month");

  return (
    <div className="min-h-screen bg-slate-50/70 pb-20">
      {/* Header Banner */}
      <section className="bg-aviation-950 text-white py-14 px-4 sm:px-6 lg:px-8 border-b border-aviation-900 text-center">
        <div className="max-w-4xl mx-auto">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-skyAccent-300 text-xs font-bold uppercase tracking-wider mb-4">
            <span>CloudAero DGCA Pilot Plans</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight font-sans">
            Simple, Transparent Pilot Pass Pricing
          </h1>
          <p className="mt-3 text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Invest in your pilot license with unrestricted access to DGCA full-length CBT mock exams, chapter practice drills, and in-depth answer rationales.
          </p>

          {/* Toggle pill */}
          <div className="mt-8 inline-flex items-center bg-aviation-900 p-1.5 rounded-2xl border border-aviation-800">
            <button
              type="button"
              onClick={() => setBillingCycle("monthly")}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                billingCycle === "monthly" ? "bg-white text-aviation-950 shadow-md" : "text-slate-300 hover:text-white"
              }`}
            >
              Monthly Plan (₹300)
            </button>
            <button
              type="button"
              onClick={() => setBillingCycle("six_month")}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                billingCycle === "six_month" ? "bg-skyAccent-400 text-aviation-950 shadow-md shadow-skyAccent-400/20" : "text-slate-300 hover:text-white"
              }`}
            >
              <span>6 Months Pilot Pass (₹1,500)</span>
              <span className="bg-emerald-600 text-white text-[10px] px-1.5 py-0.5 rounded-full font-extrabold">Save ₹300</span>
            </button>
          </div>
        </div>
      </section>

      {/* Pricing Cards Grid */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {PRICING_PLANS.map((plan) => {
            const isHighlighted = plan.id === billingCycle || plan.popular;
            return (
              <div
                key={plan.id}
                className={`rounded-3xl p-8 sm:p-10 flex flex-col justify-between transition-all duration-300 relative ${
                  isHighlighted
                    ? "bg-gradient-to-b from-aviation-900 via-aviation-950 to-aviation-950 text-white shadow-2xl border-2 border-skyAccent-400"
                    : "bg-white text-slate-900 border border-slate-200 shadow-aviation"
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 right-8 bg-skyAccent-400 text-aviation-950 text-xs font-extrabold uppercase px-3.5 py-1 rounded-full shadow-md tracking-wider">
                    Recommended for CPL & ATPL
                  </div>
                )}

                <div>
                  <h2 className={`text-2xl font-bold ${isHighlighted ? "text-white" : "text-aviation-900"}`}>
                    {plan.name}
                  </h2>
                  <p className={`text-xs mt-1 ${isHighlighted ? "text-slate-300" : "text-slate-500"}`}>
                    {plan.durationLabel}
                  </p>

                  <div className="mt-6 flex items-baseline space-x-2">
                    <span className={`text-5xl font-extrabold tracking-tight ${isHighlighted ? "text-white" : "text-aviation-900"}`}>
                      ₹{plan.priceINR}
                    </span>
                    <span className={`text-xs ${isHighlighted ? "text-slate-300" : "text-slate-500"}`}>
                      / {plan.id === "monthly" ? "1 calendar month" : "6 calendar months"}
                    </span>
                  </div>

                  <p className={`mt-2 text-xs font-medium ${isHighlighted ? "text-skyAccent-300" : "text-skyAccent-700"}`}>
                    {plan.id === "monthly"
                      ? "Provides 1 full calendar month of access (including month-end dates)."
                      : "Provides 6 full calendar months of continuous access (Save ₹300)."}
                  </p>

                  <ul className="mt-8 space-y-3.5 text-xs">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start space-x-3">
                        <span className={`mt-0.5 ${isHighlighted ? "text-skyAccent-400" : "text-emerald-600"} font-bold`}>
                          ✓
                        </span>
                        <span className={isHighlighted ? "text-slate-200" : "text-slate-700"}>
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-10 pt-4">
                  <Link
                    href={`/checkout?plan=${plan.id}`}
                    className={`w-full inline-flex items-center justify-center py-3.5 px-6 rounded-xl text-xs font-bold transition-all transform active:scale-95 shadow-md ${
                      isHighlighted
                        ? "bg-skyAccent-400 hover:bg-skyAccent-300 text-aviation-950 shadow-skyAccent-400/20"
                        : "bg-aviation-900 hover:bg-aviation-800 text-white"
                    }`}
                  >
                    Enroll Now — ₹{plan.priceINR} →
                  </Link>

                  <p className="text-center text-[11px] text-slate-400 mt-2.5">
                    Instant Activation • Razorpay UPI & Cards Supported
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Feature Comparison Table */}
        <div className="mt-16 bg-white rounded-3xl border border-aviation-100 p-8 shadow-sm">
          <h3 className="text-lg font-bold text-aviation-900 mb-6 text-center">
            Detailed Plan Comparison
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase">
                  <th className="pb-3">Platform Feature</th>
                  <th className="pb-3 text-center">Free Sample Tier</th>
                  <th className="pb-3 text-center text-aviation-900 font-extrabold">Monthly Pass (₹300)</th>
                  <th className="pb-3 text-center text-skyAccent-700 font-extrabold">6-Month Pass (₹1,500)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                <tr>
                  <td className="py-3.5 font-semibold">DGCA Subject Syllabus Browsing</td>
                  <td className="py-3.5 text-center text-emerald-600 font-bold">✓ Included</td>
                  <td className="py-3.5 text-center text-emerald-600 font-bold">✓ Included</td>
                  <td className="py-3.5 text-center text-emerald-600 font-bold">✓ Included</td>
                </tr>
                <tr>
                  <td className="py-3.5 font-semibold">DGCA Computer-Based Testing (CBT) Mock Exams</td>
                  <td className="py-3.5 text-center text-slate-400 font-bold">✕ Premium Only</td>
                  <td className="py-3.5 text-center text-emerald-600 font-bold">✓ All Papers Included</td>
                  <td className="py-3.5 text-center text-emerald-600 font-bold">✓ All Papers Included</td>
                </tr>
                <tr>
                  <td className="py-3.5 font-semibold">Chapter Practice & Answer Explanations</td>
                  <td className="py-3.5 text-center text-slate-400">Sample Only</td>
                  <td className="py-3.5 text-center text-emerald-600 font-bold">✓ Complete Bank</td>
                  <td className="py-3.5 text-center text-emerald-600 font-bold">✓ Complete Bank</td>
                </tr>
                <tr>
                  <td className="py-3.5 font-semibold">Weak Area Tracking & Bookmarks</td>
                  <td className="py-3.5 text-center text-slate-400">Basic</td>
                  <td className="py-3.5 text-center text-emerald-600 font-bold">✓ Included</td>
                  <td className="py-3.5 text-center text-emerald-600 font-bold">✓ Priority Analytics</td>
                </tr>
                <tr>
                  <td className="py-3.5 font-semibold">Validity Period</td>
                  <td className="py-3.5 text-center text-slate-500">Always Free</td>
                  <td className="py-3.5 text-center font-bold text-aviation-900">1 Calendar Month</td>
                  <td className="py-3.5 text-center font-bold text-skyAccent-700">6 Calendar Months</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
