"use client";

import React, { useState } from "react";
import Link from "next/link";
import { DETAILED_SUBJECTS } from "@/data/syllabusData";

interface PageProps {
  params: {
    slug: string;
  };
}

export default function SubjectDetailPage({ params }: PageProps) {
  const slug = params.slug;
  const [chapterSearch, setChapterSearch] = useState("");
  const [expandedNotesChapterId, setExpandedNotesChapterId] = useState<string | null>(null);

  const subject = DETAILED_SUBJECTS.find((s) => s.slug === slug) || DETAILED_SUBJECTS[0];

  const filteredChapters = subject.chapters.filter((ch) =>
    ch.title.toLowerCase().includes(chapterSearch.toLowerCase()) ||
    ch.topics.some((t) => t.toLowerCase().includes(chapterSearch.toLowerCase()))
  );

  const toggleNotes = (chapterId: string) => {
    setExpandedNotesChapterId((prev) => (prev === chapterId ? null : chapterId));
  };

  return (
    <div className="min-h-screen bg-slate-50/70 pb-20">
      {/* Header Banner */}
      <section className="bg-aviation-950 text-white py-12 px-4 sm:px-6 lg:px-8 border-b border-aviation-900">
        <div className="max-w-7xl mx-auto">
          {/* Breadcrumb */}
          <nav className="flex items-center space-x-2 text-xs text-slate-400 mb-4">
            <Link href="/" className="hover:text-white transition-colors">
              Home
            </Link>
            <span>/</span>
            <Link href="/subjects" className="hover:text-white transition-colors">
              Subjects
            </Link>
            <span>/</span>
            <span className="text-skyAccent-300 font-semibold">{subject.name}</span>
          </nav>

          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div>
              <div className="flex items-center space-x-3 mb-2">
                <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-skyAccent-400/20 text-skyAccent-300 border border-skyAccent-400/30">
                  {subject.code}
                </span>
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  DGCA Theory Module
                </span>
              </div>
              <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight font-sans">
                {subject.name}
              </h1>
              <p className="mt-2 text-sm text-slate-300 max-w-2xl leading-relaxed">
                {subject.description}
              </p>
            </div>

            {/* Quick Stats Panel */}
            <div className="bg-aviation-900/90 border border-aviation-800 p-5 rounded-2xl flex items-center space-x-6 text-center">
              <div>
                <span className="text-2xl font-bold text-white block">{subject.totalChapters}</span>
                <span className="text-[11px] text-slate-400 uppercase tracking-wider">Chapters</span>
              </div>
              <div className="w-px h-8 bg-aviation-800" />
              <div>
                <span className="text-2xl font-bold text-skyAccent-400 block">CBT</span>
                <span className="text-[11px] text-slate-400 uppercase tracking-wider">Format</span>
              </div>
              <div className="w-px h-8 bg-aviation-800" />
              <div>
                <span className="text-2xl font-bold text-emerald-400 block">{subject.passingPercentage}%</span>
                <span className="text-[11px] text-slate-400 uppercase tracking-wider">Pass Mark</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Chapter Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column: Chapters List (2 cols) */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search and Filters */}
            <div className="bg-white p-4 rounded-2xl border border-aviation-100 shadow-sm flex items-center justify-between">
              <div className="relative flex-grow max-w-md">
                <input
                  type="text"
                  value={chapterSearch}
                  onChange={(e) => setChapterSearch(e.target.value)}
                  placeholder="Filter chapters by topic or concept..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-aviation-800"
                />
                <svg
                  className="w-4 h-4 text-slate-400 absolute left-3.5 top-3"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <span className="text-xs text-slate-500 font-semibold ml-4">
                {filteredChapters.length} Chapters Listed
              </span>
            </div>

            {/* Chapters Accordion / List */}
            <div className="space-y-4">
              {filteredChapters.map((ch) => {
                const isNotesOpen = expandedNotesChapterId === ch.id;
                return (
                  <div
                    key={ch.id}
                    className="bg-white rounded-2xl border border-aviation-100 p-6 shadow-sm hover:border-aviation-300 transition-all"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-bold text-aviation-800 bg-aviation-50 px-2.5 py-0.5 rounded-full border border-aviation-100">
                            Chapter {ch.chapterNumber}
                          </span>
                          <span className="text-xs text-slate-400 font-medium">
                            Official DGCA Module
                          </span>
                        </div>

                        <h3 className="text-lg font-bold text-aviation-900">
                          {ch.title}
                        </h3>

                        <p className="text-xs text-slate-600 leading-relaxed max-w-xl">
                          {ch.description}
                        </p>
                      </div>

                      {/* Practice Action */}
                      <div className="flex sm:flex-col items-center sm:items-end gap-2 flex-shrink-0">
                        <Link
                          href={`/practice/${ch.slug}`}
                          className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-sm transition-colors text-center w-full"
                        >
                          Practice Drill
                        </Link>
                        <button
                          type="button"
                          onClick={() => toggleNotes(ch.id)}
                          className="text-[11px] font-semibold text-skyAccent-700 hover:text-aviation-900 flex items-center space-x-1"
                        >
                          <span>{isNotesOpen ? "Hide Notes" : "Quick Revision"}</span>
                          <svg
                            className={`w-3.5 h-3.5 transform transition-transform ${isNotesOpen ? "rotate-180" : ""}`}
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                          </svg>
                        </button>
                      </div>
                    </div>

                    {/* Syllabus Topics */}
                    <div className="mt-4 pt-4 border-t border-slate-100">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                        Key Exam Topics:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {ch.topics.map((t, idx) => (
                          <span
                            key={idx}
                            className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-medium"
                          >
                            • {t}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Quick Revision Notes Accordion */}
                    {isNotesOpen && (
                      <div className="mt-4 p-4 rounded-xl bg-aviation-50/70 border border-aviation-100 text-xs text-slate-700 leading-relaxed animate-fadeIn">
                        <div className="flex items-center space-x-2 text-aviation-900 font-bold mb-1">
                          <svg className="w-4 h-4 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          <span>Important DGCA Exam Revision Note:</span>
                        </div>
                        <p>{ch.revisionNotes}</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Mock Exam & Study Checklist Sidebar */}
          <div className="space-y-6">
            {/* Subject Mock Card */}
            <div className="bg-white rounded-2xl border border-aviation-100 p-6 shadow-sm">
              <span className="text-xs font-bold uppercase tracking-wider text-skyAccent-700 bg-skyAccent-50 px-2.5 py-0.5 rounded-full border border-skyAccent-200">
                Full CBT Simulation
              </span>
              <h4 className="text-base font-bold text-aviation-900 mt-3">
                {subject.name} Mock Examination
              </h4>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Attempt a complete timed mock test simulating the real DGCA computer-based testing format with negative marking rules and immediate score analysis.
              </p>

              <div className="mt-4 p-3 bg-slate-50 rounded-xl space-y-1.5 text-xs text-slate-600">
                <div className="flex justify-between">
                  <span>Questions:</span>
                  <span className="font-semibold text-aviation-900">70 Multiple Choice</span>
                </div>
                <div className="flex justify-between">
                  <span>Exam Duration:</span>
                  <span className="font-semibold text-aviation-900">120 Minutes</span>
                </div>
                <div className="flex justify-between">
                  <span>Passing Score:</span>
                  <span className="font-semibold text-emerald-600">70% Required</span>
                </div>
              </div>

              <Link
                href="/mock-exams"
                className="mt-5 w-full inline-flex items-center justify-center py-3 px-4 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-md transition-colors"
              >
                Launch Mock Exam
                <svg className="w-4 h-4 ml-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </Link>
            </div>

            {/* Preparation Tip */}
            <div className="bg-gradient-to-br from-aviation-900 to-aviation-950 text-white rounded-2xl p-6 shadow-md">
              <span className="text-xs font-bold uppercase text-skyAccent-300">Study Strategy</span>
              <h4 className="text-sm font-bold mt-2">Pass DGCA on First Attempt</h4>
              <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                DGCA theoretical examinations require both numerical precision and conceptual clarity. Complete chapter drills with at least 80% accuracy before taking the full-length mock papers.
              </p>
              <div className="mt-4 pt-3 border-t border-white/10 text-xs text-slate-400">
                Questions verified from authorized Indian civil aviation training references.
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
