"use client";

import React, { useState } from "react";
import Link from "next/link";
import { DETAILED_SUBJECTS } from "@/data/syllabusData";

export default function SubjectsCatalogPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");

  const categories = ["All", "Regulatory", "Meteorology", "Navigation", "Technical"];

  const filteredSubjects = DETAILED_SUBJECTS.filter((subject) => {
    const matchesCategory = selectedCategory === "All" || subject.category === selectedCategory;
    const matchesSearch =
      subject.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      subject.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      subject.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-slate-50/70 pb-20">
      {/* Header Banner */}
      <section className="bg-aviation-950 text-white py-14 px-4 sm:px-6 lg:px-8 border-b border-aviation-900">
        <div className="max-w-7xl mx-auto">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-skyAccent-300 text-xs font-bold uppercase tracking-wider mb-4">
            <span>DGCA Commercial & Airline Transport Pilot Syllabus</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight font-sans">
            Examination Subjects & Syllabus
          </h1>
          <p className="mt-3 text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
            Browse through all official DGCA examination subjects. Each module is structured into dedicated chapters, learning objectives, and multiple-choice drill banks.
          </p>

          {/* Search & Filter Bar */}
          <div className="mt-8 flex flex-col md:flex-row gap-4 max-w-3xl">
            <div className="relative flex-grow">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search subjects by name or code (e.g., Air Navigation, AV-MET)..."
                className="w-full pl-11 pr-4 py-3 rounded-xl bg-aviation-900 border border-aviation-800 text-white placeholder:text-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-skyAccent-400 transition-all"
              />
              <svg
                className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-2 items-center">
              {categories.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    selectedCategory === cat
                      ? "bg-skyAccent-400 text-aviation-950 shadow-md shadow-skyAccent-400/20"
                      : "bg-aviation-900 hover:bg-aviation-800 text-slate-300 border border-aviation-800"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Main Subjects Grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6">
        {filteredSubjects.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 mt-10">
            <p className="text-base font-semibold text-slate-700">No subjects found matching your search.</p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery("");
                setSelectedCategory("All");
              }}
              className="mt-3 text-sm text-aviation-800 font-bold hover:underline"
            >
              Reset Search & Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredSubjects.map((subject) => (
              <div
                key={subject.id}
                className="bg-white rounded-3xl border border-aviation-100 p-8 shadow-aviation hover:shadow-aviation-hover hover:border-skyAccent-300 transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-slate-100 text-slate-700">
                      {subject.code}
                    </span>
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-aviation-50 text-aviation-800 border border-aviation-100">
                      {subject.category}
                    </span>
                  </div>

                  <h2 className="text-2xl font-bold text-aviation-900 group-hover:text-aviation-700 transition-colors">
                    {subject.name}
                  </h2>

                  <p className="mt-2.5 text-xs text-slate-600 line-clamp-3 leading-relaxed">
                    {subject.description}
                  </p>

                  {/* Core Metrics */}
                  <div className="mt-6 grid grid-cols-2 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-100 text-xs">
                    <div>
                      <span className="text-slate-400 block font-medium">Syllabus Chapters</span>
                      <span className="text-base font-bold text-aviation-900">{subject.totalChapters} Chapters</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-medium">Curriculum</span>
                      <span className="text-base font-bold text-skyAccent-600">DGCA Standard</span>
                    </div>
                    <div className="pt-2 border-t border-slate-200/60">
                      <span className="text-slate-400 block font-medium">Exam Duration</span>
                      <span className="font-semibold text-slate-700">{subject.examDurationMinutes} Minutes</span>
                    </div>
                    <div className="pt-2 border-t border-slate-200/60">
                      <span className="text-slate-400 block font-medium">Passing Mark</span>
                      <span className="font-semibold text-emerald-600">{subject.passingPercentage}% Required</span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="mt-8 pt-4 border-t border-slate-100 flex items-center space-x-3">
                  <Link
                    href={`/subjects/${subject.slug}`}
                    className="flex-grow text-center py-3 px-4 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-sm transition-all"
                  >
                    View Chapters
                  </Link>
                  <Link
                    href="/mock-exams"
                    className="py-3 px-4 rounded-xl text-xs font-semibold text-aviation-800 bg-aviation-50 hover:bg-aviation-100 border border-aviation-200 transition-colors"
                  >
                    Mock Exam
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
