import React from "react";
import Link from "next/link";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Terms and Conditions — CloudAero DGCA",
  description: "Terms and conditions of use for CloudAero DGCA pilot examination preparation platform.",
};

export default function TermsPage() {
  return (
    <div className="bg-slate-50 min-h-screen py-12 sm:py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="bg-white p-8 sm:p-12 rounded-3xl border border-slate-200 shadow-sm space-y-8 text-xs text-slate-600 leading-relaxed">
          {/* Header */}
          <div className="border-b border-slate-100 pb-6">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-aviation-100 text-aviation-800 font-bold uppercase tracking-wider text-[11px] mb-3">
              <span>⚖️</span>
              <span>Legal Regulatory Documentation</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-aviation-950">
              Terms & Conditions of Service
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Effective Date: January 1, 2026 | Last Updated: October 2026
            </p>
          </div>

          {/* Statutory Disclaimer Callout */}
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 text-amber-950 space-y-2">
            <h3 className="font-bold uppercase tracking-wider text-[11px] text-amber-900 flex items-center space-x-1.5">
              <span>⚠️</span>
              <span>Important Independent Platform Disclaimer</span>
            </h3>
            <p>
              CloudAero DGCA is an independent self-study and examination training simulator developed by private aviation educators. CloudAero DGCA is <strong>not affiliated with, associated with, authorized by, sponsored by, or in any way officially connected with the Directorate General of Civil Aviation (DGCA), Ministry of Civil Aviation, Government of India</strong>, or any of its subsidiaries or statutory bodies. Official DGCA examination circulars, registration schedules, and results must be accessed directly via official portals (<a href="https://dgca.gov.in" target="_blank" rel="noreferrer" className="underline font-bold">dgca.gov.in</a> and <a href="https://pariksha.dgca.gov.in" target="_blank" rel="noreferrer" className="underline font-bold">pariksha.dgca.gov.in</a>).
            </p>
          </div>

          {/* Section 1 */}
          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              1. Acceptance of Terms
            </h2>
            <p>
              By accessing, browsing, registering for an account, or subscribing to CloudAero DGCA ("the Service", "the Platform", "we", "us", "our"), you agree to be bound by these Terms and Conditions ("Terms"). If you do not agree to all provisions contained herein, you must immediately discontinue your use of the Platform.
            </p>
          </section>

          {/* Section 2 */}
          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              2. Nature of the Educational Service
            </h2>
            <p>
              CloudAero DGCA provides computerized training tools, chapter-wise question banks, formula explanations, and timed Computer-Based Testing (CBT) mock examinations for student pilots preparing for Commercial Pilot License (CPL), Airline Transport Pilot License (ATPL), and Private Pilot License (PPL) examinations.
            </p>
            <p>
              The materials provided are intended strictly for educational preparation. While we endeavor to keep all information updated with current Civil Aviation Requirements (CARs) and Aeronautical Information Publications (AIP), we make no representation that questions will appear verbatim in actual government examinations.
            </p>
          </section>

          {/* Section 3 */}
          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              3. User Accounts and Security
            </h2>
            <p>
              When creating an account, you agree to provide true, accurate, and current information. You are solely responsible for maintaining the confidentiality of your credentials. Single-user subscriptions are licensed to one candidate only; account sharing, credential harvesting, or automated scraping of question items constitutes a material violation of these Terms and will result in immediate account termination without refund.
            </p>
          </section>

          {/* Section 4 */}
          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              4. Subscription Plans, Fees & Indian Currency Billing
            </h2>
            <p>
              CloudAero DGCA offers premium subscriptions billed in Indian National Rupees (INR / ₹) via authorized Reserve Bank of India (RBI) compliant payment aggregators (Razorpay):
            </p>
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Monthly Pass:</strong> ₹300 for 1 full calendar month of unlimited access.</li>
              <li><strong>Six-Month Pass:</strong> ₹1,500 for 6 full calendar months of unlimited access.</li>
            </ul>
            <p>
              Subscription terms operate on calendar-month expiration rules. Access to premium mock examinations terminates automatically upon expiration of your subscription period unless renewed.
            </p>
          </section>

          {/* Section 5 */}
          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              5. Intellectual Property Rights
            </h2>
            <p>
              All proprietary code, simulator interfaces, original explanations, mathematical derivations, software layouts, graphic assets, and editorial syntheses hosted on CloudAero are the exclusive intellectual property of CloudAero. You may not reproduce, distribute, republish, sell, or commercially exploit any content without our express written authorization.
            </p>
          </section>

          {/* Section 6 */}
          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              6. Limitation of Liability
            </h2>
            <p>
              In no event shall CloudAero, its directors, instructors, or technical affiliates be liable for any direct, indirect, incidental, consequential, or punitive damages arising from the use of the Platform, including but not limited to examination performance, regulatory schedule modifications, or temporary service interruptions.
            </p>
          </section>

          {/* Section 7 */}
          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              7. Governing Law and Dispute Resolution
            </h2>
            <p>
              These Terms shall be governed by and construed in accordance with the laws of the Republic of India. Any legal dispute, claim, or controversy arising out of or relating to these Terms or the Platform shall be subject to the exclusive jurisdiction of the competent courts situated in New Delhi, India.
            </p>
          </section>

          {/* Section 8 */}
          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              8. Contact Legal Department
            </h2>
            <p>
              For any formal inquiries concerning these Terms of Service, please contact:
            </p>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700">
              <strong>Operations:</strong> CloudAero DGCA Platform Operations<br />
              <strong>Communications:</strong> Official inquiries may be submitted through the Platform Contact Form.
            </div>
          </section>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
            <Link href="/" className="font-bold text-skyAccent-600 hover:underline">
              ← Return to CloudAero Home
            </Link>
            <Link href="/legal/privacy" className="font-semibold text-slate-500 hover:text-aviation-950">
              Read Privacy Policy →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
