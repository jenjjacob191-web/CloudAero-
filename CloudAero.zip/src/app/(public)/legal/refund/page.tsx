import React from "react";
import Link from "next/link";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Refund and Cancellation Policy — CloudAero DGCA",
  description: "Refund and cancellation guidelines for CloudAero DGCA subscription plans.",
};

export default function RefundPolicyPage() {
  return (
    <div className="bg-slate-50 min-h-screen py-12 sm:py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="bg-white p-8 sm:p-12 rounded-3xl border border-slate-200 shadow-sm space-y-8 text-xs text-slate-600 leading-relaxed">
          {/* Header */}
          <div className="border-b border-slate-100 pb-6">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-aviation-100 text-aviation-800 font-bold uppercase tracking-wider text-[11px] mb-3">
              <span>💳</span>
              <span>Billing & Subscription Rules</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-aviation-950">
              Refund & Cancellation Policy
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Applicable to all Indian Rupee (INR / ₹) Subscriptions via Razorpay
            </p>
          </div>

          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              1. Nature of Digital Goods
            </h2>
            <p>
              CloudAero DGCA provides instant digital access to digital study materials, proprietary question banks, formula derivations, and timed Computer-Based Testing (CBT) mock exam simulators immediately upon successful payment verification. Because digital content is instantly unlocked, standard physical goods return rules do not apply.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              2. 48-Hour Technical Satisfaction Consideration
            </h2>
            <p>
              We want every candidate to have an exceptional experience. If you experience verifiable technical issues that prevent you from accessing the question banks or mock exams and our support engineering team cannot resolve the problem within 48 hours of purchase, you may request a review for a full refund by submitting a ticket via our official Contact Desk.
            </p>
            <p>
              To be eligible, the refund request must be submitted within <strong>48 hours</strong> of the transaction timestamp and accompanied by your registered email and Razorpay Payment ID.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              3. Duplicate or Accidental Transactions
            </h2>
            <p>
              If your bank account, credit card, or UPI ID was charged more than once due to network latency, duplicate order submissions, or gateway time-outs, the redundant transaction will be promptly reversed. Once verified, duplicate funds are refunded back to your original source payment method within <strong>5 to 7 business banking days</strong> via Razorpay.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              4. Subscription Expiration and Renewal
            </h2>
            <p>
              Subscriptions to CloudAero DGCA (Monthly Pass at ₹300 or Six-Month Pass at ₹1,500) run for exact calendar month periods:
            </p>
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Monthly Pass:</strong> Valid for 1 calendar month from the activation date.</li>
              <li><strong>Six-Month Pass:</strong> Valid for 6 calendar months from the activation date.</li>
            </ul>
            <p>
              We do not perform hidden recurring recurring auto-charges without your explicit authorization. When your term expires, your account safely reverts to the free tier until you manually choose to purchase a new pass.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              5. Non-Refundable Scenarios
            </h2>
            <p>Refunds cannot be issued under the following circumstances:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Changes of mind after significant platform usage (e.g., completing multiple mock exams or chapter practice sessions).</li>
              <li>Official examination postponement or cancellation announced by the DGCA or regional test centers.</li>
              <li>Account suspension resulting from violation of Terms of Service (such as unauthorized credential sharing, commercial distribution, or automated web scraping).</li>
              <li>Requests submitted after 48 hours of initial transaction completion.</li>
            </ul>
          </section>

          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              6. How to Submit a Refund Claim
            </h2>
            <p>
              To initiate an inquiry or report an errant payment, submit a transmission through the platform Contact Form with:
            </p>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700 space-y-1">
              <div><strong>Channel:</strong> Platform Contact & Support Transmission Desk</div>
              <div><strong>Subject:</strong> Refund Request - [Your Registered Email]</div>
              <div><strong>Required Details:</strong> Razorpay Payment ID (e.g. pay_...), Registered Candidate Name, Description of Issue.</div>
            </div>
          </section>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
            <Link href="/" className="font-bold text-skyAccent-600 hover:underline">
              ← Return to CloudAero Home
            </Link>
            <Link href="/legal/terms" className="font-semibold text-slate-500 hover:text-aviation-950">
              Read Terms of Service →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
