import React from "react";
import Link from "next/link";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy Policy — CloudAero DGCA",
  description: "Privacy and data protection policy for CloudAero DGCA pilot examination platform.",
};

export default function PrivacyPolicyPage() {
  return (
    <div className="bg-slate-50 min-h-screen py-12 sm:py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="bg-white p-8 sm:p-12 rounded-3xl border border-slate-200 shadow-sm space-y-8 text-xs text-slate-600 leading-relaxed">
          {/* Header */}
          <div className="border-b border-slate-100 pb-6">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-aviation-100 text-aviation-800 font-bold uppercase tracking-wider text-[11px] mb-3">
              <span>🔒</span>
              <span>Data Protection & Privacy</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-aviation-950">
              Privacy Policy
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Compliant with the Information Technology Act, 2000 & Digital Personal Data Protection (DPDP) Act, 2023
            </p>
          </div>

          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              1. Overview & Commitment to Pilot Privacy
            </h2>
            <p>
              CloudAero DGCA ("we", "our", or "us") respects the privacy of our student pilots and users. This Privacy Policy describes how we collect, store, utilize, and protect your personal information when you register, use our online question banks, attempt mock exams, or purchase subscriptions.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              2. Information We Collect
            </h2>
            <p>We collect only the information necessary to provide an authentic, personalized study experience:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Account Credentials:</strong> Full name, verified email address, encrypted password hash, and optional Computer Number / License track (CPL/ATPL/PPL).</li>
              <li><strong>Academic Progress Data:</strong> Mock examination scores, time spent per question, chapter completion status, bookmarked questions, and disputed answer reports.</li>
              <li><strong>Transaction Identifiers:</strong> Razorpay Order IDs, Payment IDs, subscription start and expiry dates, and tax invoices. <em>Note: We never collect or store your raw debit/credit card numbers, CVVs, netbanking passwords, or UPI PINs.</em></li>
              <li><strong>Technical Logs:</strong> IP address, device type, and browser session headers used for security monitoring and session validation.</li>
            </ul>
          </section>

          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              3. Purpose of Data Processing
            </h2>
            <p>Your information is processed strictly for legitimate educational purposes, including:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Rendering your student dashboard, study progress counters, and mock test scorecards.</li>
              <li>Validating subscription validity and granting access to premium mock exam papers.</li>
              <li>Sending essential account notifications such as password reset tokens and billing receipts.</li>
              <li>Improving syllabus question accuracy and fixing flagged question items.</li>
            </ul>
          </section>

          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              4. Payment Security & RBI Compliance
            </h2>
            <p>
              All online monetary transactions are handled by PCI-DSS Level 1 certified Indian payment aggregator <strong>Razorpay</strong>. All sensitive financial data is tokenized and transmitted over bank-grade 256-bit TLS encrypted channels in full compliance with Reserve Bank of India (RBI) payment guidelines.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              5. Third-Party Disclosures
            </h2>
            <p>
              <strong>We do not sell, rent, or trade your personal information to third-party advertisers or recruitment agencies.</strong> Data is shared only with trusted infrastructure providers (cloud database hosting, authentication, transactional email) strictly to maintain platform operations.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              6. Data Retention and Account Deletion
            </h2>
            <p>
              We retain your examination history while your account remains active so you can track improvements across DGCA exam cycles. You may request the permanent deletion of your account and personal study history at any time by contacting support via our official Contact page.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-sm font-bold text-aviation-950 uppercase tracking-wide">
              7. Grievance Redressal
            </h2>
            <p>
              In accordance with the Information Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules, 2021, platform users may submit grievances regarding privacy, account handling, or data security through the official Contact Desk:
            </p>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700 leading-relaxed">
              <strong>Support Desk:</strong> Online Flight Examination Platform Redressal Desk<br />
              <strong>Submission:</strong> Inquiries and grievance reports may be submitted through the transmission form on the Contact page.
            </div>
          </section>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
            <Link href="/" className="font-bold text-skyAccent-600 hover:underline">
              ← Return to CloudAero Home
            </Link>
            <Link href="/legal/refund" className="font-semibold text-slate-500 hover:text-aviation-950">
              Read Refund Policy →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
