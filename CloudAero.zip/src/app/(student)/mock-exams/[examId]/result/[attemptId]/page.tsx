"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { MOCK_EXAMS_CATALOG } from "@/data/mockExamsData";

interface PageProps {
  params: {
    examId: string;
    attemptId: string;
  };
}

export default function MockExamResultPage({ params }: PageProps) {
  const examId = params.examId;
  const attemptId = params.attemptId;
  const exam = MOCK_EXAMS_CATALOG.find((e) => e.id === examId) || MOCK_EXAMS_CATALOG[0];

  const [savedData, setSavedData] = useState<{
    selectedAnswers: Record<number, string>;
    timeSpentSeconds: number;
    completedAt: string;
  } | null>(null);

  const [filterMode, setFilterMode] = useState<"all" | "correct" | "incorrect" | "unattempted">("all");

  useEffect(() => {
    if (typeof window !== "undefined") {
      const stored = sessionStorage.getItem(`mock-result-${attemptId}`);
      if (stored) {
        try {
          setSavedData(JSON.parse(stored));
        } catch {
          // ignore error
        }
      }
    }
  }, [attemptId]);

  const selectedAnswers = savedData?.selectedAnswers || {};
  const timeSpentSeconds = savedData?.timeSpentSeconds || 0;

  // Compute scores
  let correctCount = 0;
  let incorrectCount = 0;
  let unattemptedCount = 0;

  exam.questions.forEach((q, idx) => {
    const chosenOptId = selectedAnswers[idx];
    if (!chosenOptId) {
      unattemptedCount++;
    } else if (chosenOptId === q.correctOptionId) {
      correctCount++;
    } else {
      incorrectCount++;
    }
  });

  const rawScore = correctCount * exam.marksPerQuestion - incorrectCount * exam.negativeMarking;
  const maxPossibleMarks = exam.questions.length * exam.marksPerQuestion;
  const percentage = maxPossibleMarks > 0 ? Math.max(0, Math.round((rawScore / maxPossibleMarks) * 100)) : 0;
  const isPassed = percentage >= exam.passingPercentage;

  const formatTimeSpent = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainderSecs = secs % 60;
    return `${mins}m ${remainderSecs}s`;
  };

  // Filter questions
  const filteredQuestions = exam.questions.filter((q, idx) => {
    const chosenOptId = selectedAnswers[idx];
    const isCorrect = chosenOptId === q.correctOptionId;
    if (filterMode === "correct") return chosenOptId && isCorrect;
    if (filterMode === "incorrect") return chosenOptId && !isCorrect;
    if (filterMode === "unattempted") return !chosenOptId;
    return true;
  });

  return (
    <div className="min-h-screen bg-slate-50/70 pb-20">
      {/* Result Hero Header */}
      <section
        className={`py-12 px-4 sm:px-6 lg:px-8 border-b text-white ${
          isPassed ? "bg-gradient-to-r from-aviation-950 via-aviation-900 to-emerald-950 border-emerald-800" : "bg-gradient-to-r from-aviation-950 via-aviation-900 to-red-950 border-red-800"
        }`}
      >
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center space-x-2 text-xs uppercase tracking-wider mb-2">
              <span className="font-mono bg-white/10 px-2 py-0.5 rounded text-skyAccent-300">
                {exam.subjectName}
              </span>
              <span>•</span>
              <span className="text-slate-300">Attempt ID: {attemptId.slice(0, 16)}</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
              {exam.title}
            </h1>
            <p className="text-xs text-slate-300 mt-1">
              Test Completed on {savedData?.completedAt ? new Date(savedData.completedAt).toLocaleString() : "Today"}
            </p>
          </div>

          {/* Large Result Verdict Badge */}
          <div
            className={`px-6 py-4 rounded-2xl border text-center flex-shrink-0 ${
              isPassed
                ? "bg-emerald-500/20 border-emerald-400/40 text-emerald-300 shadow-lg shadow-emerald-900/30"
                : "bg-red-500/20 border-red-400/40 text-red-300 shadow-lg shadow-red-900/30"
            }`}
          >
            <span className="text-xs uppercase font-extrabold tracking-wider block">DGCA Examination Status</span>
            <span className="text-3xl font-extrabold block my-0.5">
              {isPassed ? "PASSED" : "NEEDS REVIEW"}
            </span>
            <span className="text-xs text-slate-200">DGCA Requirement: 70%</span>
          </div>
        </div>
      </section>

      {/* Main Scorecard & Breakdown */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6">
        {/* Top 4 Score Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          <div className="bg-white p-5 rounded-2xl border border-aviation-100 shadow-sm text-center">
            <span className="text-xs font-semibold text-slate-400 block uppercase">Final Score</span>
            <span className="text-3xl font-extrabold text-aviation-900 my-1 block">
              {rawScore} / {maxPossibleMarks}
            </span>
            <span className={`text-xs font-bold ${isPassed ? "text-emerald-600" : "text-red-500"}`}>
              {percentage}%
            </span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-aviation-100 shadow-sm text-center">
            <span className="text-xs font-semibold text-slate-400 block uppercase">Correct</span>
            <span className="text-3xl font-extrabold text-emerald-600 my-1 block">
              {correctCount}
            </span>
            <span className="text-xs text-slate-400">Questions</span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-aviation-100 shadow-sm text-center">
            <span className="text-xs font-semibold text-slate-400 block uppercase">Incorrect</span>
            <span className="text-3xl font-extrabold text-red-500 my-1 block">
              {incorrectCount}
            </span>
            <span className="text-xs text-slate-400">{unattemptedCount} Unattempted</span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-aviation-100 shadow-sm text-center">
            <span className="text-xs font-semibold text-slate-400 block uppercase">Time Taken</span>
            <span className="text-2xl font-extrabold text-aviation-900 my-1 block">
              {formatTimeSpent(timeSpentSeconds)}
            </span>
            <span className="text-xs text-slate-400">of {exam.durationMinutes}m allowed</span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="bg-white p-4 rounded-2xl border border-aviation-100 shadow-sm flex flex-wrap items-center justify-between gap-4 mb-8">
          {/* Review Filter Pills */}
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => setFilterMode("all")}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                filterMode === "all" ? "bg-aviation-900 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              }`}
            >
              All Questions ({exam.questions.length})
            </button>
            <button
              type="button"
              onClick={() => setFilterMode("correct")}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                filterMode === "correct" ? "bg-emerald-600 text-white" : "bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
              }`}
            >
              Correct ({correctCount})
            </button>
            <button
              type="button"
              onClick={() => setFilterMode("incorrect")}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                filterMode === "incorrect" ? "bg-red-600 text-white" : "bg-red-50 text-red-700 hover:bg-red-100"
              }`}
            >
              Incorrect ({incorrectCount})
            </button>
            <button
              type="button"
              onClick={() => setFilterMode("unattempted")}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                filterMode === "unattempted" ? "bg-slate-700 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              }`}
            >
              Unattempted ({unattemptedCount})
            </button>
          </div>

          <div className="flex items-center space-x-3">
            <Link
              href={`/mock-exams/${exam.id}/instructions`}
              className="py-2 px-4 rounded-xl text-xs font-bold text-aviation-800 bg-aviation-50 hover:bg-aviation-100 border border-aviation-200"
            >
              🔄 Retake Mock Exam
            </Link>
            <Link
              href="/dashboard"
              className="py-2 px-4 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-sm"
            >
              Back to Dashboard
            </Link>
          </div>
        </div>

        {/* Question-By-Question Detailed Audit */}
        <div className="space-y-6">
          <h2 className="text-base font-bold text-aviation-900 uppercase tracking-wider">
            Detailed Solution & Rationales
          </h2>

          {filteredQuestions.map((q) => {
            const originalIndex = exam.questions.findIndex((orig) => orig.id === q.id);
            const userChosenOptId = selectedAnswers[originalIndex];
            const isUserCorrect = userChosenOptId === q.correctOptionId;
            const isUnattempted = !userChosenOptId;

            return (
              <div
                key={q.id}
                className={`bg-white rounded-2xl border p-6 sm:p-7 shadow-sm transition-all ${
                  isUnattempted
                    ? "border-slate-200"
                    : isUserCorrect
                    ? "border-emerald-200"
                    : "border-red-200"
                }`}
              >
                {/* Header status */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <span className="w-7 h-7 rounded-lg bg-aviation-900 text-skyAccent-400 font-bold text-xs flex items-center justify-center">
                      #{originalIndex + 1}
                    </span>
                    <span className="text-xs font-bold text-slate-500">Multiple Choice</span>
                  </div>

                  <div>
                    {isUnattempted ? (
                      <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-full">
                        Unattempted (0 Marks)
                      </span>
                    ) : isUserCorrect ? (
                      <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full flex items-center space-x-1">
                        <span>✓ Correct</span>
                        <span>(+{exam.marksPerQuestion})</span>
                      </span>
                    ) : (
                      <span className="text-xs font-bold text-red-700 bg-red-50 border border-red-200 px-2.5 py-0.5 rounded-full flex items-center space-x-1">
                        <span>✕ Incorrect</span>
                        {exam.negativeMarking > 0 && <span>(-{exam.negativeMarking})</span>}
                      </span>
                    )}
                  </div>
                </div>

                {/* Question Text */}
                <h3 className="text-base font-bold text-aviation-900 mb-5 leading-snug">
                  {q.questionText}
                </h3>

                {/* Options List with Color Highlights */}
                <div className="space-y-2.5 mb-5">
                  {q.options.map((opt) => {
                    const isSelectedByUser = userChosenOptId === opt.id;
                    const isTheCorrectOpt = opt.id === q.correctOptionId;

                    let optStyle = "bg-slate-50/60 border-slate-200 text-slate-700";

                    if (isTheCorrectOpt) {
                      optStyle = "bg-emerald-50 border-emerald-400 text-emerald-950 font-bold";
                    } else if (isSelectedByUser && !isTheCorrectOpt) {
                      optStyle = "bg-red-50 border-red-400 text-red-950 font-semibold";
                    }

                    return (
                      <div
                        key={opt.id}
                        className={`p-3.5 rounded-xl border text-xs flex items-center justify-between ${optStyle}`}
                      >
                        <div className="flex items-center space-x-3">
                          <span className="w-6 h-6 rounded-lg bg-white border border-slate-300 flex items-center justify-center font-bold text-[11px] text-slate-700">
                            {opt.label}
                          </span>
                          <span>{opt.text}</span>
                        </div>

                        {isTheCorrectOpt && (
                          <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                            Correct Answer Key
                          </span>
                        )}
                        {isSelectedByUser && !isTheCorrectOpt && (
                          <span className="text-[11px] font-bold text-red-700 bg-red-100 px-2 py-0.5 rounded">
                            Your Response
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Explanation */}
                <div className="p-4 rounded-xl bg-aviation-50 border border-aviation-100 text-xs text-aviation-950 leading-relaxed">
                  <span className="font-bold text-aviation-900 block mb-1">Detailed Explanation & Flight Rule:</span>
                  <p className="text-slate-700">{q.explanation}</p>
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
}
