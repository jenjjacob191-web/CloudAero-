"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { MOCK_EXAMS_CATALOG } from "@/data/mockExamsData";
import { useAuth } from "@/lib/auth-context";

interface PageProps {
  params: {
    examId: string;
  };
}

export default function MockExamInstructionsPage({ params }: PageProps) {
  const router = useRouter();
  const { isPremium } = useAuth();
  const examId = params.examId;
  const exam = MOCK_EXAMS_CATALOG.find((e) => e.id === examId) || MOCK_EXAMS_CATALOG[0];

  const [hasAgreed, setHasAgreed] = useState(false);

  // Access controlled directly through Supabase profiles.is_premium
  const isLocked = !isPremium;

  const hasQuestions = exam.questions && exam.questions.length > 0;

  const handleStartExam = () => {
    if (!hasAgreed || isLocked || !hasQuestions) return;
    router.push(`/mock-exams/${exam.id}/live`);
  };

  return (
    <div className="min-h-screen bg-slate-50/70 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto bg-white rounded-3xl border border-aviation-100 shadow-2xl p-6 sm:p-10">
        {/* Header */}
        <div className="pb-6 border-b border-slate-100 mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2 text-xs text-skyAccent-700 font-bold uppercase tracking-wider mb-1">
              <span>{exam.subjectName}</span>
              <span>•</span>
              <span className="text-slate-400">DGCA Examination Room</span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-800 border border-amber-300">
                🔒 Premium CBT Paper
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-aviation-900 tracking-tight">
              {exam.title}
            </h1>
          </div>

          <div className="bg-aviation-50 border border-aviation-200 px-4 py-2 rounded-xl text-right">
            <span className="text-[11px] text-slate-400 block font-medium">Standard Duration</span>
            <span className="text-base font-bold text-aviation-900">{exam.durationMinutes} Minutes</span>
          </div>
        </div>

        {/* Premium Lock Banner if Locked */}
        {isLocked && (
          <div className="bg-gradient-to-r from-aviation-950 via-aviation-900 to-aviation-950 text-white rounded-2xl p-6 mb-8 border border-aviation-800 shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 w-36 h-36 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 relative z-10">
              <div className="space-y-1.5 max-w-lg">
                <div className="flex items-center space-x-2 text-amber-300 font-extrabold text-xs uppercase tracking-wider">
                  <span>🔒</span>
                  <span>Premium License Preparation Paper</span>
                </div>
                <h3 className="text-lg font-bold text-white">
                  Active CloudAero Subscription Required
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  This full-length DGCA Computer-Based mock examination contains verified syllabus questions and server-side evaluation. Unlock complete access across all subjects starting at just ₹300/month.
                </p>
              </div>

              <div className="flex-shrink-0">
                <Link
                  href="/pricing"
                  className="inline-flex items-center space-x-2 px-6 py-3 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-aviation-950 shadow-md transition-all font-sans"
                >
                  <span>Unlock for ₹300</span>
                  <span>→</span>
                </Link>
              </div>
            </div>
          </div>
        )}

        {/* Exam Specifications Table */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-50 p-5 rounded-2xl border border-slate-100 text-xs mb-8">
          <div>
            <span className="text-slate-400 block font-medium">Total Questions</span>
            <span className="text-lg font-bold text-aviation-900">{exam.totalQuestions} MCQs</span>
          </div>
          <div>
            <span className="text-slate-400 block font-medium">Total Marks</span>
            <span className="text-lg font-bold text-aviation-900">{exam.totalQuestions * exam.marksPerQuestion}</span>
          </div>
          <div>
            <span className="text-slate-400 block font-medium">Passing Criteria</span>
            <span className="text-lg font-bold text-emerald-600">{exam.passingPercentage}% Required</span>
          </div>
          <div>
            <span className="text-slate-400 block font-medium">Negative Marking</span>
            <span className="text-lg font-bold text-slate-700">
              {exam.negativeMarking > 0 ? `-${exam.negativeMarking}` : "None"}
            </span>
          </div>
        </div>

        {/* Detailed Examination Rules */}
        <div className="space-y-6 text-xs text-slate-700 leading-relaxed mb-8">
          <div>
            <h3 className="text-sm font-bold text-aviation-900 mb-2 uppercase tracking-wider">
              1. General Examination Instructions
            </h3>
            <ul className="list-disc pl-5 space-y-1.5 text-slate-600">
              <li>The test timer will begin immediately upon clicking <strong>&ldquo;Launch CBT Examination&rdquo;</strong>.</li>
              <li>The exam cannot be paused once initiated. If your browser closes or connectivity drops, your timer continues running.</li>
              <li>The exam will <strong>automatically submit</strong> when the countdown reaches 00:00:00.</li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-bold text-aviation-900 mb-2 uppercase tracking-wider">
              2. Question Palette Status Indicators
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
              <div className="flex items-center space-x-2 bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl">
                <span className="w-4 h-4 rounded-full bg-emerald-600 flex-shrink-0" />
                <span className="font-semibold text-emerald-950">Answered</span>
              </div>
              <div className="flex items-center space-x-2 bg-red-50 border border-red-200 p-2.5 rounded-xl">
                <span className="w-4 h-4 rounded-full bg-red-500 flex-shrink-0" />
                <span className="font-semibold text-red-950">Not Answered</span>
              </div>
              <div className="flex items-center space-x-2 bg-amber-50 border border-amber-200 p-2.5 rounded-xl">
                <span className="w-4 h-4 rounded-full bg-amber-500 flex-shrink-0" />
                <span className="font-semibold text-amber-950">Marked for Review</span>
              </div>
              <div className="flex items-center space-x-2 bg-slate-100 border border-slate-200 p-2.5 rounded-xl">
                <span className="w-4 h-4 rounded-full bg-slate-400 flex-shrink-0" />
                <span className="font-semibold text-slate-700">Not Visited</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-bold text-aviation-900 mb-2 uppercase tracking-wider">
              3. Integrity & Score Calculation
            </h3>
            <p className="text-slate-600 leading-relaxed">
              In accordance with DGCA examination regulations, correct answers and detailed explanations will be revealed only after the exam has been formally submitted. Do not refresh or tamper with browser storage during the live test session.
            </p>
          </div>
        </div>

        {/* Agreement Checkbox */}
        <div className="p-4 bg-aviation-50 rounded-2xl border border-aviation-200 mb-8 flex items-start space-x-3">
          <input
            type="checkbox"
            id="agree-rules"
            disabled={isLocked}
            checked={hasAgreed}
            onChange={(e) => setHasAgreed(e.target.checked)}
            className="mt-0.5 h-4 w-4 rounded border-slate-300 text-aviation-900 focus:ring-aviation-800 disabled:opacity-50"
          />
          <label htmlFor="agree-rules" className={`text-xs font-semibold leading-relaxed ${isLocked ? "text-slate-400" : "text-aviation-950"}`}>
            I confirm that I have read and understood all DGCA examination guidelines, question palette symbols, and timing protocols. I am ready to begin my test session.
          </label>
        </div>

        {/* Action Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <Link
            href="/mock-exams"
            className="py-3 px-6 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors w-full sm:w-auto text-center"
          >
            ← Return to Exam Catalog
          </Link>

          {isLocked ? (
            <Link
              href="/pricing"
              className="py-3.5 px-8 rounded-xl text-sm font-bold text-white bg-amber-600 hover:bg-amber-500 transition-all shadow-md w-full sm:w-auto text-center flex items-center justify-center space-x-2"
            >
              <span>🔒 Upgrade to Unlock Exam</span>
            </Link>
          ) : !hasQuestions ? (
            <div className="flex flex-col sm:flex-row items-center gap-2">
              <span className="text-xs font-semibold text-amber-700 bg-amber-50 px-3 py-2 rounded-xl border border-amber-200">
                📝 Paper Awaiting Question Bank Loading
              </span>
              <button
                type="button"
                disabled
                className="py-3.5 px-8 rounded-xl text-sm font-bold text-white bg-slate-400 opacity-60 cursor-not-allowed transition-all shadow-md w-full sm:w-auto text-center"
              >
                Paper Not Yet Active
              </button>
            </div>
          ) : (
            <button
              type="button"
              disabled={!hasAgreed}
              onClick={handleStartExam}
              className="py-3.5 px-8 rounded-xl text-sm font-bold text-white bg-aviation-900 hover:bg-aviation-800 disabled:opacity-40 transition-all shadow-md w-full sm:w-auto text-center"
            >
              Launch CBT Examination →
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
