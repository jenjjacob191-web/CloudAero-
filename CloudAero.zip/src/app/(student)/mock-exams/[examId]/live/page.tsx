"use client";

import React, { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { MOCK_EXAMS_CATALOG } from "@/data/mockExamsData";
import { useAuth } from "@/lib/auth-context";
import { recordRealMockAttempt } from "@/lib/user-progress";
import FlightComputerModal from "@/components/exam/FlightComputerModal";

interface PageProps {
  params: {
    examId: string;
  };
}

export default function LiveMockExamPage({ params }: PageProps) {
  const router = useRouter();
  const { profile, isPremium } = useAuth();
  const examId = params.examId;
  const exam = MOCK_EXAMS_CATALOG.find((e) => e.id === examId) || MOCK_EXAMS_CATALOG[0];

  // Access control: verified via Supabase profiles.is_premium
  const isLocked = !isPremium;

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
  const [markedForReview, setMarkedForReview] = useState<Record<number, boolean>>({});
  const [visitedQuestions, setVisitedQuestions] = useState<Record<number, boolean>>({ 0: true });

  // Flight Computer Modal & Cockpit Audio FX
  const [isCalcOpen, setIsCalcOpen] = useState(false);
  const [isSoundEnabled, setIsSoundEnabled] = useState(true);

  // Countdown timer in seconds
  const totalDurationSeconds = exam.durationMinutes * 60;
  const [secondsRemaining, setSecondsRemaining] = useState(totalDurationSeconds);
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const currentQuestion = exam.questions[currentIndex] || exam.questions[0];

  // Synthesized Cockpit Chime (Web Audio API)
  const playCockpitAudio = useCallback((type: "beep" | "ding" | "alert" = "beep") => {
    if (!isSoundEnabled || typeof window === "undefined") return;
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      const audioCtx = new AudioContextClass();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      if (type === "beep") {
        osc.frequency.setValueAtTime(750, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.03, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.08);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.08);
      } else if (type === "ding") {
        osc.frequency.setValueAtTime(1046.5, audioCtx.currentTime); // C6 note
        gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.2);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.2);
      } else if (type === "alert") {
        osc.frequency.setValueAtTime(440, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.06, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.3);
      }
    } catch {
      // Audio autoplay policy handled silently
    }
  }, [isSoundEnabled]);

  // Auto-submit handler
  const performSubmission = useCallback(() => {
    setIsSubmitting(true);
    const attemptId = `attempt-${Date.now()}`;
    const timeSpentSeconds = totalDurationSeconds - secondsRemaining;

    // Calculate real score and record attempt
    let correctCount = 0;
    exam.questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctOptionId) {
        correctCount++;
      }
    });
    const percentage = exam.questions.length > 0 ? Math.round((correctCount / exam.questions.length) * 100) : 0;
    const passed = percentage >= exam.passingPercentage;

    recordRealMockAttempt({
      id: attemptId,
      examId: exam.id,
      examTitle: exam.title,
      subjectName: exam.subjectName,
      score: correctCount,
      totalQuestions: exam.questions.length,
      percentage,
      passed,
      timeSpentSeconds,
      completedAt: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
    });

    // Cache the candidate's answers in sessionStorage for instant scorecard evaluation
    if (typeof window !== "undefined") {
      sessionStorage.setItem(
        `mock-result-${attemptId}`,
        JSON.stringify({
          examId: exam.id,
          selectedAnswers,
          timeSpentSeconds,
          completedAt: new Date().toISOString(),
        })
      );
    }

    setTimeout(() => {
      router.push(`/mock-exams/${exam.id}/result/${attemptId}`);
    }, 1000);
  }, [exam, router, secondsRemaining, selectedAnswers, totalDurationSeconds]);

  // Timer countdown
  useEffect(() => {
    if (isLocked) return;

    if (secondsRemaining <= 0) {
      performSubmission();
      return;
    }

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [secondsRemaining, performSubmission, isLocked]);

  // Format time as HH:MM:SS
  const formatTime = (totalSec: number) => {
    const hours = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    return `${hours.toString().padStart(2, "0")}:${mins
      .toString()
      .padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // Jump to specific question
  const jumpToQuestion = useCallback((index: number) => {
    setCurrentIndex(index);
    setVisitedQuestions((prev) => ({ ...prev, [index]: true }));
    playCockpitAudio("beep");
  }, [playCockpitAudio]);

  // Select option
  const handleSelectOption = useCallback((optionId: string) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [currentIndex]: optionId,
    }));
    playCockpitAudio("ding");
  }, [currentIndex, playCockpitAudio]);

  // Clear choice
  const handleClearResponse = () => {
    setSelectedAnswers((prev) => {
      const next = { ...prev };
      delete next[currentIndex];
      return next;
    });
    playCockpitAudio("alert");
  };

  // Mark for review & next
  const handleMarkForReview = useCallback(() => {
    setMarkedForReview((prev) => ({
      ...prev,
      [currentIndex]: true,
    }));
    playCockpitAudio("alert");
    if (currentIndex < (exam.questions?.length || 0) - 1) {
      jumpToQuestion(currentIndex + 1);
    }
  }, [currentIndex, exam.questions?.length, jumpToQuestion, playCockpitAudio]);

  // Global Keyboard shortcuts for authentic CBT station experience
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      if (e.key === "ArrowRight" || e.key.toLowerCase() === "n") {
        if (currentIndex < (exam.questions?.length || 0) - 1) {
          jumpToQuestion(currentIndex + 1);
        }
      } else if (e.key === "ArrowLeft" || e.key.toLowerCase() === "p") {
        if (currentIndex > 0) {
          jumpToQuestion(currentIndex - 1);
        }
      } else if (e.key.toLowerCase() === "m") {
        handleMarkForReview();
      } else if (e.key.toLowerCase() === "c" && !e.ctrlKey && !e.metaKey) {
        setIsCalcOpen((prev) => !prev);
      } else if (["1", "2", "3", "4"].includes(e.key)) {
        const optionIdx = parseInt(e.key) - 1;
        if (currentQuestion?.options?.[optionIdx]) {
          handleSelectOption(currentQuestion.options[optionIdx].id);
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentIndex, exam.questions?.length, currentQuestion, handleMarkForReview, handleSelectOption, jumpToQuestion]);

  // If unauthorized user attempted to bypass lock
  if (isLocked) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center text-3xl mx-auto font-bold">
            🔒
          </div>
          <h2 className="text-xl font-extrabold text-aviation-950">
            Premium Mock Examination Restricted
          </h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            This DGCA CBT examination simulator is strictly accessible to active Monthly or Six-Month subscribers. Direct URL bypass is prohibited.
          </p>
          <div className="pt-2 flex flex-col gap-2">
            <Link
              href="/pricing"
              className="py-3 px-4 rounded-xl text-xs font-bold bg-aviation-900 hover:bg-aviation-800 text-white transition-colors text-center shadow-md"
            >
              Activate Pass (₹300/mo) →
            </Link>
            <Link
              href="/mock-exams"
              className="py-2.5 px-4 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors text-center"
            >
              ← Return to Mock Exam Catalog
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // If exam has no questions loaded yet
  if (!exam.questions || exam.questions.length === 0) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-aviation-100 text-aviation-800 flex items-center justify-center text-3xl mx-auto font-bold">
            📝
          </div>
          <h2 className="text-xl font-extrabold text-aviation-950">
            Exam Paper Being Prepared
          </h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            No questions have been published for this mock examination yet. Real questions will be uploaded by administrators.
          </p>
          <div className="flex flex-col gap-2 pt-2">
            <Link
              href="/mock-exams"
              className="w-full py-3 px-4 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 transition"
            >
              Return to Mock Exams
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Summary counts for question palette
  const totalCount = exam.questions.length;
  const answeredCount = Object.keys(selectedAnswers).length;
  const markedCount = Object.keys(markedForReview).filter(
    (k) => markedForReview[Number(k)]
  ).length;
  const notVisitedCount = totalCount - Object.keys(visitedQuestions).length;
  const notAnsweredCount = totalCount - answeredCount;

  // Determine question status in palette
  const getQuestionPaletteClass = (idx: number) => {
    const isCurrent = idx === currentIndex;
    const isAnswered = !!selectedAnswers[idx];
    const isMarked = !!markedForReview[idx];
    const isVisited = !!visitedQuestions[idx];

    let base =
      "w-9 h-9 sm:w-10 sm:h-10 rounded-xl font-bold text-xs flex items-center justify-center transition-all cursor-pointer relative ";

    if (isCurrent) {
      base += "ring-2 ring-skyAccent-500 ring-offset-2 scale-105 z-10 ";
    }

    if (isMarked) {
      return base + "bg-amber-500 text-white shadow-xs";
    }
    if (isAnswered) {
      return base + "bg-emerald-600 text-white shadow-xs";
    }
    if (isVisited) {
      return base + "bg-rose-500 text-white shadow-xs";
    }
    return base + "bg-slate-200 text-slate-700 hover:bg-slate-300";
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col select-none">
      {/* Cockpit Exam Bar */}
      <header className="bg-aviation-950 border-b border-aviation-800/80 px-4 sm:px-6 py-3 flex items-center justify-between sticky top-0 z-30 shadow-lg">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-skyAccent-400 text-aviation-950 flex items-center justify-center font-bold text-sm">
            ✈️
          </div>
          <div>
            <h1 className="text-xs sm:text-sm font-extrabold text-white tracking-tight line-clamp-1">
              {exam.title}
            </h1>
            <span className="text-[10px] text-skyAccent-300 block font-mono">
              DGCA CBT Candidate: {profile?.full_name || "Student Candidate"} (CPL / ATPL)
            </span>
          </div>
        </div>

        {/* Flight Instruments & Tools */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Flight Computer Trigger */}
          <button
            type="button"
            onClick={() => setIsCalcOpen(true)}
            className="px-2.5 sm:px-3 py-1.5 rounded-xl border border-skyAccent-500/40 bg-skyAccent-950/40 hover:bg-skyAccent-900/60 text-skyAccent-300 font-mono text-xs font-bold transition-all flex items-center space-x-1.5 shadow-sm"
            title="Open CX-3 / E6B Flight Computer & Calculator (Press 'C')"
          >
            <span>🧮</span>
            <span className="hidden md:inline">CX-3 Flight Computer</span>
            <span className="text-[10px] px-1 py-0.2 rounded bg-skyAccent-500/20 text-skyAccent-200">[C]</span>
          </button>

          {/* Cockpit Audio Toggle */}
          <button
            type="button"
            onClick={() => setIsSoundEnabled((prev) => !prev)}
            className={`p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl border text-xs font-mono transition-colors flex items-center space-x-1 ${
              isSoundEnabled
                ? "bg-aviation-900 border-aviation-700 text-emerald-400"
                : "bg-aviation-950 border-aviation-800 text-slate-500"
            }`}
            title="Toggle Cockpit Audio Feedback"
          >
            <span>{isSoundEnabled ? "🔊" : "🔇"}</span>
            <span className="hidden lg:inline text-[11px]">{isSoundEnabled ? "CHIME ON" : "MUTED"}</span>
          </button>

          {/* Chronometer */}
          <div
            className={`px-2.5 sm:px-4 py-1.5 rounded-xl border flex items-center space-x-2 font-mono font-bold text-xs sm:text-base ${
              secondsRemaining < 300
                ? "bg-rose-500/20 border-rose-500 text-rose-300 animate-pulse"
                : "bg-aviation-900 border-aviation-700 text-skyAccent-300"
            }`}
          >
            <span className="text-xs">⏱️</span>
            <span>{formatTime(secondsRemaining)}</span>
          </div>

          <button
            onClick={() => setIsSubmitModalOpen(true)}
            className="hidden sm:inline-flex items-center px-4 py-1.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors shadow-sm"
          >
            Submit Exam
          </button>
        </div>
      </header>

      {/* Main Examination Grid */}
      <div className="flex-grow flex flex-col lg:flex-row max-w-7xl w-full mx-auto p-3 sm:p-6 gap-6">
        {/* Left Column: Question Area */}
        <div className="flex-grow flex flex-col justify-between bg-white text-aviation-950 rounded-3xl p-5 sm:p-8 shadow-2xl border border-slate-200">
          <div>
            {/* Question Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 text-xs">
              <span className="font-bold text-aviation-900 bg-aviation-50 px-3 py-1 rounded-lg border border-aviation-200">
                Question {currentIndex + 1} of {exam.questions.length}
              </span>
              <div className="flex items-center space-x-3 text-[11px] text-slate-500 font-medium">
                <span>Marks: +{exam.marksPerQuestion}</span>
                {exam.negativeMarking > 0 && (
                  <span className="text-rose-600">Negative: -{exam.negativeMarking}</span>
                )}
              </div>
            </div>

            {/* Question Text */}
            <div className="py-6">
              <h2 className="text-sm sm:text-base font-bold text-aviation-950 leading-relaxed font-sans">
                {currentQuestion.questionText}
              </h2>
            </div>

            {/* Options List */}
            <div className="space-y-3 pt-2">
              {currentQuestion.options.map((opt, optIdx) => {
                const isSelected = selectedAnswers[currentIndex] === opt.id;
                return (
                  <button
                    key={opt.id}
                    onClick={() => handleSelectOption(opt.id)}
                    className={`w-full text-left p-4 rounded-2xl border transition-all flex items-start justify-between space-x-3.5 group ${
                      isSelected
                        ? "bg-skyAccent-50 border-skyAccent-500 ring-2 ring-skyAccent-400/40 text-aviation-950 font-semibold"
                        : "bg-slate-50 border-slate-200 hover:bg-slate-100 hover:border-slate-300 text-slate-800"
                    }`}
                  >
                    <div className="flex items-start space-x-3.5">
                      <span
                        className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs flex-shrink-0 transition-colors ${
                          isSelected
                            ? "bg-aviation-900 text-white"
                            : "bg-white border border-slate-300 text-slate-600 group-hover:border-aviation-400"
                        }`}
                      >
                        {opt.label}
                      </span>
                      <span className="text-xs sm:text-sm pt-0.5 leading-relaxed">{opt.text}</span>
                    </div>
                    <span className="hidden sm:inline-block font-mono text-[10px] text-slate-400 group-hover:text-slate-600 px-1.5 py-0.5 rounded bg-slate-200/50">
                      [{optIdx + 1}]
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Question Bottom Action Bar */}
          <div className="mt-8 pt-6 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center space-x-2">
              <button
                onClick={handleMarkForReview}
                className="px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-50 text-amber-900 border border-amber-300 hover:bg-amber-100 transition-colors flex items-center space-x-1"
              >
                <span>⭐</span>
                <span>Mark for Review</span>
                <span className="font-mono text-[10px] text-amber-700 bg-amber-200/60 px-1 rounded">[M]</span>
              </button>
              <button
                onClick={handleClearResponse}
                disabled={!selectedAnswers[currentIndex]}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:text-rose-600 hover:bg-rose-50 transition-colors disabled:opacity-30"
              >
                Clear Response
              </button>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => jumpToQuestion(Math.max(0, currentIndex - 1))}
                disabled={currentIndex === 0}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 disabled:opacity-30 transition-colors flex items-center space-x-1"
              >
                <span>← Previous</span>
                <span className="font-mono text-[10px] text-slate-500 bg-slate-200 px-1 rounded">[P]</span>
              </button>
              <button
                onClick={() =>
                  jumpToQuestion(Math.min(exam.questions.length - 1, currentIndex + 1))
                }
                disabled={currentIndex === exam.questions.length - 1}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 disabled:opacity-30 transition-colors flex items-center space-x-1"
              >
                <span>Save & Next →</span>
                <span className="font-mono text-[10px] text-skyAccent-300 bg-aviation-800 px-1 rounded">[N]</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Question Palette & Overview */}
        <div className="w-full lg:w-80 flex-shrink-0 bg-aviation-950 rounded-3xl p-5 border border-aviation-800 shadow-2xl flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-extrabold text-white uppercase tracking-wider mb-4 pb-2 border-b border-aviation-800 flex items-center justify-between">
              <span>Question Palette</span>
              <span className="text-skyAccent-400 font-mono text-[11px]">
                {currentIndex + 1} / {totalCount}
              </span>
            </h3>

            {/* Status Legend */}
            <div className="grid grid-cols-2 gap-2 text-[10px] mb-5">
              <div className="flex items-center space-x-2 bg-aviation-900/60 p-2 rounded-xl border border-aviation-800">
                <span className="w-3 h-3 rounded-md bg-emerald-600" />
                <span className="text-slate-300">Answered ({answeredCount})</span>
              </div>
              <div className="flex items-center space-x-2 bg-aviation-900/60 p-2 rounded-xl border border-aviation-800">
                <span className="w-3 h-3 rounded-md bg-rose-500" />
                <span className="text-slate-300">Not Answered ({notAnsweredCount})</span>
              </div>
              <div className="flex items-center space-x-2 bg-aviation-900/60 p-2 rounded-xl border border-aviation-800">
                <span className="w-3 h-3 rounded-md bg-amber-500" />
                <span className="text-slate-300">Marked ({markedCount})</span>
              </div>
              <div className="flex items-center space-x-2 bg-aviation-900/60 p-2 rounded-xl border border-aviation-800">
                <span className="w-3 h-3 rounded-md bg-slate-400" />
                <span className="text-slate-300">Not Visited ({notVisitedCount})</span>
              </div>
            </div>

            {/* Matrix of Question Buttons */}
            <div className="grid grid-cols-5 gap-2 max-h-72 overflow-y-auto p-1">
              {exam.questions.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => jumpToQuestion(idx)}
                  className={getQuestionPaletteClass(idx)}
                >
                  {idx + 1}
                </button>
              ))}
            </div>
          </div>

          {/* Submit Button on Mobile & Bottom */}
          <div className="pt-6 border-t border-aviation-800 mt-6">
            <button
              onClick={() => setIsSubmitModalOpen(true)}
              className="w-full py-3 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-lg flex items-center justify-center space-x-2"
            >
              <span>🏁</span>
              <span>Final Exam Submission</span>
            </button>
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      {isSubmitModalOpen && (
        <div className="fixed inset-0 z-50 bg-aviation-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full text-aviation-950 shadow-2xl border border-slate-200 space-y-4">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xl mx-auto mb-3">
                ✓
              </div>
              <h3 className="text-lg font-extrabold text-aviation-950">
                Confirm Examination Submission?
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Once submitted, answers cannot be altered and your official DGCA score will be generated.
              </p>
            </div>

            {/* Candidate Summary */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Total Questions:</span>
                <span className="font-bold text-aviation-900">{totalCount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Answered:</span>
                <span className="font-bold text-emerald-600">{answeredCount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Marked for Review:</span>
                <span className="font-bold text-amber-600">{markedCount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Unanswered / Left:</span>
                <span className="font-bold text-rose-600">{notAnsweredCount}</span>
              </div>
            </div>

            <div className="flex items-center space-x-3 pt-2">
              <button
                onClick={() => setIsSubmitModalOpen(false)}
                className="w-1/2 py-2.5 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors"
              >
                Resume Exam
              </button>
              <button
                onClick={performSubmission}
                disabled={isSubmitting}
                className="w-1/2 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 transition-colors shadow-md flex items-center justify-center space-x-1"
              >
                {isSubmitting ? (
                  <span>Evaluating...</span>
                ) : (
                  <>
                    <span>Confirm & Submit</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CX-3 / E6B Flight Computer & Calculator Modal */}
      <FlightComputerModal
        isOpen={isCalcOpen}
        onClose={() => setIsCalcOpen(false)}
      />
    </div>
  );
}
