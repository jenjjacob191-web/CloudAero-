"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { DGCA_SUBJECTS_DEMO } from "@/data/mockData";
import {
  getRealStudentStats,
  getRealMockAttempts,
  getRealBookmarks,
  StudentStats,
  RealMockAttempt,
  RealBookmarkedQuestion,
} from "@/lib/user-progress";

export default function StudentDashboardPage() {
  const { user, profile, subscription, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<"overview" | "subjects" | "exams" | "bookmarks">("overview");
  const [isBriefingOpen, setIsBriefingOpen] = useState(false);
  const [briefingStep, setBriefingStep] = useState(1);

  // Real, dynamic student analytics state
  const [stats, setStats] = useState<StudentStats>({
    totalQuestionsPracticed: 0,
    totalCorrect: 0,
    accuracyPercentage: 0,
    chaptersCompleted: 0,
    totalChapters: 24,
    mockAttemptsCount: 0,
    mockAttemptsPassed: 0,
    subjectProgress: {
      "air-regulations": { attempted: 0, total: 0, accuracy: 0 },
      "aviation-meteorology": { attempted: 0, total: 0, accuracy: 0 },
      "air-navigation": { attempted: 0, total: 0, accuracy: 0 },
      "technical-general": { attempted: 0, total: 0, accuracy: 0 },
      "technical-specific": { attempted: 0, total: 0, accuracy: 0 },
    },
  });
  const [mockAttempts, setMockAttempts] = useState<RealMockAttempt[]>([]);
  const [bookmarks, setBookmarks] = useState<RealBookmarkedQuestion[]>([]);

  // Load real student progress from client storage
  useEffect(() => {
    setStats(getRealStudentStats());
    setMockAttempts(getRealMockAttempts());
    setBookmarks(getRealBookmarks());
  }, []);

  // If not logged in and not loading, show prompt or auto demo
  if (!isLoading && !user) {
    return (
      <div className="min-h-[calc(100vh-80px)] py-16 px-4 max-w-lg mx-auto flex flex-col justify-center items-center text-center">
        <div className="w-16 h-16 rounded-3xl bg-aviation-50 border border-aviation-200 flex items-center justify-center text-aviation-900 mb-4 shadow-sm">
          <svg className="w-8 h-8 text-aviation-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
          </svg>
        </div>
        <h2 className="text-2xl font-extrabold text-aviation-900">Protected Student Flight Deck</h2>
        <p className="text-sm text-slate-500 mt-2 mb-6">
          Please log in to your personal account to review test progress, exam scorecards, and bookmarks.
        </p>
        <div className="space-y-3 w-full">
          <Link
            href="/login"
            className="w-full inline-block py-3 px-6 rounded-xl text-sm font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-md transition-colors"
          >
            Log In to Your Account
          </Link>
          <Link
            href="/register"
            className="w-full inline-block py-3 px-6 rounded-xl text-sm font-semibold text-aviation-800 bg-skyAccent-50 hover:bg-skyAccent-100 border border-skyAccent-200 transition-colors"
          >
            Register New Cadet Account →
          </Link>
        </div>
      </div>
    );
  }

  // Calculate days remaining in subscription
  let daysRemaining = 0;
  if (subscription?.expires_at) {
    const diff = new Date(subscription.expires_at).getTime() - new Date().getTime();
    daysRemaining = Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  }

  const candidateId = user?.id ? `IND-CPL-${user.id.substring(0, 6).toUpperCase()}` : "IND-CPL-DEMO";

  // Dynamic Pilot Epaulet Rank Insignia Calculation
  const passedMocks = stats.mockAttemptsPassed;
  let pilotRank = {
    title: "Cadet Pilot",
    stripes: 1,
    description: "Student Pilot — Ground Theory Phase",
  };
  if (passedMocks >= 8 && stats.accuracyPercentage >= 75) {
    pilotRank = {
      title: "Senior Flight Captain",
      stripes: 4,
      description: "DGCA ATPL Ready — Master Aviator",
    };
  } else if (passedMocks >= 4 && stats.accuracyPercentage >= 70) {
    pilotRank = {
      title: "First Officer (CPL)",
      stripes: 3,
      description: "DGCA CPL Theory Proficient",
    };
  } else if (passedMocks >= 1 || stats.chaptersCompleted >= 3) {
    pilotRank = {
      title: "Junior First Officer",
      stripes: 2,
      description: "PPL / CPL Intermediate Cadet",
    };
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50/40 via-white to-sky-50/30 pb-20">
      {/* Flight Deck Header Banner */}
      <section className="bg-gradient-to-r from-sky-600 via-sky-500 to-blue-600 text-white border-b border-sky-400 pt-8 pb-12 px-4 sm:px-6 lg:px-8 shadow-sm">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-2xl font-bold text-skyAccent-300 shadow-inner">
              {profile?.full_name?.charAt(0) || "P"}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-3">
                <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                  {profile?.full_name || "Cadet Pilot"}
                </h1>
                <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-skyAccent-400 text-aviation-950">
                  {profile?.role === "admin" ? "Flight Instructor / Admin" : "Student Pilot"}
                </span>

                {/* Pilot Epaulet Rank Insignia */}
                <div
                  className="flex items-center space-x-2 px-2.5 py-1 rounded-xl bg-aviation-950/80 border border-amber-400/40 shadow-inner"
                  title={pilotRank.description}
                >
                  <div className="flex flex-col space-y-0.5">
                    {Array.from({ length: pilotRank.stripes }).map((_, i) => (
                      <span key={i} className="w-4 h-1 rounded-xs bg-amber-400 shadow-xs" />
                    ))}
                  </div>
                  <div className="text-left font-mono">
                    <span className="text-[10px] text-amber-300 font-bold block leading-tight">{pilotRank.title}</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-3 mt-2">
                <p className="text-xs text-slate-300 flex items-center space-x-2">
                  <span>{profile?.email}</span>
                  <span>•</span>
                  <span className="font-mono text-skyAccent-300 font-bold">ID: {candidateId}</span>
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setBriefingStep(1);
                    setIsBriefingOpen(true);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-skyAccent-400/20 hover:bg-skyAccent-400/30 text-skyAccent-200 border border-skyAccent-400/40 text-[11px] font-bold flex items-center space-x-1.5 transition-colors"
                >
                  <span>🧭</span>
                  <span>Pre-Flight Briefing Tour</span>
                </button>
              </div>
            </div>
          </div>

          {/* Subscription Validity Badge */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/15 flex items-center space-x-4">
            <div className="w-10 h-10 rounded-xl bg-skyAccent-400/20 border border-skyAccent-400/30 flex items-center justify-center text-skyAccent-300">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
              </svg>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs text-slate-300 font-medium">Subscription Tier:</span>
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wide">
                  {subscription?.status === "active" ? "Premium Active" : "Standard Student"}
                </span>
              </div>
              <p className="text-xs font-semibold text-white mt-0.5">
                {subscription?.status === "active"
                  ? `${daysRemaining} Days Remaining (Active Pass)`
                  : "Standard Tier (Upgrade for CBT mock exams)"}
              </p>
            </div>
            {subscription?.status !== "active" && (
              <Link
                href="/pricing"
                className="px-3 py-1.5 rounded-lg bg-skyAccent-400 hover:bg-skyAccent-300 text-aviation-950 font-bold text-xs"
              >
                Upgrade
              </Link>
            )}
          </div>
        </div>
      </section>

      {/* Main Dashboard Body */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6">
        {/* Top 4 Real Metric Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {/* 1. Overall Accuracy */}
          <div className="bg-white p-6 rounded-2xl border border-aviation-100 shadow-sm flex flex-col justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Overall Accuracy</span>
            <div className="flex items-baseline space-x-2 my-2">
              <span className="text-3xl sm:text-4xl font-extrabold text-aviation-900 font-sans">
                {stats.totalQuestionsPracticed > 0 ? `${stats.accuracyPercentage}%` : "0.0%"}
              </span>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                  stats.totalQuestionsPracticed === 0
                    ? "bg-slate-100 text-slate-600"
                    : stats.accuracyPercentage >= 70
                    ? "bg-emerald-50 text-emerald-700"
                    : "bg-amber-50 text-amber-700"
                }`}
              >
                {stats.totalQuestionsPracticed === 0
                  ? "No Drills Yet"
                  : stats.accuracyPercentage >= 70
                  ? "Passing Grade"
                  : "Needs Revision"}
              </span>
            </div>
            <span className="text-[11px] text-slate-400">
              {stats.totalQuestionsPracticed > 0
                ? `${stats.totalCorrect} / ${stats.totalQuestionsPracticed} Correct (Pass Norm: 70%)`
                : "DGCA CPL Passing Norm: 70%"}
            </span>
          </div>

          {/* 2. Questions Practiced */}
          <div className="bg-white p-6 rounded-2xl border border-aviation-100 shadow-sm flex flex-col justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Questions Practiced</span>
            <div className="flex items-baseline space-x-2 my-2">
              <span className="text-3xl sm:text-4xl font-extrabold text-aviation-900 font-sans">
                {stats.totalQuestionsPracticed}
              </span>
              <span className="text-xs font-medium text-slate-400">/ 2,450 Total</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-1.5 mt-1 overflow-hidden">
              <div
                className="bg-skyAccent-500 h-1.5 rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, Math.max(0, (stats.totalQuestionsPracticed / 2450) * 100))}%` }}
              />
            </div>
          </div>

          {/* 3. Chapters Completed */}
          <div className="bg-white p-6 rounded-2xl border border-aviation-100 shadow-sm flex flex-col justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Chapters Completed</span>
            <div className="flex items-baseline space-x-2 my-2">
              <span className="text-3xl sm:text-4xl font-extrabold text-aviation-900 font-sans">
                {stats.chaptersCompleted}
              </span>
              <span className="text-xs font-medium text-slate-400">/ {stats.totalChapters} Chapters</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-1.5 mt-1 overflow-hidden">
              <div
                className="bg-emerald-500 h-1.5 rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, Math.max(0, (stats.chaptersCompleted / stats.totalChapters) * 100))}%` }}
              />
            </div>
          </div>

          {/* 4. Timed Mocks Attempted */}
          <div className="bg-white p-6 rounded-2xl border border-aviation-100 shadow-sm flex flex-col justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Timed CBT Mocks</span>
            <div className="flex items-baseline space-x-2 my-2">
              <span className="text-3xl sm:text-4xl font-extrabold text-aviation-900 font-sans">
                {stats.mockAttemptsCount}
              </span>
              <span className="text-xs font-medium text-slate-400">
                {stats.mockAttemptsCount > 0 ? `(${stats.mockAttemptsPassed} Passed)` : "Attempted"}
              </span>
            </div>
            <span className="text-[11px] text-slate-400">
              {stats.mockAttemptsCount > 0 ? "Official CBT Simulator" : "No mocks completed yet"}
            </span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="mt-10 border-b border-sky-100 flex space-x-8 overflow-x-auto text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab("overview")}
            className={`pb-4 text-sm font-bold border-b-2 transition-all ${
              activeTab === "overview"
                ? "border-sky-500 text-sky-600"
                : "border-transparent text-slate-500 hover:text-sky-700"
            }`}
          >
            Study Overview
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("subjects")}
            className={`pb-4 text-sm font-bold border-b-2 transition-all ${
              activeTab === "subjects"
                ? "border-sky-500 text-sky-600"
                : "border-transparent text-slate-500 hover:text-sky-700"
            }`}
          >
            Syllabus Subjects (5)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("exams")}
            className={`pb-4 text-sm font-bold border-b-2 transition-all ${
              activeTab === "exams"
                ? "border-sky-500 text-sky-600"
                : "border-transparent text-slate-500 hover:text-sky-700"
            }`}
          >
            Mock Exam History ({mockAttempts.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("bookmarks")}
            className={`pb-4 text-sm font-bold border-b-2 transition-all ${
              activeTab === "bookmarks"
                ? "border-sky-500 text-sky-600"
                : "border-transparent text-slate-500 hover:text-sky-700"
            }`}
          >
            Bookmarked Questions ({bookmarks.length})
          </button>
        </div>

        {/* Tab 1: Overview */}
        {activeTab === "overview" && (
          <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              {/* Study Drill Recommendation */}
              <div className="bg-white rounded-2xl border border-aviation-100 p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-bold text-aviation-900">
                    {stats.totalQuestionsPracticed === 0 ? "Begin Your Flight Training" : "Targeted Practice Drill"}
                  </h3>
                  <span className="text-xs font-semibold text-skyAccent-800 bg-skyAccent-50 px-2.5 py-1 rounded-full border border-skyAccent-200">
                    {stats.totalQuestionsPracticed === 0 ? "Step 1: Chapter Drill" : "Continuous Practice"}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {stats.totalQuestionsPracticed === 0
                    ? "Welcome to your flight deck, Candidate! You have not completed any chapter drills yet. Begin with Chapter 1: Atmospheric Pressure & Altimetry to practice question navigation and formula derivations."
                    : `You have practiced ${stats.totalQuestionsPracticed} questions with ${stats.accuracyPercentage}% accuracy. Continue practicing chapter drills to keep your scores above the 70% DGCA passing threshold.`}
                </p>
                <div className="mt-5 flex items-center space-x-3">
                  <Link
                    href="/practice/pressure-and-altimetry"
                    className="inline-flex items-center px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-sm transition-colors"
                  >
                    Start Altimetry Drill (20 Qs) →
                  </Link>
                  <Link
                    href="/subjects"
                    className="inline-flex items-center px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
                  >
                    Browse All Subjects
                  </Link>
                </div>
              </div>

              {/* Recent Mock Table */}
              <div className="bg-white rounded-2xl border border-aviation-100 p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-bold text-aviation-900">
                    Recent Mock Examination Attempts
                  </h3>
                  <Link href="/mock-exams" className="text-xs font-semibold text-skyAccent-700 hover:underline">
                    Take New Mock →
                  </Link>
                </div>

                {mockAttempts.length === 0 ? (
                  <div className="py-10 text-center text-xs text-slate-500 space-y-3">
                    <div className="text-3xl">⏱️</div>
                    <p className="font-bold text-aviation-950">No Mock Examinations Attempted Yet</p>
                    <p className="max-w-md mx-auto text-slate-500">
                      Take your first simulated Computer-Based Testing (CBT) mock exam to evaluate your score against the 70% passing benchmark.
                    </p>
                    <div className="pt-2">
                      <Link
                        href="/mock-exams"
                        className="inline-block px-4 py-2 rounded-xl text-xs font-bold bg-aviation-900 hover:bg-aviation-800 text-white shadow-xs transition-colors"
                      >
                        Launch CBT Mock Exam
                      </Link>
                    </div>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-slate-100 text-slate-400 font-semibold">
                          <th className="pb-3">Subject / Paper</th>
                          <th className="pb-3">Date</th>
                          <th className="pb-3">Score</th>
                          <th className="pb-3">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-600">
                        {mockAttempts.map((m) => (
                          <tr key={m.id}>
                            <td className="py-3 font-semibold text-aviation-900">{m.examTitle}</td>
                            <td className="py-3 text-slate-400">{m.completedAt}</td>
                            <td className="py-3 font-bold text-aviation-900">
                              {m.percentage}% ({m.score}/{m.totalQuestions})
                            </td>
                            <td className="py-3">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  m.passed
                                    ? "bg-emerald-100 text-emerald-800"
                                    : "bg-rose-100 text-rose-800"
                                }`}
                              >
                                {m.passed ? "PASSED (≥70%)" : "FAILED (<70%)"}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Actions Side Card */}
            <div className="space-y-6">
              <div className="bg-white rounded-2xl border border-aviation-100 p-6 shadow-sm space-y-4">
                <h3 className="text-sm font-bold text-aviation-900 uppercase tracking-wider">
                  Quick Access Flight Controls
                </h3>
                <div className="space-y-2.5 text-xs font-semibold">
                  <Link
                    href="/question-bank"
                    className="w-full p-3 rounded-xl bg-slate-50 hover:bg-slate-100 text-aviation-900 flex items-center justify-between border border-slate-100 transition-colors"
                  >
                    <span>Browse DGCA Question Bank</span>
                    <span>→</span>
                  </Link>
                  <Link
                    href="/mock-exams"
                    className="w-full p-3 rounded-xl bg-slate-50 hover:bg-slate-100 text-aviation-900 flex items-center justify-between border border-slate-100 transition-colors"
                  >
                    <span>Full CBT Mock Examination Room</span>
                    <span>→</span>
                  </Link>
                  <Link
                    href="/pricing"
                    className="w-full p-3 rounded-xl bg-skyAccent-50 hover:bg-skyAccent-100 text-aviation-950 flex items-center justify-between border border-skyAccent-200 transition-colors"
                  >
                    <span>Upgrade to Premium Access (₹300)</span>
                    <span>→</span>
                  </Link>
                </div>
              </div>

              <div className="bg-aviation-950 text-white rounded-2xl p-6 shadow-sm space-y-3">
                <div className="flex items-center space-x-2 text-skyAccent-400 text-xs font-bold">
                  <span>💡</span>
                  <span>DGCA Rule Reminder</span>
                </div>
                <h4 className="font-extrabold text-sm text-white">Minimum Passing Mark: 70%</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Under Aircraft Rules 1937, candidate pilots must achieve a score of 70% or higher in every theoretical knowledge examination.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Syllabus Subjects */}
        {activeTab === "subjects" && (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            {DGCA_SUBJECTS_DEMO.map((sub) => {
              const prog = stats.subjectProgress[sub.slug] || { attempted: 0, total: sub.questionsCount, accuracy: 0 };
              const percent = prog.total > 0 ? Math.round((prog.attempted / prog.total) * 100) : 0;
              return (
                <div key={sub.id} className="bg-white rounded-2xl border border-aviation-100 p-6 shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-mono text-[10px] font-bold text-skyAccent-700 bg-skyAccent-50 px-2 py-0.5 rounded">
                        {sub.code}
                      </span>
                      <h3 className="text-base font-extrabold text-aviation-900 mt-1">{sub.name}</h3>
                    </div>
                    <span className="text-xs font-bold text-slate-500">{percent}% Practiced</span>
                  </div>

                  <p className="text-xs text-slate-500 leading-relaxed line-clamp-2">{sub.description}</p>

                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] text-slate-400 font-medium">
                      <span>Questions Attempted: {prog.attempted}</span>
                      <span>Chapters: {sub.chaptersCount}</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-aviation-900 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-xs text-slate-400 font-medium">{sub.chaptersCount} Chapters</span>
                    <Link
                      href={`/subjects/${sub.slug}`}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-aviation-900 hover:bg-aviation-800 text-white transition-colors"
                    >
                      Open Subject →
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Tab 3: Mock Exam History */}
        {activeTab === "exams" && (
          <div className="mt-8 bg-white rounded-2xl border border-aviation-100 p-6 sm:p-8 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-extrabold text-aviation-900">Your Official Examination Attempts</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Real simulation test results evaluated against DGCA passing guidelines.
                </p>
              </div>
              <Link
                href="/mock-exams"
                className="px-4 py-2 rounded-xl text-xs font-bold bg-aviation-900 hover:bg-aviation-800 text-white transition-colors"
              >
                Launch New Mock Test
              </Link>
            </div>

            {mockAttempts.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-500 space-y-3">
                <div className="text-4xl">📊</div>
                <h4 className="text-base font-bold text-aviation-900">No Mock Exam History</h4>
                <p className="max-w-md mx-auto text-slate-500 leading-relaxed">
                  You have not attempted any timed computer-based mock exams yet. Take your first test to record your score here.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-100 text-slate-400 font-semibold">
                      <th className="pb-3">Exam Paper</th>
                      <th className="pb-3">Subject</th>
                      <th className="pb-3">Date</th>
                      <th className="pb-3">Score</th>
                      <th className="pb-3">Percentage</th>
                      <th className="pb-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-600">
                    {mockAttempts.map((m) => (
                      <tr key={m.id}>
                        <td className="py-3.5 font-bold text-aviation-900">{m.examTitle}</td>
                        <td className="py-3.5 text-slate-500">{m.subjectName}</td>
                        <td className="py-3.5 text-slate-400">{m.completedAt}</td>
                        <td className="py-3.5 font-bold text-aviation-900">{m.score} / {m.totalQuestions}</td>
                        <td className="py-3.5 font-extrabold text-aviation-900">{m.percentage}%</td>
                        <td className="py-3.5">
                          <span
                            className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                              m.passed ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"
                            }`}
                          >
                            {m.passed ? "PASSED (≥70%)" : "FAILED (<70%)"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Bookmarked Questions */}
        {activeTab === "bookmarks" && (
          <div className="mt-8 space-y-4">
            <div className="flex items-center justify-between mb-2">
              <div>
                <h3 className="text-lg font-extrabold text-aviation-900">Bookmarked Questions for Revision</h3>
                <p className="text-xs text-slate-500">
                  Questions you flagged with a star during chapter drills for quick recall.
                </p>
              </div>
            </div>

            {bookmarks.length === 0 ? (
              <div className="bg-white rounded-2xl border border-aviation-100 p-12 text-center text-xs text-slate-500 space-y-3">
                <div className="text-4xl">★</div>
                <h4 className="text-base font-bold text-aviation-900">No Bookmarked Questions Yet</h4>
                <p className="max-w-md mx-auto text-slate-500 leading-relaxed">
                  While answering questions in chapter practice drills, click the <strong>★ star icon</strong> to bookmark challenging concepts here for quick review before exam day.
                </p>
                <div className="pt-2">
                  <Link
                    href="/practice/pressure-and-altimetry"
                    className="inline-block px-4 py-2 rounded-xl text-xs font-bold bg-aviation-900 hover:bg-aviation-800 text-white"
                  >
                    Start Practice Drill
                  </Link>
                </div>
              </div>
            ) : (
              bookmarks.map((bm) => (
                <div key={bm.id} className="bg-white rounded-2xl border border-aviation-100 p-6 shadow-sm space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-skyAccent-700 bg-skyAccent-50 px-2.5 py-0.5 rounded">
                      {bm.subjectName} • {bm.chapterTitle}
                    </span>
                    <span className="text-xs text-amber-600 font-semibold">★ Bookmarked</span>
                  </div>
                  <p className="text-sm font-semibold text-aviation-900 leading-relaxed">{bm.questionText}</p>
                  <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-700 space-y-1">
                    <div>
                      <strong className="text-emerald-800">Correct Answer:</strong> {bm.correctAnswerText}
                    </div>
                    {bm.memoryAid && (
                      <p className="text-slate-500 italic">
                        <strong>Memory Aid:</strong> {bm.memoryAid}
                      </p>
                    )}
                    {bm.explanation && (
                      <p className="text-slate-600 pt-1 leading-relaxed">{bm.explanation}</p>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </main>

      {/* Pre-Flight Briefing Tour Modal */}
      {isBriefingOpen && (
        <div className="fixed inset-0 z-50 bg-aviation-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-xl bg-aviation-900 text-skyAccent-400 flex items-center justify-center text-sm font-bold">
                  ✈️
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-aviation-950">Pre-Flight Orientation</h3>
                  <p className="text-[11px] text-slate-500">DGCA Examination Pilot Briefing • Step {briefingStep} of 3</p>
                </div>
              </div>
              <button
                onClick={() => setIsBriefingOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center text-xs font-bold"
              >
                ✕
              </button>
            </div>

            {/* Step 1: Syllabus & Chapters */}
            {briefingStep === 1 && (
              <div className="space-y-4 text-xs text-slate-600">
                <div className="p-4 bg-aviation-50 rounded-2xl border border-aviation-100 flex items-start space-x-3">
                  <div className="text-2xl">📚</div>
                  <div>
                    <h4 className="font-bold text-aviation-950 text-sm mb-1">1. Master Subjects Chapter by Chapter</h4>
                    <p className="leading-relaxed">
                      DGCA exams cover 5 core disciplines: <strong>Air Regulations, Aviation Meteorology, Air Navigation, Technical General, and Technical Specific</strong>. Use the Subjects menu to drill questions topic-by-topic before attempting full mock exams.
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="font-bold text-aviation-950 block">Instant Feedback</span>
                    <span className="text-slate-500">Explanations and formulas appear as soon as you submit an option.</span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="font-bold text-aviation-950 block">Target Pass Mark</span>
                    <span className="text-emerald-700 font-bold">70% Required</span> in every DGCA paper.
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Practice Features */}
            {briefingStep === 2 && (
              <div className="space-y-4 text-xs text-slate-600">
                <div className="p-4 bg-skyAccent-50 rounded-2xl border border-skyAccent-200 flex items-start space-x-3">
                  <div className="text-2xl">💡</div>
                  <div>
                    <h4 className="font-bold text-aviation-950 text-sm mb-1">2. Memory Aids & Regulatory Citations</h4>
                    <p className="leading-relaxed">
                      Every practice question includes instructor mnemonics (like <em>"High to low, look out below"</em> for altimetry) and exact citations to Aircraft Rules 1937 and Civil Aviation Requirements (CAR).
                    </p>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-[11px] bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                    <span className="text-amber-500 font-bold text-base">★</span>
                    <span><strong>Bookmark questions:</strong> Flag difficult items to review later in your dashboard.</span>
                  </div>
                  <div className="flex items-center space-x-2 text-[11px] bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                    <span className="text-rose-500 font-bold text-base">🚩</span>
                    <span><strong>Report Issue:</strong> Spot a controversial answer key? Dispatch instructors review reports within 24 hours.</span>
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: CBT Mock Simulator */}
            {briefingStep === 3 && (
              <div className="space-y-4 text-xs text-slate-600">
                <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-start space-x-3">
                  <div className="text-2xl">⏱️</div>
                  <div>
                    <h4 className="font-bold text-aviation-950 text-sm mb-1">3. Realistic DGCA CBT Simulator</h4>
                    <p className="leading-relaxed">
                      Before test day at Pariksha DGCA centers, test yourself under authentic conditions with countdown timers, 4-status question palettes, and automatic submission.
                    </p>
                  </div>
                </div>
                <div className="p-3 bg-aviation-950 text-white rounded-xl text-[11px] flex items-center justify-between">
                  <div>
                    <span className="font-bold text-skyAccent-400 block">Premium Mock Papers</span>
                    <span className="text-slate-300">Unlock full papers across all subjects for ₹300/mo.</span>
                  </div>
                  <Link
                    href="/pricing"
                    onClick={() => setIsBriefingOpen(false)}
                    className="px-3 py-1.5 rounded-lg bg-skyAccent-400 text-aviation-950 font-bold text-xs hover:bg-skyAccent-300"
                  >
                    View Plans
                  </Link>
                </div>
              </div>
            )}

            {/* Modal Controls */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <button
                type="button"
                disabled={briefingStep === 1}
                onClick={() => setBriefingStep((prev) => Math.max(1, prev - 1))}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 disabled:opacity-30 transition-colors"
              >
                ← Previous
              </button>

              <div className="flex space-x-1.5">
                {[1, 2, 3].map((step) => (
                  <span
                    key={step}
                    className={`w-2.5 h-2.5 rounded-full transition-all ${
                      briefingStep === step ? "bg-aviation-900 w-6" : "bg-slate-200"
                    }`}
                  />
                ))}
              </div>

              {briefingStep < 3 ? (
                <button
                  type="button"
                  onClick={() => setBriefingStep((prev) => Math.min(3, prev + 1))}
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 transition-colors shadow-sm"
                >
                  Next Step →
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsBriefingOpen(false)}
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 transition-colors shadow-sm"
                >
                  Ready for Takeoff! ✈️
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
