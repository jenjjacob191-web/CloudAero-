"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { CHAPTER_PRACTICE_QUESTIONS, PracticeQuestion } from "@/data/practiceQuestions";
import { DETAILED_SUBJECTS } from "@/data/syllabusData";
import {
  recordRealQuestionPractice,
  recordRealChapterCompletion,
  toggleRealBookmark,
  getRealBookmarks,
} from "@/lib/user-progress";

interface PageProps {
  params: {
    chapterId: string;
  };
}

export default function ChapterPracticePage({ params }: PageProps) {
  const chapterSlug = params.chapterId;
  const questionsList: PracticeQuestion[] = CHAPTER_PRACTICE_QUESTIONS[chapterSlug] || [];

  const { user, profile } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
  const [bookmarkedQuestions, setBookmarkedQuestions] = useState<Record<string, boolean>>({});
  const [isNotesOpen, setIsNotesOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportType, setReportType] = useState("incorrect_answer");
  const [reportText, setReportText] = useState("");
  const [reportSubmitted, setReportSubmitted] = useState(false);
  const [isFinished, setIsFinished] = useState(false);

  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fetch("/api/support/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          source: "question_dispute",
          category: "exam_dispute",
          subject: `Dispute on Question ${currentQuestion?.id || "N/A"} (${chapterSlug})`,
          message: `[Issue Type: ${reportType}]\n${reportText}\n\nQuestion Reference: "${currentQuestion?.questionText}"`,
          questionCode: currentQuestion?.id,
          name: profile?.full_name || (user?.user_metadata?.full_name as string) || "Student Pilot",
          email: user?.email || "student@pilot.dgca",
          licenseType: (profile as { license_type?: string })?.license_type || "CPL",
        }),
      });
    } catch (err) {
      console.warn("Could not submit ticket:", err);
    }
    setReportSubmitted(true);
    setTimeout(() => {
      setIsReportModalOpen(false);
      setReportText("");
      setReportSubmitted(false);
    }, 2200);
  };

  // Initialize bookmarks on load
  useEffect(() => {
    const existing = getRealBookmarks();
    const map: Record<string, boolean> = {};
    existing.forEach((b) => {
      map[b.id] = true;
    });
    setBookmarkedQuestions(map);
  }, []);

  if (!questionsList || questionsList.length === 0) {
    return (
      <div className="min-h-screen bg-slate-50/70 py-20 px-4 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-3xl border border-aviation-100 shadow-xl p-8 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl mx-auto flex items-center justify-center text-3xl bg-skyAccent-50 text-skyAccent-600 border border-skyAccent-200">
            📚
          </div>
          <h2 className="text-xl font-bold text-aviation-900 tracking-tight">
            No Questions Available Yet
          </h2>
          <p className="text-xs text-slate-500 leading-relaxed">
            Practice questions for this chapter have not been published yet. Questions will appear once uploaded by administrators.
          </p>
          <div className="flex flex-col gap-2.5 pt-2">
            <Link
              href="/subjects"
              className="w-full py-3 px-5 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow transition-colors text-center"
            >
              Back to Syllabus Outline
            </Link>
            <Link
              href="/admin/questions"
              className="w-full py-2.5 px-5 rounded-xl text-xs font-semibold text-aviation-700 bg-aviation-50 hover:bg-aviation-100 transition-colors text-center"
            >
              Upload Questions (Admin Deck)
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const currentQuestion = questionsList[currentIndex] || questionsList[0];
  const selectedOptionId = selectedAnswers[currentIndex];
  const hasAnswered = selectedOptionId !== undefined;

  // Resolve subject and chapter meta
  const matchingSubject = DETAILED_SUBJECTS.find((s) =>
    s.chapters.some((c) => c.slug === chapterSlug)
  );
  const subjectSlug = matchingSubject?.slug || "air-regulations";
  const subjectName = matchingSubject?.name || currentQuestion?.subjectName || "Air Regulations";

  // Handle option selection
  const handleSelectOption = (optionId: string) => {
    if (hasAnswered) return; // prevent changing after first selection in drill mode
    setSelectedAnswers((prev) => ({
      ...prev,
      [currentIndex]: optionId,
    }));

    const isCorrect = currentQuestion.options.find((o) => o.id === optionId)?.isCorrect || false;
    recordRealQuestionPractice(currentQuestion.id, isCorrect, subjectSlug, chapterSlug);
  };

  // Toggle bookmark
  const toggleBookmark = (qId: string) => {
    const isNowBookmarked = !bookmarkedQuestions[qId];
    setBookmarkedQuestions((prev) => ({
      ...prev,
      [qId]: isNowBookmarked,
    }));

    const correctOpt = currentQuestion.options.find((o) => o.isCorrect);
    toggleRealBookmark({
      id: currentQuestion.id,
      subjectName: subjectName,
      chapterTitle: currentQuestion.chapterTitle || chapterSlug.replace(/-/g, " "),
      questionText: currentQuestion.questionText,
      correctAnswerText: correctOpt?.text || "",
      explanation: currentQuestion.explanation.concept,
      memoryAid: currentQuestion.explanation.memoryAid,
      bookmarkedAt: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
    });
  };

  // Navigation
  const goToNext = () => {
    if (currentIndex < questionsList.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      setIsFinished(true);
      recordRealChapterCompletion(chapterSlug);
    }
  };

  const goToPrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
  };

  const handleReset = () => {
    setSelectedAnswers({});
    setCurrentIndex(0);
    setIsFinished(false);
  };

  // Calculate scores
  let correctCount = 0;
  let attemptedCount = 0;
  questionsList.forEach((q, idx) => {
    const selId = selectedAnswers[idx];
    if (selId) {
      attemptedCount++;
      const correctOpt = q.options.find((o) => o.isCorrect);
      if (correctOpt && correctOpt.id === selId) {
        correctCount++;
      }
    }
  });

  const accuracyPercent = attemptedCount > 0 ? Math.round((correctCount / attemptedCount) * 100) : 0;
  const isPassing = accuracyPercent >= 70;

  // Render Finished Summary Scorecard
  if (isFinished) {
    return (
      <div className="min-h-screen bg-slate-50/70 py-16 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
        <div className="max-w-xl w-full bg-white rounded-3xl border border-aviation-100 shadow-2xl p-8 sm:p-10 text-center">
          <div
            className={`w-20 h-20 rounded-3xl mx-auto flex items-center justify-center text-3xl mb-4 shadow-md ${
              isPassing ? "bg-emerald-50 text-emerald-600 border border-emerald-200" : "bg-amber-50 text-amber-600 border border-amber-200"
            }`}
          >
            {isPassing ? "✈️" : "⚠️"}
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-aviation-900 tracking-tight">
            Chapter Drill Completed
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {currentQuestion.subjectName} • {currentQuestion.chapterTitle}
          </p>

          {/* Performance Box */}
          <div className="my-8 p-6 rounded-2xl bg-slate-50 border border-slate-100 grid grid-cols-3 gap-4 text-center">
            <div>
              <span className="text-slate-400 text-xs block font-medium">Questions</span>
              <span className="text-2xl font-bold text-aviation-900">{questionsList.length}</span>
            </div>
            <div>
              <span className="text-slate-400 text-xs block font-medium">Score</span>
              <span className="text-2xl font-bold text-emerald-600">{correctCount} / {questionsList.length}</span>
            </div>
            <div>
              <span className="text-slate-400 text-xs block font-medium">Accuracy</span>
              <span className={`text-2xl font-extrabold ${isPassing ? "text-emerald-600" : "text-amber-600"}`}>
                {accuracyPercent}%
              </span>
            </div>
          </div>

          <div className={`p-4 rounded-xl text-xs font-semibold mb-6 ${isPassing ? "bg-emerald-50 text-emerald-800" : "bg-amber-50 text-amber-800"}`}>
            {isPassing
              ? "✓ Congratulations! You scored above the DGCA 70% threshold for this chapter."
              : "⚠️ Your accuracy is below the 70% DGCA passing standard. Review the explanations and retry."}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={handleReset}
              className="flex-grow py-3 px-6 rounded-xl text-xs font-bold text-aviation-900 bg-aviation-50 hover:bg-aviation-100 border border-aviation-200 transition-colors"
            >
              🔄 Retry Chapter Drill
            </button>
            <Link
              href="/subjects"
              className="flex-grow py-3 px-6 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-md transition-colors text-center"
            >
              Back to Syllabus Outline
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50/70 pb-20">
      {/* Flight Deck Header */}
      <section className="bg-aviation-950 text-white py-6 px-4 sm:px-6 lg:px-8 border-b border-aviation-900 sticky top-20 z-30 shadow-md backdrop-blur-md">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2 text-xs text-skyAccent-300 font-semibold mb-1">
              <Link href="/subjects" className="hover:underline">
                {currentQuestion.subjectName}
              </Link>
              <span>•</span>
              <span className="text-slate-300">{currentQuestion.chapterTitle}</span>
            </div>
            <h1 className="text-lg sm:text-xl font-bold tracking-tight">
              Interactive Chapter Practice Drill
            </h1>
          </div>

          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={() => setIsNotesOpen((prev) => !prev)}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/20 border border-white/20 text-white transition-colors"
            >
              {isNotesOpen ? "Hide Notes" : "📖 Quick Notes"}
            </button>
            <div className="text-right hidden sm:block">
              <span className="text-xs text-slate-400 block font-medium">Accuracy</span>
              <span className="text-sm font-bold text-skyAccent-400">{accuracyPercent}%</span>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="max-w-4xl mx-auto mt-4">
          <div className="flex justify-between text-[11px] text-slate-400 font-medium mb-1.5">
            <span>Question {currentIndex + 1} of {questionsList.length}</span>
            <span>{Math.round(((currentIndex + 1) / questionsList.length) * 100)}% Completed</span>
          </div>
          <div className="w-full bg-aviation-900 rounded-full h-2 overflow-hidden border border-white/10">
            <div
              className="bg-gradient-to-r from-skyAccent-500 to-skyAccent-400 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentIndex + 1) / questionsList.length) * 100}%` }}
            />
          </div>
        </div>
      </section>

      {/* Main Question Card Container */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        {/* Revision Notes Slide Down */}
        {isNotesOpen && (
          <div className="bg-white rounded-2xl border border-aviation-200 p-6 shadow-sm mb-6 animate-fadeIn">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold text-aviation-900 flex items-center space-x-2">
                <span>📋 Chapter Key Concept Reference</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsNotesOpen(false)}
                className="text-xs text-slate-400 hover:text-slate-700 font-bold"
              >
                ✕ Close
              </button>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Standard ISA sea-level temperature is 15°C, pressure is 1013.25 hPa (29.92 inHg), and lapse rate is 1.98°C/1000ft (approx 2°C/1000ft) up to 11km. Remember: <em>&ldquo;High to low, look out below&rdquo;</em> (altimeter reads higher than true altitude).
            </p>
          </div>
        )}

        <div className="bg-white rounded-3xl border border-aviation-100 shadow-aviation p-6 sm:p-10">
          {/* Question Metadata Row */}
          <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
            <div className="flex items-center space-x-2.5">
              <span className="w-8 h-8 rounded-xl bg-aviation-900 text-skyAccent-400 flex items-center justify-center font-bold text-xs">
                #{currentIndex + 1}
              </span>
              <span
                className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                  currentQuestion.difficulty === "Easy"
                    ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                    : currentQuestion.difficulty === "Medium"
                    ? "bg-amber-50 text-amber-700 border border-amber-200"
                    : "bg-red-50 text-red-700 border border-red-200"
                }`}
              >
                {currentQuestion.difficulty}
              </span>
              <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">
                {currentQuestion.source}
              </span>
            </div>

            <div className="flex items-center space-x-2">
              {/* Bookmark Toggle */}
              <button
                type="button"
                onClick={() => toggleBookmark(currentQuestion.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-colors ${
                  bookmarkedQuestions[currentQuestion.id]
                    ? "bg-amber-100 text-amber-800 border border-amber-300"
                    : "bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200"
                }`}
                title="Bookmark tricky question for later revision"
              >
                <span>{bookmarkedQuestions[currentQuestion.id] ? "★" : "☆"}</span>
                <span>{bookmarkedQuestions[currentQuestion.id] ? "Bookmarked" : "Bookmark"}</span>
              </button>

              {/* Report Issue */}
              <button
                type="button"
                onClick={() => {
                  setIsReportModalOpen(true);
                  setReportSubmitted(false);
                }}
                className="p-1.5 rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                title="Report incorrect question or error"
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 21v-4m0 0V5a2 2 0 012-2h6.5l1 1H21l-3 6 3 6h-8.5l-1-1H5a2 2 0 00-2 2zm9-13.5V9" />
                </svg>
              </button>
            </div>
          </div>

          {/* Question Text */}
          <h2 className="text-base sm:text-xl font-bold text-aviation-900 leading-relaxed mb-8">
            {currentQuestion.questionText}
          </h2>

          {/* 4 Interactive Multiple-Choice Options */}
          <div className="space-y-3.5">
            {currentQuestion.options.map((opt) => {
              const isSelected = selectedOptionId === opt.id;
              const showResult = hasAnswered;
              const isTrueCorrect = opt.isCorrect;

              let cardStyle = "bg-white border-slate-200 hover:border-aviation-400 hover:bg-slate-50/50";
              let badgeStyle = "bg-slate-100 text-slate-600 border-slate-200";

              if (showResult) {
                if (isTrueCorrect) {
                  cardStyle = "bg-emerald-50/80 border-emerald-400 text-emerald-950 font-bold shadow-sm";
                  badgeStyle = "bg-emerald-600 text-white border-emerald-600";
                } else if (isSelected && !isTrueCorrect) {
                  cardStyle = "bg-red-50/80 border-red-400 text-red-950 font-semibold";
                  badgeStyle = "bg-red-600 text-white border-red-600";
                } else {
                  cardStyle = "bg-slate-50/40 border-slate-200 text-slate-400 opacity-60";
                }
              }

              return (
                <button
                  key={opt.id}
                  type="button"
                  disabled={hasAnswered}
                  onClick={() => handleSelectOption(opt.id)}
                  className={`w-full text-left p-4 sm:p-5 rounded-2xl border-2 transition-all flex items-center justify-between ${cardStyle}`}
                >
                  <div className="flex items-center space-x-4">
                    <span
                      className={`w-8 h-8 rounded-xl border flex items-center justify-center font-bold text-xs flex-shrink-0 transition-colors ${badgeStyle}`}
                    >
                      {opt.label}
                    </span>
                    <span className="text-xs sm:text-sm leading-relaxed">{opt.text}</span>
                  </div>

                  {showResult && isTrueCorrect && (
                    <span className="text-emerald-600 text-xs font-extrabold flex items-center space-x-1 ml-2">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="hidden sm:inline">Correct</span>
                    </span>
                  )}
                  {showResult && isSelected && !isTrueCorrect && (
                    <span className="text-red-600 text-xs font-bold flex items-center space-x-1 ml-2">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                      <span className="hidden sm:inline">Incorrect</span>
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Detailed In-Depth Answer Explanation Box */}
          {hasAnswered && (
            <div className="mt-8 p-6 rounded-2xl bg-aviation-50 border border-aviation-200 text-xs text-aviation-950 animate-fadeIn space-y-3">
              <div className="flex items-center space-x-2 text-aviation-900 font-bold text-sm">
                <svg className="w-5 h-5 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span>Detailed Explanation & Flight Rationale:</span>
              </div>

              <p className="leading-relaxed text-slate-700">
                {currentQuestion.explanation.concept}
              </p>

              {currentQuestion.explanation.formula && (
                <div className="p-3 bg-white rounded-xl border border-aviation-100 font-mono text-[11px] text-aviation-900 font-semibold">
                  📐 Formula Derivation: {currentQuestion.explanation.formula}
                </div>
              )}

              {currentQuestion.explanation.memoryAid && (
                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 font-medium">
                  💡 Memory Rule: <strong>{currentQuestion.explanation.memoryAid}</strong>
                </div>
              )}

              {currentQuestion.explanation.regulatoryRef && (
                <div className="text-[11px] text-slate-500 font-mono pt-1">
                  Reference: {currentQuestion.explanation.regulatoryRef}
                </div>
              )}
            </div>
          )}

          {/* Bottom Navigation Bar */}
          <div className="mt-8 pt-6 border-t border-slate-100 flex items-center justify-between">
            <button
              type="button"
              disabled={currentIndex === 0}
              onClick={goToPrev}
              className="py-2.5 px-5 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 transition-colors"
            >
              ← Previous
            </button>

            <span className="text-xs text-slate-400 font-medium hidden sm:inline">
              Question {currentIndex + 1} of {questionsList.length}
            </span>

            <button
              type="button"
              disabled={!hasAnswered}
              onClick={goToNext}
              className="py-2.5 px-6 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 disabled:opacity-40 transition-colors shadow-sm"
            >
              {currentIndex === questionsList.length - 1 ? "Complete Drill →" : "Next Question →"}
            </button>
          </div>
        </div>
      </main>

      {/* Report Question Modal */}
      {isReportModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-aviation-900">Report Question Issue</h3>
              <button
                type="button"
                onClick={() => setIsReportModalOpen(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            {reportSubmitted ? (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-center text-xs text-emerald-800 font-semibold">
                ✓ Thank you. Your feedback has been queued for our chief flight theory instructor review.
              </div>
            ) : (
              <form onSubmit={handleReportSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Issue Type</label>
                  <select
                    value={reportType}
                    onChange={(e) => setReportType(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-aviation-800"
                  >
                    <option value="incorrect_answer">Incorrect answer key</option>
                    <option value="ambiguous_wording">Ambiguous wording / Multiple interpretations</option>
                    <option value="typo">Typographical or numerical calculation error</option>
                    <option value="outdated_regulation">Outdated DGCA / ICAO regulation</option>
                    <option value="other">Other issue</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Description</label>
                  <textarea
                    rows={3}
                    required
                    value={reportText}
                    onChange={(e) => setReportText(e.target.value)}
                    placeholder="Provide details on why this question or explanation requires correction..."
                    className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-aviation-800"
                  />
                </div>

                <div className="flex justify-end space-x-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsReportModalOpen(false)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800"
                  >
                    Submit Report
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
