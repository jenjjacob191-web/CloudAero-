"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";

interface Receipt {
  id: string;
  planId: string;
  status: string;
  startsAt: string;
  expiresAt: string;
  amountINR: number;
  paymentId: string;
}

export default function CheckoutSuccessPage() {
  const [receipt, setReceipt] = useState<Receipt | null>(null);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const stored = sessionStorage.getItem("last-payment-receipt");
      if (stored) {
        try {
          setReceipt(JSON.parse(stored));
        } catch {
          // ignore
        }
      }
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-50/70 py-16 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
      <div className="max-w-lg w-full bg-white rounded-3xl border border-aviation-100 shadow-2xl p-8 sm:p-10 text-center">
        {/* Success Icon */}
        <div className="w-20 h-20 rounded-3xl bg-emerald-50 border border-emerald-200 text-emerald-600 mx-auto flex items-center justify-center text-3xl mb-4 shadow-sm">
          ✓
        </div>

        <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
          Payment Verified
        </span>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-aviation-900 tracking-tight mt-3">
          Subscription Active!
        </h1>

        <p className="text-xs text-slate-500 mt-1 mb-8">
          Your payment was processed and verified by the server. Full access to premium DGCA mock examinations and question banks is now unlocked.
        </p>

        {/* Receipt Box */}
        <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 text-left text-xs space-y-3 mb-8">
          <div className="flex justify-between border-b border-slate-200/60 pb-2">
            <span className="text-slate-500">Subscription Tier:</span>
            <span className="font-bold text-aviation-900 uppercase">
              {receipt?.planId === "six_month" ? "6-Month Complete Pilot Pass" : "Monthly Preparation Pass"}
            </span>
          </div>

          <div className="flex justify-between">
            <span className="text-slate-500">Amount Paid:</span>
            <span className="font-bold text-emerald-700">₹{receipt?.amountINR || 300} (INR)</span>
          </div>

          <div className="flex justify-between">
            <span className="text-slate-500">Payment ID:</span>
            <span className="font-mono text-slate-700">{receipt?.paymentId || "pay_rzp_live"}</span>
          </div>

          <div className="flex justify-between">
            <span className="text-slate-500">Start Date:</span>
            <span className="text-slate-800">
              {receipt?.startsAt ? new Date(receipt.startsAt).toLocaleDateString() : new Date().toLocaleDateString()}
            </span>
          </div>

          <div className="flex justify-between border-t border-slate-200/60 pt-2">
            <span className="text-slate-500 font-semibold">Valid Until:</span>
            <span className="font-bold text-aviation-900">
              {receipt?.expiresAt ? new Date(receipt.expiresAt).toLocaleDateString() : "Active Month"}
            </span>
          </div>
        </div>

        {/* Navigation Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <Link
            href="/mock-exams"
            className="flex-grow py-3.5 px-6 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-md transition-colors"
          >
            Launch Premium Mock Exams →
          </Link>
          <Link
            href="/dashboard"
            className="flex-grow py-3.5 px-6 rounded-xl text-xs font-bold text-aviation-800 bg-aviation-50 hover:bg-aviation-100 border border-aviation-200 transition-colors"
          >
            Go to Student Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}
