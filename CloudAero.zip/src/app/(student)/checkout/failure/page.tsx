"use client";

import React from "react";
import Link from "next/link";

export default function CheckoutFailurePage() {
  return (
    <div className="min-h-screen bg-slate-50/70 py-16 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
      <div className="max-w-md w-full bg-white rounded-3xl border border-aviation-100 shadow-2xl p-8 sm:p-10 text-center">
        <div className="w-20 h-20 rounded-3xl bg-red-50 border border-red-200 text-red-600 mx-auto flex items-center justify-center text-3xl mb-4 shadow-sm">
          ✕
        </div>

        <span className="text-xs font-bold uppercase tracking-wider text-red-700 bg-red-50 px-3 py-1 rounded-full border border-red-200">
          Payment Unsuccessful
        </span>

        <h1 className="text-2xl font-extrabold text-aviation-900 tracking-tight mt-3">
          Transaction Was Not Completed
        </h1>

        <p className="text-xs text-slate-500 mt-2 mb-8 leading-relaxed">
          The payment gateway could not verify the transaction. If funds were debited from your bank account or UPI app, Razorpay will automatically reverse the charges within 3-5 business days.
        </p>

        <div className="space-y-3">
          <Link
            href="/checkout?plan=monthly"
            className="w-full inline-block py-3.5 px-6 rounded-xl text-xs font-bold text-white bg-aviation-900 hover:bg-aviation-800 shadow-md transition-colors"
          >
            Retry Payment
          </Link>
          <Link
            href="/pricing"
            className="w-full inline-block py-3 px-6 rounded-xl text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
          >
            View Other Subscription Plans
          </Link>
        </div>
      </div>
    </div>
  );
}
