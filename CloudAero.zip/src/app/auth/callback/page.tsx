"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase/client";

function CallbackHandler() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    let isSubscribed = true;

    async function handleExchange() {
      try {
        const errorDesc = searchParams.get("error_description") || searchParams.get("error");
        if (errorDesc) {
          if (isSubscribed) setErrorMessage(decodeURIComponent(errorDesc));
          return;
        }

        const code = searchParams.get("code");
        if (code) {
          const { error } = await supabase.auth.exchangeCodeForSession(code);
          if (error) {
            console.error("OAuth exchange code error:", error);
            if (isSubscribed) setErrorMessage(error.message);
            return;
          }
        } else if (typeof window !== "undefined" && window.location.hash) {
          // Handle implicit OAuth flow (#access_token=...&refresh_token=...)
          const hashParams = new URLSearchParams(window.location.hash.substring(1));
          const accessToken = hashParams.get("access_token");
          const refreshToken = hashParams.get("refresh_token");
          if (accessToken && refreshToken) {
            const { error: setErr } = await supabase.auth.setSession({
              access_token: accessToken,
              refresh_token: refreshToken,
            });
            if (setErr) {
              console.warn("SetSession from hash error:", setErr);
            }
          }
        }

        // Check active session and determine role destination
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
          const userEmail = session.user.email?.toLowerCase().trim();

          // 1. Register this device as the SINGLE AUTHORITATIVE active session (kicks out any previously logged-in device)
          try {
            const regRes = await fetch("/api/auth/session/register", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                userId: session.user.id,
                email: userEmail,
                userAgent: typeof navigator !== "undefined" ? navigator.userAgent : "Google OAuth Client",
              }),
            });
            if (regRes.ok) {
              const regData = await regRes.json();
              if (regData?.sessionId) {
                localStorage.setItem("cloudaero_active_session_id", regData.sessionId);
                localStorage.setItem("aeroprep_active_session_id", regData.sessionId);
              }
            }
          } catch (regErr) {
            console.warn("Could not register device session on OAuth callback:", regErr);
          }

          const redirectParam = searchParams.get("redirect") || searchParams.get("returnUrl");
          let destination = redirectParam || "/";

          try {
            // Check profiles table for role
            const { data: profile } = await (supabase
              .from("profiles") as any)
              .select("role")
              .eq("id", session.user.id)
              .maybeSingle();

            if (profile?.role === "admin" || userEmail === "administrationprep@gmail.com" || userEmail?.includes("admin@")) {
              destination = "/admin";
            }
          } catch {
            // fallback
          }

          window.location.href = destination;
          return;
        }

        // Brief delay before fallback
        const timer = setTimeout(() => {
          window.location.href = "/";
        }, 1500);

        return () => clearTimeout(timer);
      } catch (err: any) {
        if (isSubscribed) setErrorMessage(err?.message || "Failed to process authentication.");
      }
    }

    handleExchange();

    return () => {
      isSubscribed = false;
    };
  }, [router, searchParams]);

  if (errorMessage) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-slate-50 text-slate-900">
        <div className="max-w-md w-full bg-white rounded-3xl p-8 border border-rose-200 shadow-xl text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center text-2xl mx-auto font-bold">
            ⚠️
          </div>
          <h2 className="text-xl font-black text-slate-900">
            Authentication Issue
          </h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            {errorMessage}
          </p>
          <div className="pt-2">
            <a
              href="/login"
              className="inline-flex items-center justify-center w-full py-3 px-4 rounded-xl text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 shadow-md shadow-sky-600/20 transition-all"
            >
              Return to Login Page
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-80px)] flex items-center justify-center bg-white text-slate-900">
      <div className="text-center space-y-4 p-8 max-w-sm">
        <div className="w-12 h-12 border-4 border-sky-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
        <h2 className="text-lg font-extrabold text-aviation-950">
          Connecting to Flight Deck...
        </h2>
        <p className="text-xs text-slate-500">
          Completing authentication. Establishing pilot credentials...
        </p>
      </div>
    </div>
  );
}

export default function AuthCallbackPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-white">
          <div className="animate-pulse text-sm font-bold text-sky-600">
            Connecting...
          </div>
        </div>
      }
    >
      <CallbackHandler />
    </Suspense>
  );
}
