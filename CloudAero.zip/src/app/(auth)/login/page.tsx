"use client";

import React, { useState, useEffect, Suspense } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter, useSearchParams } from "next/navigation";
import { useAuth, checkIsAdminEmail } from "@/lib/auth-context";
import { supabase } from "@/lib/supabase/client";

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { signIn, signInWithGoogle, loginAsDemoGoogleUser, setDeviceSessionId } = useAuth();

  // Mode: "otp" (Passwordless Code - Default) | "password" (Traditional)
  const [authMode, setAuthMode] = useState<"otp" | "password">("otp");
  const [step, setStep] = useState<"enter_email" | "enter_otp">("enter_email");

  // Form inputs
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otpCode, setOtpCode] = useState("");

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // OTP Timer State
  const [timerSeconds, setTimerSeconds] = useState(300);
  const [resendCooldown, setResendCooldown] = useState(0);

  // Check for concurrent session logout notice
  useEffect(() => {
    const errorParam = searchParams.get("error");
    if (errorParam === "concurrent_session") {
      setErrorMessage(
        "Single-Device Security Notice: Your account was signed in on another device. For your exam license protection, only 1 active device is permitted at a time. The previous session was securely closed."
      );
    }
  }, [searchParams]);

  // OTP countdown
  useEffect(() => {
    if (step !== "enter_otp") return;
    const timer = setInterval(() => {
      setTimerSeconds((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [step]);

  // Resend cooldown
  useEffect(() => {
    if (resendCooldown <= 0) return;
    const cd = setInterval(() => {
      setResendCooldown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(cd);
  }, [resendCooldown]);

  // 1. Passwordless OTP Request: Dispatches 6-digit code to candidate's email
  const handleRequestOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes("@")) {
      setErrorMessage("Please enter a valid email address.");
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch("/api/auth/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: cleanEmail }),
      });
      const data = await res.json();
      setIsSubmitting(false);

      if (!res.ok) {
        setErrorMessage(data.error || "Failed to dispatch verification code.");
        return;
      }

      setStep("enter_otp");
      setOtpCode("");
      setTimerSeconds(300);
      setResendCooldown(30);
      setSuccessMessage(`A 6-digit login verification code was sent to ${cleanEmail}.`);
    } catch {
      setIsSubmitting(false);
      setErrorMessage("Network error: Could not connect to verification service.");
    }
  };

  // 2. Verify 6-digit OTP and establish authenticated session
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanOtp = otpCode.trim();
    if (cleanOtp.length !== 6 || !/^\d+$/.test(cleanOtp)) {
      setErrorMessage("Please enter the complete 6-digit numeric verification code.");
      return;
    }

    setIsSubmitting(true);
    try {
      const cleanEmail = email.trim().toLowerCase();
      const res = await fetch("/api/auth/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: cleanEmail,
          code: cleanOtp,
          userAgent: typeof navigator !== "undefined" ? navigator.userAgent : "Web Browser",
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setIsSubmitting(false);
        setErrorMessage(data.error || "Invalid or expired verification code.");
        return;
      }

      // If Supabase tokenHash is returned, authenticate client session
      if (data.tokenHash) {
        try {
          await supabase.auth.verifyOtp({
            token_hash: data.tokenHash,
            type: "magiclink",
          });
        } catch (authErr) {
          console.warn("Client session hydration note:", authErr);
        }
      }

      if (data.sessionId) {
        setDeviceSessionId(data.sessionId);
      }

      // Also ensure local session fallback is set for resilient offline usage
      await signIn(cleanEmail, "CloudAero@2026");

      setIsSubmitting(false);

      // Determine redirect (to requested page, or default to the homepage webpage for students)
      const redirectParam = searchParams.get("redirect") || searchParams.get("returnUrl");
      const destination = checkIsAdminEmail(cleanEmail) ? "/admin" : redirectParam || "/";
      if (typeof window !== "undefined") {
        window.location.href = destination;
      } else {
        router.push(destination);
      }
    } catch {
      setIsSubmitting(false);
      setErrorMessage("Verification request failed. Please try again.");
    }
  };

  // 3. Password Login
  const handlePasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !password) {
      setErrorMessage("Please enter both email and password.");
      return;
    }

    setIsSubmitting(true);
    const { error, user } = await signIn(cleanEmail, password);
    setIsSubmitting(false);

    if (error) {
      setErrorMessage(
        `${error}. Tip: Switch to "Email Login Code" tab to sign in with an OTP without needing a password, or use default password: CloudAero@2026.`
      );
      return;
    }

    // Register active device session to kick out any other devices
    try {
      const regRes = await fetch("/api/auth/session/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user?.id,
          email: cleanEmail,
          userAgent: typeof navigator !== "undefined" ? navigator.userAgent : "Password Login Client",
        }),
      });
      if (regRes.ok) {
        const regData = await regRes.json();
        if (regData?.sessionId) {
          setDeviceSessionId(regData.sessionId);
        }
      }
    } catch {
      // non-blocking
    }

    // Success! Redirect (to requested page, or default to the homepage webpage for students)
    const redirectParam = searchParams.get("redirect") || searchParams.get("returnUrl");
    const destination = checkIsAdminEmail(cleanEmail) || checkIsAdminEmail(user?.email) ? "/admin" : redirectParam || "/";
    if (typeof window !== "undefined") {
      window.location.href = destination;
    } else {
      router.push(destination);
    }
  };

  const handleGoogleSignIn = async () => {
    setErrorMessage(null);
    setIsSubmitting(true);
    const { error } = await signInWithGoogle();
    if (error) {
      setErrorMessage(error);
      setIsSubmitting(false);
    }
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="min-h-[calc(100vh-80px)] py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-sky-50/60 via-white to-sky-50/60 flex items-center justify-center text-slate-900">
      <div className="max-w-md w-full bg-white rounded-3xl border border-sky-200 shadow-xl shadow-sky-500/10 p-8 sm:p-10">
        
        {/* Emblem & Title */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-sky-50 mx-auto flex items-center justify-center shadow-xs mb-3.5 overflow-hidden border border-sky-200 p-0.5">
            <Image
              src="/images/logo.jpg"
              alt="CloudAero DGCA Emblem"
              width={64}
              height={64}
              className="w-full h-full object-cover rounded-xl"
              priority
            />
          </div>

          <div className="flex items-center justify-center space-x-2">
            <h1 className="text-2xl font-black text-slate-900 tracking-tight font-sans">
              CloudAero
            </h1>
            <span className="text-xs font-mono font-black uppercase px-2 py-0.5 rounded-md bg-sky-500 text-white shadow-xs">
              DGCA
            </span>
          </div>
          <h2 className="text-sm font-bold text-slate-700 mt-1">
            Candidate Flight Deck Login
          </h2>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto leading-relaxed">
            Access your DGCA CBT mock exams, question bank drills, and personal scorecards.
          </p>
        </div>

        {/* Google OAuth Login */}
        {step !== "enter_otp" && (
          <div className="mb-5">
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isSubmitting}
              className="w-full flex items-center justify-center space-x-3 py-3 px-4 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-bold text-sm shadow-xs transition-all hover:border-slate-400 active:scale-[0.99] disabled:opacity-60 cursor-pointer"
            >
              <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{isSubmitting ? "Connecting to Google..." : "Continue with Google"}</span>
            </button>

            <div className="relative flex py-3 items-center">
              <div className="flex-grow border-t border-slate-200"></div>
              <span className="flex-shrink mx-3 text-[11px] font-semibold text-slate-400 uppercase tracking-wider font-mono">
                or candidate email
              </span>
              <div className="flex-grow border-t border-slate-200"></div>
            </div>
          </div>
        )}

        {/* Tab Selector: One-Time Code vs Password */}
        {step !== "enter_otp" && (
          <div className="flex rounded-xl bg-slate-100 p-1 mb-5">
            <button
              type="button"
              onClick={() => {
                setAuthMode("otp");
                setErrorMessage(null);
              }}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                authMode === "otp"
                  ? "bg-white text-slate-900 shadow-xs"
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              ✉️ Email Login Code
            </button>
            <button
              type="button"
              onClick={() => {
                setAuthMode("password");
                setErrorMessage(null);
              }}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                authMode === "password"
                  ? "bg-white text-slate-900 shadow-xs"
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              🔑 Password Login
            </button>
          </div>
        )}

        {/* Error / Alert Notice */}
        {errorMessage && (
          <div className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs space-y-2">
            <div className="flex items-start space-x-2">
              <span className="text-sm mt-0.5">⚠️</span>
              <span className="leading-relaxed font-medium">{errorMessage}</span>
            </div>
            {errorMessage.includes("Google") && loginAsDemoGoogleUser && (
              <div className="pt-2 border-t border-rose-200">
                <button
                  type="button"
                  onClick={() => {
                    loginAsDemoGoogleUser();
                    window.location.href = "/dashboard";
                  }}
                  className="w-full py-2 px-3 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-xs transition-all flex items-center justify-center space-x-1.5 cursor-pointer"
                >
                  <span>🚀 Continue as Google Pilot (Instant Demo)</span>
                </button>
              </div>
            )}
          </div>
        )}

        {successMessage && (
          <div className="mb-5 p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-start space-x-2 font-medium">
            <span className="text-sm mt-0.5">✅</span>
            <span className="leading-relaxed">{successMessage}</span>
          </div>
        )}

        {/* MODE A: OTP - Step 1: Request Code */}
        {authMode === "otp" && step === "enter_email" && (
          <form onSubmit={handleRequestOtp} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 font-mono">
                Candidate Email Address
              </label>
              <input
                type="email"
                required
                autoFocus
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="cadet@cloudaero.in"
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-300 focus:border-sky-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/20 text-sm text-slate-900 transition-all placeholder:text-slate-400"
              />
              <p className="text-[11px] text-slate-500 mt-1.5 leading-relaxed">
                A 6-digit numeric login verification code will be sent to your inbox.
              </p>
            </div>

            <div className="pt-1">
              <button
                type="submit"
                disabled={isSubmitting || !email.trim()}
                className="w-full py-3.5 px-4 rounded-xl text-sm font-bold text-white bg-sky-500 hover:bg-sky-600 shadow-md shadow-sky-500/20 transition-all active:scale-[0.98] disabled:opacity-50 flex items-center justify-center space-x-2 cursor-pointer"
              >
                <span>{isSubmitting ? "Sending Verification Code..." : "Send 6-Digit Login Code"}</span>
                {!isSubmitting && <span>→</span>}
              </button>
            </div>
          </form>
        )}

        {/* MODE A: OTP - Step 2: Enter 6-digit Code */}
        {authMode === "otp" && step === "enter_otp" && (
          <form onSubmit={handleVerifyOtp} className="space-y-5">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 text-center font-mono">
                Enter 6-Digit Verification Code
              </label>
              <input
                type="text"
                maxLength={6}
                autoFocus
                required
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ""))}
                placeholder="••••••"
                className="w-full px-4 py-3.5 rounded-2xl border-2 border-sky-500 text-center font-mono font-black text-2xl tracking-[0.5em] text-slate-900 focus:outline-none focus:ring-4 focus:ring-sky-500/20 shadow-inner"
              />
              <div className="flex items-center justify-between text-xs text-slate-500 mt-2 px-1">
                <span>Code expires in:</span>
                <span className={`font-mono font-bold ${timerSeconds < 60 ? "text-rose-600" : "text-sky-700"}`}>
                  {formatTimer(timerSeconds)}
                </span>
              </div>
            </div>

            <div className="pt-1 space-y-2.5">
              <button
                type="submit"
                disabled={isSubmitting || otpCode.length !== 6}
                className="w-full py-3.5 px-4 rounded-xl text-sm font-bold text-white bg-sky-500 hover:bg-sky-600 shadow-md shadow-sky-500/20 transition-all active:scale-[0.98] disabled:opacity-50 cursor-pointer"
              >
                {isSubmitting ? "Verifying Code & Session..." : "Confirm & Access Flight Deck"}
              </button>

              <div className="flex items-center justify-between pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setStep("enter_email");
                    setErrorMessage(null);
                    setSuccessMessage(null);
                  }}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
                >
                  ← Change Email
                </button>

                <button
                  type="button"
                  onClick={handleRequestOtp}
                  disabled={resendCooldown > 0}
                  className="text-xs font-bold text-sky-600 hover:text-sky-800 disabled:opacity-40 transition-colors cursor-pointer"
                >
                  {resendCooldown > 0 ? `Resend code (${resendCooldown}s)` : "Resend code"}
                </button>
              </div>
            </div>
          </form>
        )}

        {/* MODE B: Password Login */}
        {authMode === "password" && (
          <form onSubmit={handlePasswordLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 font-mono">
                Email Address
              </label>
              <input
                type="email"
                required
                autoFocus
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="cadet.pilot@example.com"
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-300 focus:border-sky-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/20 text-sm text-slate-900 transition-all placeholder:text-slate-400"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider font-mono">
                  Password
                </label>
                <Link
                  href="/forgot-password"
                  className="text-xs font-semibold text-sky-600 hover:text-sky-800"
                >
                  Forgot Password?
                </Link>
              </div>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password (e.g. CloudAero@2026)"
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-300 focus:border-sky-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/20 text-sm text-slate-900 transition-all placeholder:text-slate-400"
              />
              <p className="text-[11px] text-slate-500 mt-1.5">
                Default password: <code className="text-sky-700 font-mono font-bold">CloudAero@2026</code>
              </p>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 px-4 rounded-xl text-sm font-bold text-white bg-sky-500 hover:bg-sky-600 shadow-md shadow-sky-500/20 transition-all disabled:opacity-50 flex items-center justify-center space-x-2 cursor-pointer"
              >
                <span>{isSubmitting ? "Authenticating..." : "Sign In to Flight Deck"}</span>
                {!isSubmitting && <span>→</span>}
              </button>
            </div>
          </form>
        )}

        {/* Single Device Notice */}
        <div className="mt-6 bg-slate-50 p-3 rounded-xl border border-slate-200 text-[11px] text-slate-600 flex items-start space-x-2">
          <span className="text-sm">🛡️</span>
          <span className="leading-snug">
            <strong>Single-Device Security Active:</strong> Confirming login establishes this browser as your exclusive active device.
          </span>
        </div>

        {/* Switch to Register */}
        <div className="mt-6 pt-5 border-t border-slate-200 text-center text-xs text-slate-600">
          Do not have an account yet?{" "}
          <Link href="/register" className="text-sky-600 font-bold hover:underline">
            Register for free
          </Link>
        </div>

      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-[calc(100vh-80px)] py-12 px-4 flex items-center justify-center bg-slate-50">
          <div className="text-center font-bold text-sky-600 text-sm animate-pulse">
            Loading CloudAero Flight Deck...
          </div>
        </div>
      }
    >
      <LoginForm />
    </Suspense>
  );
}
