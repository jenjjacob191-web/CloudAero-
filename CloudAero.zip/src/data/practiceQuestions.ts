export interface PracticeQuestion {
  id: string;
  chapterSlug: string;
  chapterTitle: string;
  subjectName: string;
  questionNumber: number;
  questionText: string;
  diagramUrl?: string;
  options: {
    id: string;
    label: string; // A, B, C, D
    text: string;
    isCorrect: boolean;
  }[];
  explanation: {
    concept: string;
    formula?: string;
    regulatoryRef?: string;
    memoryAid?: string;
  };
  difficulty: "Easy" | "Medium" | "Hard";
  source: string;
  examYear?: number;
}

// All sample/fake questions cleared. Real DGCA questions will be inserted via Admin Console or Supabase.
export const CHAPTER_PRACTICE_QUESTIONS: Record<string, PracticeQuestion[]> = {};
