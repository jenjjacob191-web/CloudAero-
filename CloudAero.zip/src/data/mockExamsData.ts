export interface MockExamDefinition {
  id: string;
  slug: string;
  title: string;
  subjectName: string;
  subjectSlug: string;
  difficulty: "Beginner" | "Intermediate" | "DGCA Standard" | "Advanced";
  durationMinutes: number;
  totalQuestions: number;
  marksPerQuestion: number;
  negativeMarking: number;
  passingPercentage: number;
  isPremium: boolean;
  description: string;
  questions: {
    id: string;
    questionText: string;
    options: { id: string; label: string; text: string }[];
    correctOptionId: string;
    explanation: string;
  }[];
}

// All mock exams are premium and accessible only to subscribed students.
export const MOCK_EXAMS_CATALOG: MockExamDefinition[] = [
  {
    id: "mock-met-diagnostic",
    slug: "av-met-diagnostic-sample",
    title: "Aviation Meteorology — Full CBT Examination",
    subjectName: "Aviation Meteorology",
    subjectSlug: "aviation-meteorology",
    difficulty: "Intermediate",
    durationMinutes: 45,
    totalQuestions: 0,
    marksPerQuestion: 1,
    negativeMarking: 0,
    passingPercentage: 70,
    isPremium: true,
    description: "Standard timed CBT mock paper covering atmospheric pressure, altimetry subscales, ISA standards, and weather hazards.",
    questions: [],
  },
  {
    id: "mock-nav-cpl-full",
    slug: "air-nav-cpl-standard-paper-1",
    title: "Air Navigation — Full CPL Standard Mock Exam",
    subjectName: "Air Navigation",
    subjectSlug: "air-navigation",
    difficulty: "DGCA Standard",
    durationMinutes: 120,
    totalQuestions: 0,
    marksPerQuestion: 1,
    negativeMarking: 0,
    passingPercentage: 70,
    isPremium: true,
    description: "Comprehensive 70-question CPL standard timed CBT examination paper covering flight navigation computations, 1:60 rule, and radio aids.",
    questions: [],
  },
  {
    id: "mock-regs-sample",
    slug: "air-regs-sample-paper",
    title: "Air Regulations — Comprehensive Mock Paper",
    subjectName: "Air Regulations",
    subjectSlug: "air-regulations",
    difficulty: "Intermediate",
    durationMinutes: 45,
    totalQuestions: 0,
    marksPerQuestion: 1,
    negativeMarking: 0,
    passingPercentage: 70,
    isPremium: true,
    description: "Essential rules of the air, right-of-way priorities, transponder codes, and CAR Section 7 flight duty time limitations.",
    questions: [],
  },
  {
    id: "mock-techgen-full",
    slug: "tech-general-comprehensive",
    title: "Technical General — Comprehensive Mock Exam",
    subjectName: "Technical General",
    subjectSlug: "technical-general",
    difficulty: "DGCA Standard",
    durationMinutes: 120,
    totalQuestions: 0,
    marksPerQuestion: 1,
    negativeMarking: 0,
    passingPercentage: 70,
    isPremium: true,
    description: "Full-length DGCA simulation paper covering subsonic aerodynamics, lift/drag polar curves, aircraft systems, and flight instruments.",
    questions: [],
  },
];
