export interface NavItem {
  label: string;
  href: string;
  badge?: string;
}

export interface HeroSlide {
  id: string;
  title: string;
  subtitle: string;
  badgeText: string;
  imageSrc: string;
  primaryCtaText: string;
  primaryCtaLink: string;
  secondaryCtaText: string;
  secondaryCtaLink: string;
}

export interface DGCASubject {
  id: string;
  name: string;
  code: string;
  slug: string;
  description: string;
  iconName: string;
  chaptersCount: number;
  questionsCount: number;
  colorScheme: string;
}

export interface FeatureItem {
  title: string;
  description: string;
  iconName: string;
  highlightText?: string;
}

export interface MockExamCard {
  id: string;
  title: string;
  subjectName: string;
  durationMinutes: number;
  totalQuestions: number;
  passingMarks: number;
  isPremium: boolean;
  difficulty: "Beginner" | "Intermediate" | "DGCA Standard" | "Advanced";
}

export interface PricingPlan {
  id: "monthly" | "six_month";
  name: string;
  priceINR: number;
  durationMonths: number;
  durationLabel: string;
  popular?: boolean;
  features: string[];
}
