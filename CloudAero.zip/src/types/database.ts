export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string;
          role: "student" | "admin";
          is_premium?: boolean;
          subscription_tier?: string | null;
          avatar_url: string | null;
          phone_number: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name: string;
          role?: "student" | "admin";
          is_premium?: boolean;
          subscription_tier?: string | null;
          avatar_url?: string | null;
          phone_number?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string;
          role?: "student" | "admin";
          is_premium?: boolean;
          subscription_tier?: string | null;
          avatar_url?: string | null;
          phone_number?: string | null;
          updated_at?: string;
        };
      };
      subscription_plans: {
        Row: {
          id: string;
          code: "monthly" | "six_month";
          name: string;
          price_inr: number;
          duration_months: number;
          description: string;
          is_active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          code: "monthly" | "six_month";
          name: string;
          price_inr: number;
          duration_months: number;
          description: string;
          is_active?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          code?: "monthly" | "six_month";
          name?: string;
          price_inr?: number;
          duration_months?: number;
          description?: string;
          is_active?: boolean;
        };
      };
      user_subscriptions: {
        Row: {
          id: string;
          user_id: string;
          plan_id: string;
          status: "active" | "expired" | "cancelled" | "pending";
          starts_at: string;
          expires_at: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          plan_id: string;
          status?: "active" | "expired" | "cancelled" | "pending";
          starts_at?: string;
          expires_at: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          plan_id?: string;
          status?: "active" | "expired" | "cancelled" | "pending";
          starts_at?: string;
          expires_at?: string;
          updated_at?: string;
        };
      };
      payments: {
        Row: {
          id: string;
          user_id: string;
          subscription_id: string | null;
          gateway_provider: string;
          gateway_order_id: string;
          gateway_payment_id: string | null;
          gateway_signature: string | null;
          amount_inr: number;
          currency: string;
          status: "created" | "captured" | "failed" | "refunded";
          error_reason: string | null;
          created_at: string;
          verified_at: string | null;
        };
        Insert: {
          id?: string;
          user_id: string;
          subscription_id?: string | null;
          gateway_provider?: string;
          gateway_order_id: string;
          gateway_payment_id?: string | null;
          gateway_signature?: string | null;
          amount_inr: number;
          currency?: string;
          status?: "created" | "captured" | "failed" | "refunded";
          error_reason?: string | null;
          created_at?: string;
          verified_at?: string | null;
        };
        Update: {
          id?: string;
          user_id?: string;
          subscription_id?: string | null;
          gateway_order_id?: string;
          gateway_payment_id?: string | null;
          gateway_signature?: string | null;
          amount_inr?: number;
          status?: "created" | "captured" | "failed" | "refunded";
          error_reason?: string | null;
          verified_at?: string | null;
        };
      };
      subjects: {
        Row: {
          id: string;
          name: string;
          code: string;
          slug: string;
          description: string;
          icon_name: string;
          display_order: number;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          code: string;
          slug: string;
          description: string;
          icon_name?: string;
          display_order?: number;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          code?: string;
          slug?: string;
          description?: string;
          icon_name?: string;
          display_order?: number;
          is_active?: boolean;
          updated_at?: string;
        };
      };
      chapters: {
        Row: {
          id: string;
          subject_id: string;
          title: string;
          slug: string;
          chapter_number: number;
          revision_notes: string | null;
          display_order: number;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          subject_id: string;
          title: string;
          slug: string;
          chapter_number: number;
          revision_notes?: string | null;
          display_order?: number;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          subject_id?: string;
          title?: string;
          slug?: string;
          chapter_number?: number;
          revision_notes?: string | null;
          display_order?: number;
          is_active?: boolean;
          updated_at?: string;
        };
      };
      topics: {
        Row: {
          id: string;
          chapter_id: string;
          title: string;
          slug: string;
          display_order: number;
          is_active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          chapter_id: string;
          title: string;
          slug: string;
          display_order?: number;
          is_active?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          chapter_id?: string;
          title?: string;
          slug?: string;
          display_order?: number;
          is_active?: boolean;
        };
      };
      questions: {
        Row: {
          id: string;
          chapter_id: string;
          topic_id: string | null;
          question_text: string;
          explanation: string;
          difficulty: "easy" | "medium" | "hard";
          question_source: string;
          exam_year: number | null;
          image_url: string | null;
          is_demo: boolean;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          chapter_id: string;
          topic_id?: string | null;
          question_text: string;
          explanation: string;
          difficulty?: "easy" | "medium" | "hard";
          question_source?: string;
          exam_year?: number | null;
          image_url?: string | null;
          is_demo?: boolean;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          chapter_id?: string;
          topic_id?: string | null;
          question_text?: string;
          explanation?: string;
          difficulty?: "easy" | "medium" | "hard";
          question_source?: string;
          exam_year?: number | null;
          image_url?: string | null;
          is_demo?: boolean;
          is_active?: boolean;
          updated_at?: string;
        };
      };
      question_options: {
        Row: {
          id: string;
          question_id: string;
          option_text: string;
          is_correct: boolean;
          display_order: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          question_id: string;
          option_text: string;
          is_correct?: boolean;
          display_order?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          question_id?: string;
          option_text?: string;
          is_correct?: boolean;
          display_order?: number;
        };
      };
      mock_exams: {
        Row: {
          id: string;
          subject_id: string | null;
          title: string;
          slug: string;
          description: string;
          duration_minutes: number;
          total_questions: number;
          passing_percentage: number;
          marks_per_question: number;
          negative_marking: number;
          is_premium: boolean;
          is_published: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          subject_id?: string | null;
          title: string;
          slug: string;
          description: string;
          duration_minutes?: number;
          total_questions?: number;
          passing_percentage?: number;
          marks_per_question?: number;
          negative_marking?: number;
          is_premium?: boolean;
          is_published?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          subject_id?: string | null;
          title?: string;
          slug?: string;
          description?: string;
          duration_minutes?: number;
          total_questions?: number;
          passing_percentage?: number;
          marks_per_question?: number;
          negative_marking?: number;
          is_premium?: boolean;
          is_published?: boolean;
          updated_at?: string;
        };
      };
      exam_attempts: {
        Row: {
          id: string;
          user_id: string;
          mock_exam_id: string;
          score: number;
          percentage: number;
          total_questions: number;
          correct_count: number;
          incorrect_count: number;
          unattempted_count: number;
          marked_review_count: number;
          time_spent_seconds: number;
          status: "in_progress" | "completed" | "abandoned";
          started_at: string;
          completed_at: string | null;
        };
        Insert: {
          id?: string;
          user_id: string;
          mock_exam_id: string;
          score?: number;
          percentage?: number;
          total_questions: number;
          correct_count?: number;
          incorrect_count?: number;
          unattempted_count?: number;
          marked_review_count?: number;
          time_spent_seconds?: number;
          status?: "in_progress" | "completed" | "abandoned";
          started_at?: string;
          completed_at?: string | null;
        };
        Update: {
          id?: string;
          score?: number;
          percentage?: number;
          correct_count?: number;
          incorrect_count?: number;
          unattempted_count?: number;
          marked_review_count?: number;
          time_spent_seconds?: number;
          status?: "in_progress" | "completed" | "abandoned";
          completed_at?: string | null;
        };
      };
      bookmarks: {
        Row: {
          id: string;
          user_id: string;
          question_id: string;
          notes: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          question_id: string;
          notes?: string | null;
          created_at?: string;
        };
        Update: {
          notes?: string | null;
        };
      };
      chapter_progress: {
        Row: {
          id: string;
          user_id: string;
          chapter_id: string;
          questions_attempted: number;
          questions_correct: number;
          is_completed: boolean;
          last_practiced_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          chapter_id: string;
          questions_attempted?: number;
          questions_correct?: number;
          is_completed?: boolean;
          last_practiced_at?: string;
        };
        Update: {
          questions_attempted?: number;
          questions_correct?: number;
          is_completed?: boolean;
          last_practiced_at?: string;
        };
      };
      question_reports: {
        Row: {
          id: string;
          user_id: string;
          question_id: string;
          report_type: "incorrect_answer" | "ambiguous_wording" | "typo" | "outdated_regulation" | "other";
          description: string;
          status: "pending" | "resolved" | "dismissed";
          created_at: string;
          resolved_at: string | null;
        };
        Insert: {
          id?: string;
          user_id: string;
          question_id: string;
          report_type: "incorrect_answer" | "ambiguous_wording" | "typo" | "outdated_regulation" | "other";
          description: string;
          status?: "pending" | "resolved" | "dismissed";
          created_at?: string;
          resolved_at?: string | null;
        };
        Update: {
          status?: "pending" | "resolved" | "dismissed";
          resolved_at?: string | null;
        };
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      is_admin: {
        Args: Record<PropertyKey, never>;
        Returns: boolean;
      };
    };
    Enums: {
      [_ in never]: never;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
}
