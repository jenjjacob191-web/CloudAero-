"use client";

import React, { useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";

// Paths accessible to guests without logging in
const PUBLIC_PATHS = [
  "/login",
  "/register",
  "/forgot-password",
  "/auth/callback",
  "/contact",
  "/legal/privacy",
  "/legal/terms",
  "/legal/refund",
];

export default function AuthGuard({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, isLoading } = useAuth();

  // Allow static assets, Next internal files, and public routes
  const isPublicPath =
    PUBLIC_PATHS.some((path) => pathname === path || pathname.startsWith(path + "/")) ||
    pathname.startsWith("/api/") ||
    pathname.startsWith("/_next/");

  useEffect(() => {
    if (!isLoading && !user && !isPublicPath) {
      // Force unauthenticated visitors opening any website link or root to land on /login
      const returnUrl = pathname && pathname !== "/" ? `?redirect=${encodeURIComponent(pathname)}` : "";
      router.replace(`/login${returnUrl}`);
    }
  }, [user, isLoading, isPublicPath, pathname, router]);

  // While checking auth on protected routes (including root /), show splash before redirecting
  if (!isPublicPath && (isLoading || !user)) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-sky-50 via-white to-sky-50 flex flex-col items-center justify-center p-4">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-white border border-sky-200 flex items-center justify-center shadow-lg mx-auto p-1 animate-pulse">
            <span className="text-3xl">✈️</span>
          </div>
          <div className="space-y-1">
            <h2 className="text-sm font-bold text-aviation-950 tracking-tight font-sans">
              CloudAero Flight Deck
            </h2>
            <p className="text-xs text-sky-600 font-mono font-medium">
              Redirecting to Pilot Login...
            </p>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
