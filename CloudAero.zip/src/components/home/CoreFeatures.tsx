"use client";

import React from "react";
import Link from "next/link";

interface Feature {
  icon: string;
  title: string;
  description: string;
  points: string[];
}

const CORE_PILLARS: Feature[] = [
  {
    icon: "🖥️",
    title: "DGCA Pariksha CBT Simulator",
    description: "Practice in the authentic computer-based testing format used in official DGCA examination centers across India.",
    points: [
      "Exact question palette navigation (Answered, Flagged, Visited)",
      "Real exam timers (2.0 to 2.5 hours) with auto-submission",
      "Instant score evaluation against the official 70% pass criteria",
    ],
  },
  {
    icon: "📐",
    title: "Comprehensive Step-by-Step Explanations",
    description: "Every question includes complete derivation steps, formula breakdowns, and regulatory citations.",
    points: [
      "Altimetry subscale computations (QNH, QFE, Pressure Altitude)",
      "1:60 Rule navigation drift and wind triangle calculations",
      "Official ICAO Annex & Indian Aircraft Rules 1937 citations",
    ],
  },
  {
    icon: "📊",
    title: "Personal Performance Analytics",
    description: "Track your actual chapter progress and identify weak knowledge areas before taking the official exam.",
    points: [
      "Chapter-wise accuracy tracking across all 5 syllabus modules",
      "Full history of mock exam attempts and scorecards",
      "Personal revision vault to bookmark complex questions",
    ],
  },
  {
    icon: "🛡️",
    title: "Single-Device License Security",
    description: "Bank-grade concurrent session protection safeguards your student account and personal exam progress.",
    points: [
      "Automated detection of concurrent logins across multiple devices",
      "Two-factor verification to secure your candidate profile",
      "Encrypted session management and progress persistence",
    ],
  },
];

export default function CoreFeatures() {
  return (
    <section className="py-20 lg:py-28 bg-gradient-to-b from-white via-sky-50/25 to-white text-slate-900 border-b border-sky-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-white border border-sky-200 text-sky-700 text-xs font-bold uppercase tracking-wider shadow-xs">
            <span>PLATFORM CAPABILITIES</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-950 font-sans">
            Designed for Commercial Pilot Ground Theory
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Everything student pilots need to master the 5 mandatory DGCA papers, practice timed mock tests, and pass with confidence.
          </p>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {CORE_PILLARS.map((feat, idx) => (
            <div
              key={idx}
              className="rounded-3xl bg-white border border-sky-200 p-7 sm:p-9 shadow-sm hover:shadow-xl hover:shadow-sky-500/10 hover:border-sky-400 transition-all space-y-5"
            >
              <div className="w-12 h-12 rounded-2xl bg-sky-50 border border-sky-200 flex items-center justify-center text-2xl shadow-inner">
                {feat.icon}
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-950 tracking-tight">
                  {feat.title}
                </h3>
                <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                  {feat.description}
                </p>
              </div>

              <ul className="space-y-2.5 pt-2 border-t border-sky-100 text-xs text-slate-700">
                {feat.points.map((pt, pIdx) => (
                  <li key={pIdx} className="flex items-start space-x-2.5">
                    <span className="text-sky-500 font-bold mt-0.5">•</span>
                    <span>{pt}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom CTA Banner */}
        <div className="mt-14 p-8 rounded-3xl bg-gradient-to-r from-sky-50 via-white to-sky-50 border border-sky-200 shadow-lg shadow-sky-500/5 flex flex-wrap items-center justify-between gap-6">
          <div className="space-y-1">
            <h4 className="text-lg font-bold text-slate-900">
              Ready to begin your DGCA ground school preparation?
            </h4>
            <p className="text-xs text-slate-600">
              Access authentic timed mock exams and chapter practice drills across all 5 subjects.
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <Link
              href="/mock-exams"
              className="px-6 py-3 rounded-xl text-xs sm:text-sm font-bold text-white bg-sky-500 hover:bg-sky-600 shadow-md shadow-sky-500/20 transition-all"
            >
              View Mock Exams →
            </Link>
            <Link
              href="/pricing"
              className="px-6 py-3 rounded-xl text-xs sm:text-sm font-semibold text-sky-800 bg-white hover:bg-sky-50 border border-sky-200 transition-all"
            >
              View Pricing (₹300/mo)
            </Link>
          </div>
        </div>

      </div>
    </section>
  );
}
