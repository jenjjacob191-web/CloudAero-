"use client";

import React from "react";
import Link from "next/link";

export default function DashboardPreview() {
  return (
    <section className="py-20 lg:py-28 bg-gradient-to-b from-white via-sky-50/20 to-white border-b border-sky-100 text-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-white border border-sky-200 text-sky-700 text-xs font-bold uppercase tracking-wider shadow-xs">
            <span>STUDENT DASHBOARD</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight font-sans">
            Personal Flight Deck & Progress Analytics
          </h2>
          <p className="text-base text-slate-600 leading-relaxed">
            Every question you practice and every mock exam you attempt is tracked in real-time. Review your genuine scorecards, chapter progress, and bookmarked questions.
          </p>
        </div>

        {/* Dashboard Mock Window Container */}
        <div className="bg-white rounded-3xl border border-sky-200 shadow-xl shadow-sky-500/10 overflow-hidden max-w-5xl mx-auto">
          {/* Mock Window Top Bar */}
          <div className="bg-sky-50/60 px-6 py-4 flex items-center justify-between border-b border-sky-100 font-mono">
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-rose-400 inline-block" />
              <span className="w-3 h-3 rounded-full bg-amber-400 inline-block" />
              <span className="w-3 h-3 rounded-full bg-emerald-400 inline-block" />
              <span className="ml-4 text-xs text-slate-500 font-sans">
                cloudaero.in/dashboard
              </span>
            </div>
            <span className="text-xs font-bold text-sky-700 bg-white px-3 py-1 rounded-md border border-sky-200 shadow-xs">
              CANDIDATE FLIGHT DECK
            </span>
          </div>

          <div className="p-6 sm:p-10 space-y-8">
            {/* 4 Feature Preview Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              <div className="bg-gradient-to-b from-white to-sky-50/40 p-5 rounded-2xl border border-sky-100 shadow-xs">
                <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider block">Live Accuracy</span>
                <div className="flex items-baseline space-x-2 mt-2">
                  <span className="text-2xl sm:text-3xl font-black text-slate-900 font-mono">Real-Time %</span>
                </div>
                <span className="text-[11px] text-slate-500 mt-1 block">Evaluated against DGCA 70% threshold</span>
              </div>

              <div className="bg-gradient-to-b from-white to-sky-50/40 p-5 rounded-2xl border border-sky-100 shadow-xs">
                <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider block">Questions Solved</span>
                <div className="flex items-baseline space-x-2 mt-2">
                  <span className="text-2xl sm:text-3xl font-black text-sky-600 font-mono">Live Count</span>
                </div>
                <span className="text-[11px] text-slate-500 mt-1 block">Tracks across all 5 syllabus subjects</span>
              </div>

              <div className="bg-gradient-to-b from-white to-sky-50/40 p-5 rounded-2xl border border-sky-100 shadow-xs">
                <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider block">Timed CBT Mocks</span>
                <div className="flex items-baseline space-x-2 mt-2">
                  <span className="text-2xl sm:text-3xl font-black text-emerald-600 font-mono">Score History</span>
                </div>
                <span className="text-[11px] text-slate-500 mt-1 block">Full breakdown of passes and referrals</span>
              </div>

              <div className="bg-gradient-to-b from-white to-sky-50/40 p-5 rounded-2xl border border-sky-100 shadow-xs">
                <span className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider block">Revision Bookmarks</span>
                <div className="flex items-baseline space-x-2 mt-2">
                  <span className="text-2xl sm:text-3xl font-black text-amber-600 font-mono">Personal Vault</span>
                </div>
                <span className="text-[11px] text-slate-500 mt-1 block">Star tricky questions for quick recall</span>
              </div>
            </div>

            {/* How Progress Is Saved */}
            <div className="bg-gradient-to-br from-white to-sky-50/30 rounded-2xl border border-sky-200 p-6 space-y-4 shadow-xs">
              <h3 className="text-xs font-mono font-bold text-sky-700 uppercase tracking-wider">
                How Your Progress Is Recorded
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-slate-600">
                <div className="p-4 rounded-xl bg-white border border-sky-100 space-y-1.5 shadow-xs">
                  <span className="text-sm font-bold text-slate-900 block">1. Practice Chapters</span>
                  <p>Attempt chapter questions with immediate explanations. Your answers update your accuracy score in real-time.</p>
                </div>
                <div className="p-4 rounded-xl bg-white border border-sky-100 space-y-1.5 shadow-xs">
                  <span className="text-sm font-bold text-slate-900 block">2. Timed CBT Mocks</span>
                  <p>Attempt timed mock exams under official DGCA conditions. Scorecards evaluate passes against the 70% threshold.</p>
                </div>
                <div className="p-4 rounded-xl bg-white border border-sky-100 space-y-1.5 shadow-xs">
                  <span className="text-sm font-bold text-slate-900 block">3. Revision Bookmarks</span>
                  <p>Star any question to save it to your revision vault. Review formulas and rule citations anytime.</p>
                </div>
              </div>
            </div>

            <div className="text-center pt-2">
              <Link
                href="/dashboard"
                className="inline-flex items-center space-x-2 px-6 py-3 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs sm:text-sm shadow-md shadow-sky-500/20 transition-all"
              >
                <span>View Full Candidate Dashboard</span>
                <span>→</span>
              </Link>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
