"use client";

import React from "react";
import Link from "next/link";
import { PRICING_PLANS } from "@/data/mockData";

export default function PricingPreview() {
  return (
    <section id="pricing" className="py-20 lg:py-28 bg-gradient-to-b from-white via-sky-50/30 to-white border-b border-sky-100 text-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-white border border-sky-200 text-sky-700 text-xs font-bold uppercase tracking-wider shadow-xs">
            <span>TRANSPARENT CADET PRICING</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight font-sans">
            Simple, Affordable Plans for Student Pilots
          </h2>
          <p className="text-base text-slate-600 leading-relaxed">
            Unlock all DGCA subject mock exams, high-yield practice drills, and detailed explanations. Cancel or renew anytime.
          </p>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {PRICING_PLANS.map((plan) => (
            <div
              key={plan.id}
              className={`rounded-3xl p-8 sm:p-10 flex flex-col justify-between transition-all duration-300 relative bg-white ${
                plan.popular
                  ? "shadow-2xl shadow-sky-500/15 border-2 border-sky-400"
                  : "border border-sky-200 shadow-md hover:border-sky-300"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 right-8 bg-sky-500 text-white text-xs font-bold uppercase px-3.5 py-1 rounded-full shadow-md tracking-wider">
                  Recommended for CPL / ATPL
                </div>
              )}

              <div>
                <h3 className="text-2xl font-black text-slate-900">
                  {plan.name}
                </h3>
                <p className="text-xs text-slate-500 font-medium mt-1 font-sans">
                  {plan.durationLabel}
                </p>

                {/* Price Display */}
                <div className="mt-6 flex items-baseline space-x-2">
                  <span className="text-5xl font-black tracking-tight text-slate-950 font-mono">
                    ₹{plan.priceINR}
                  </span>
                  <span className="text-sm font-semibold text-slate-500">
                    / {plan.id === "monthly" ? "month" : "6 months"}
                  </span>
                </div>

                <div className="mt-2 text-xs font-semibold text-sky-700">
                  {plan.id === "monthly"
                    ? "Full 30-day unlimited access across all 5 subjects"
                    : "Full 6-month access (Save ₹300 compared to monthly)"}
                </div>

                {/* Feature List */}
                <ul className="mt-8 space-y-3.5 text-xs sm:text-sm">
                  {plan.features.map((feature, fIdx) => (
                    <li key={fIdx} className="flex items-start space-x-3">
                      <div className="mt-0.5 rounded-full p-0.5 text-sky-600">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="text-slate-700">
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Subscribe CTA Button */}
              <div className="mt-10">
                <Link
                  href={`/checkout?plan=${plan.id}`}
                  className={`w-full inline-flex items-center justify-center py-3.5 px-6 rounded-xl text-sm font-bold transition-all transform active:scale-95 shadow-md ${
                    plan.popular
                      ? "bg-sky-500 hover:bg-sky-600 text-white shadow-sky-500/25"
                      : "bg-white hover:bg-sky-50 text-sky-800 border-2 border-sky-300"
                  }`}
                >
                  Subscribe Now
                  <svg className="w-4 h-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </Link>
                <p className="text-center text-[11px] mt-2.5 text-slate-500 font-mono">
                  Secure checkout • UPI, Cards & NetBanking
                </p>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
