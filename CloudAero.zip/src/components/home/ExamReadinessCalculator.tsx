"use client";

import React, { useState } from "react";
import Link from "next/link";

export default function ExamReadinessCalculator() {
  const [studyHours, setStudyHours] = useState(3);
  const [currentScore, setCurrentScore] = useState(65);
  const [questionsDone, setQuestionsDone] = useState(600);

  // Compute calculated metrics
  const scoreFactor = Math.min(100, Math.max(40, currentScore));
  const practiceFactor = Math.min(25, (questionsDone / 1500) * 25);
  const hoursFactor = Math.min(20, (studyHours / 5) * 20);

  const rawProbability = Math.round((scoreFactor * 0.55) + practiceFactor + hoursFactor);
  const passProbability = Math.min(99, Math.max(45, rawProbability));

  // Estimated days to reach 85%+ readiness
  const pointsNeeded = Math.max(0, 85 - currentScore);
  const daysNeeded = Math.max(12, Math.round((pointsNeeded * 3.5) / Math.max(1, studyHours * 0.7)));

  // Recommended mock count
  const recommendedMocks = Math.max(6, Math.round(18 - (currentScore / 8)));

  let tierLabel = "Ground School In-Progress";
  let tierColor = "text-amber-800";
  let tierBg = "bg-amber-100 border-amber-300";

  if (passProbability >= 85) {
    tierLabel = "🟢 Flight Ready — High Confidence";
    tierColor = "text-emerald-900";
    tierBg = "bg-emerald-100 border-emerald-300";
  } else if (passProbability >= 70) {
    tierLabel = "🟡 Cleared for Solo — Moderate Polish Needed";
    tierColor = "text-sky-950";
    tierBg = "bg-sky-100 border-sky-300";
  }

  return (
    <section className="py-20 lg:py-28 bg-gradient-to-b from-white via-sky-50/30 to-white text-slate-900 border-b border-sky-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-white border border-sky-200 text-sky-700 text-xs font-bold uppercase tracking-wider shadow-xs">
            <span>INTERACTIVE CADET UTILITY</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-950 font-sans">
            Calculate Your DGCA Pass Probability
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Adjust your current preparation variables to see your predicted first-attempt pass probability and recommended flight training plan.
          </p>
        </div>

        {/* Calculator Main Box */}
        <div className="max-w-5xl mx-auto rounded-3xl bg-white border border-sky-200 p-6 sm:p-10 shadow-xl shadow-sky-500/5">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Sliders Area (Left 7 Cols) */}
            <div className="lg:col-span-7 space-y-7">
              {/* Slider 1: Study Hours */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs sm:text-sm">
                  <span className="font-bold text-slate-800">Daily Study Dedication:</span>
                  <span className="font-mono font-bold text-sky-700 bg-sky-50 px-2.5 py-1 rounded-md border border-sky-200">
                    {studyHours} {studyHours === 1 ? "Hour" : "Hours"} / day
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="8"
                  step="1"
                  value={studyHours}
                  onChange={(e) => setStudyHours(Number(e.target.value))}
                  className="w-full h-2 bg-sky-100 rounded-lg appearance-none cursor-pointer accent-sky-500"
                />
                <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                  <span>1 hr (Casual)</span>
                  <span>4 hrs (Cadet Standard)</span>
                  <span>8 hrs (Intensive Crash Course)</span>
                </div>
              </div>

              {/* Slider 2: Current Score */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs sm:text-sm">
                  <span className="font-bold text-slate-800">Current Mock Exam Score Average:</span>
                  <span className="font-mono font-bold text-sky-700 bg-sky-50 px-2.5 py-1 rounded-md border border-sky-200">
                    {currentScore}%
                  </span>
                </div>
                <input
                  type="range"
                  min="40"
                  max="95"
                  step="5"
                  value={currentScore}
                  onChange={(e) => setCurrentScore(Number(e.target.value))}
                  className="w-full h-2 bg-sky-100 rounded-lg appearance-none cursor-pointer accent-sky-500"
                />
                <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                  <span>40% (Beginning)</span>
                  <span>70% (DGCA Pass Mark)</span>
                  <span>95% (Airline Cadets)</span>
                </div>
              </div>

              {/* Slider 3: Questions Practiced */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs sm:text-sm">
                  <span className="font-bold text-slate-800">Practice Questions Completed:</span>
                  <span className="font-mono font-bold text-sky-700 bg-sky-50 px-2.5 py-1 rounded-md border border-sky-200">
                    {questionsDone} Questions
                  </span>
                </div>
                <input
                  type="range"
                  min="100"
                  max="2500"
                  step="100"
                  value={questionsDone}
                  onChange={(e) => setQuestionsDone(Number(e.target.value))}
                  className="w-full h-2 bg-sky-100 rounded-lg appearance-none cursor-pointer accent-sky-500"
                />
                <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                  <span>100 (Sample)</span>
                  <span>1,000 (Target)</span>
                  <span>2,500+ (Mastery)</span>
                </div>
              </div>

              <div className="pt-2 text-[11px] text-slate-500 leading-relaxed font-sans border-t border-sky-100">
                ⚡ Projected readiness score calibrated against the official DGCA 70% passing threshold and syllabus breadth.
              </div>
            </div>

            {/* Results Dial / Gauge Card (Right 5 Cols - Sky Blue Hero Visual) */}
            <div className="lg:col-span-5 bg-gradient-to-br from-sky-500 via-sky-600 to-blue-600 rounded-2xl border border-sky-400 p-6 sm:p-8 text-center space-y-6 text-white shadow-xl shadow-sky-500/25">
              <span className="text-[11px] font-mono uppercase tracking-wider text-sky-100 font-bold">
                PREDICTED PASS PROBABILITY
              </span>

              {/* Big Metric */}
              <div className="space-y-2">
                <div className="text-5xl sm:text-6xl font-black text-white font-mono drop-shadow-sm">
                  {passProbability}%
                </div>
                <div className={`inline-block px-3.5 py-1 rounded-full text-xs font-bold border ${tierBg} ${tierColor}`}>
                  {tierLabel}
                </div>
              </div>

              {/* Breakdown Grid */}
              <div className="grid grid-cols-2 gap-3 pt-2 text-left">
                <div className="bg-white/15 backdrop-blur-xs p-3 rounded-xl border border-white/20">
                  <p className="text-[10px] text-sky-100 font-mono uppercase">Est. Prep Time</p>
                  <p className="text-base font-bold text-white font-mono mt-0.5">{daysNeeded} Days</p>
                </div>
                <div className="bg-white/15 backdrop-blur-xs p-3 rounded-xl border border-white/20">
                  <p className="text-[10px] text-sky-100 font-mono uppercase">Target Mocks</p>
                  <p className="text-base font-bold text-white font-mono mt-0.5">{recommendedMocks} CBT Papers</p>
                </div>
              </div>

              {/* CTA */}
              <div className="pt-2">
                <Link
                  href="/pricing"
                  className="w-full inline-flex items-center justify-center px-6 py-3.5 rounded-xl text-xs sm:text-sm font-bold text-sky-900 bg-white hover:bg-sky-50 shadow-md transition-all"
                >
                  Unlock All Mock Papers (₹300/mo) →
                </Link>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
