"use client";

import React, { useState } from "react";
import Link from "next/link";

interface SubjectCBTMetric {
  id: string;
  moduleCode: string;
  name: string;
  shortName: string;
  questionCount: number;
  durationMinutes: number;
  passPercentage: number;
  icon: string;
  status: "Ready" | "Updated" | "High Yield";
  slug: string;
}

const DGCA_CBT_METRICS: SubjectCBTMetric[] = [
  {
    id: "nav",
    moduleCode: "MODULE 0103",
    name: "Air Navigation",
    shortName: "Navigation",
    questionCount: 100,
    durationMinutes: 150,
    passPercentage: 70,
    icon: "🧭",
    status: "High Yield",
    slug: "air-navigation",
  },
  {
    id: "met",
    moduleCode: "MODULE 0102",
    name: "Aviation Meteorology",
    shortName: "Meteorology",
    questionCount: 50,
    durationMinutes: 120,
    passPercentage: 70,
    icon: "🌦️",
    status: "Updated",
    slug: "aviation-meteorology",
  },
  {
    id: "regs",
    moduleCode: "MODULE 0101",
    name: "Air Regulations",
    shortName: "Regulations",
    questionCount: 50,
    durationMinutes: 120,
    passPercentage: 70,
    icon: "⚖️",
    status: "Ready",
    slug: "air-regulations",
  },
  {
    id: "tech-gen",
    moduleCode: "MODULE 0104",
    name: "Technical General",
    shortName: "Tech General",
    questionCount: 100,
    durationMinutes: 150,
    passPercentage: 70,
    icon: "⚙️",
    status: "High Yield",
    slug: "technical-general",
  },
  {
    id: "tech-sp",
    moduleCode: "MODULE 0105",
    name: "Technical Specific",
    shortName: "Tech Specific",
    questionCount: 50,
    durationMinutes: 90,
    passPercentage: 70,
    icon: "🔧",
    status: "Ready",
    slug: "technical-specific",
  },
];

export default function AcademyHero() {
  const [selectedSubject, setSelectedSubject] = useState<SubjectCBTMetric>(DGCA_CBT_METRICS[0]);

  return (
    <section className="relative w-full bg-gradient-to-b from-sky-100/60 via-sky-50/40 to-white text-slate-900 pt-16 pb-20 lg:pt-24 lg:pb-28 border-b border-sky-100">
      {/* Background Architectural Grid & Subtle Sky Clouds */}
      <div className="absolute inset-0 pointer-events-none opacity-40 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:28px_28px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Academy Proposition */}
          <div className="lg:col-span-7 space-y-7 text-center lg:text-left">
            {/* Pill Badge */}
            <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-white border border-sky-200 text-sky-700 text-xs font-bold uppercase tracking-wider shadow-sm">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-500 animate-pulse" />
              <span>DGCA CPL & ATPL PILOT EXAMINATION ACADEMY • 2026 CYCLE</span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-slate-950 leading-[1.12] font-sans">
              Clear Your DGCA Pilot Theory Exams on the{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-600 via-sky-500 to-blue-700">
                First Attempt.
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-slate-600 font-normal leading-relaxed max-w-2xl mx-auto lg:mx-0">
              India&apos;s dedicated computer-based testing platform for commercial pilot ground theory. Practice authentic timed Pariksha CBT mocks, chapter-wise question drills, and step-by-step formula explanations.
            </p>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-wrap gap-4 justify-center lg:justify-start">
              <Link
                href="/mock-exams"
                className="inline-flex items-center justify-center px-8 py-4 rounded-xl text-sm font-bold text-white bg-sky-500 hover:bg-sky-600 shadow-lg shadow-sky-500/25 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>Launch CBT Mock Exam</span>
                <svg className="w-4 h-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </Link>
              <Link
                href="/subjects"
                className="inline-flex items-center justify-center px-7 py-4 rounded-xl text-sm font-semibold text-sky-800 bg-white hover:bg-sky-50 border border-sky-200 shadow-sm transition-all"
              >
                Explore DGCA Subjects
              </Link>
            </div>

            {/* Quick Pilot Category Selectors */}
            <div className="pt-3 flex flex-wrap items-center justify-center lg:justify-start gap-2.5 text-xs text-slate-600">
              <span className="font-semibold text-sky-700 uppercase tracking-wider text-[11px] font-mono">
                Target Licence:
              </span>
              <span className="px-3.5 py-1.5 rounded-lg bg-white border border-sky-200 font-medium text-sky-900 shadow-xs">
                ✈️ Commercial Pilot (CPL)
              </span>
              <span className="px-3.5 py-1.5 rounded-lg bg-white border border-sky-200 font-medium text-sky-900 shadow-xs">
                🛫 Airline Transport (ATPL)
              </span>
              <span className="px-3.5 py-1.5 rounded-lg bg-white border border-sky-200 font-medium text-sky-900 shadow-xs">
                🛩️ Private Pilot (PPL)
              </span>
            </div>

            {/* Official Examination Standards Strip */}
            <div className="pt-6 border-t border-sky-100 grid grid-cols-2 sm:grid-cols-4 gap-6 text-left">
              <div className="p-3 rounded-xl bg-white/70 border border-sky-100 shadow-xs">
                <p className="text-2xl sm:text-3xl font-black text-slate-900 font-mono">70%</p>
                <p className="text-xs text-sky-700 font-medium mt-0.5">DGCA Pass Mark</p>
              </div>
              <div className="p-3 rounded-xl bg-white/70 border border-sky-100 shadow-xs">
                <p className="text-2xl sm:text-3xl font-black text-sky-600 font-mono">5 Papers</p>
                <p className="text-xs text-sky-700 font-medium mt-0.5">CPL / ATPL Syllabus</p>
              </div>
              <div className="p-3 rounded-xl bg-white/70 border border-sky-100 shadow-xs">
                <p className="text-2xl sm:text-3xl font-black text-sky-600 font-mono">2.0 - 2.5h</p>
                <p className="text-xs text-sky-700 font-medium mt-0.5">Timed CBT Sessions</p>
              </div>
              <div className="p-3 rounded-xl bg-white/70 border border-sky-100 shadow-xs">
                <p className="text-2xl sm:text-3xl font-black text-slate-700 font-mono">0.00</p>
                <p className="text-xs text-sky-700 font-medium mt-0.5">Nil Negative Marking</p>
              </div>
            </div>
          </div>

          {/* Right Column: Pariksha CBT Cockpit Simulator Console (No Sample Questions) */}
          <div className="lg:col-span-5">
            <div className="rounded-3xl bg-white border border-sky-200 shadow-xl shadow-sky-500/10 p-6 sm:p-7 relative transition-all">
              
              {/* CBT Simulator Console Header */}
              <div className="flex items-center justify-between pb-4 border-b border-sky-100 text-xs">
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="font-mono font-bold text-sky-700">PARIKSHA CBT ENGINE</span>
                  <span className="text-slate-400 font-medium">• LIVE V3.2</span>
                </div>
                <span className="text-[11px] font-mono text-sky-700 bg-sky-50 px-2.5 py-1 rounded-md border border-sky-200 font-semibold">
                  ACTIVE CYCLE 2026
                </span>
              </div>

              {/* Subject Selection Tabs */}
              <div className="py-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-wider font-mono">
                    Select DGCA Paper:
                  </span>
                  <span className="text-xs text-sky-600 font-semibold">
                    {selectedSubject.moduleCode}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {DGCA_CBT_METRICS.slice(0, 3).map((sub) => {
                    const isActive = selectedSubject.id === sub.id;
                    return (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={() => setSelectedSubject(sub)}
                        className={`p-2.5 rounded-xl border text-left transition-all ${
                          isActive
                            ? "bg-sky-50 border-sky-400 text-sky-900 shadow-xs"
                            : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:border-sky-200"
                        }`}
                      >
                        <div className="text-base mb-1">{sub.icon}</div>
                        <p className="text-xs font-bold leading-tight line-clamp-1">{sub.shortName}</p>
                        <p className="text-[10px] text-slate-500 font-mono mt-0.5">{sub.questionCount} Qs</p>
                      </button>
                    );
                  })}
                </div>

                <div className="grid grid-cols-2 gap-2 mt-2">
                  {DGCA_CBT_METRICS.slice(3, 5).map((sub) => {
                    const isActive = selectedSubject.id === sub.id;
                    return (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={() => setSelectedSubject(sub)}
                        className={`p-2.5 rounded-xl border text-left transition-all ${
                          isActive
                            ? "bg-sky-50 border-sky-400 text-sky-900 shadow-xs"
                            : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:border-sky-200"
                        }`}
                      >
                        <div className="flex items-center space-x-2">
                          <span className="text-base">{sub.icon}</span>
                          <div>
                            <p className="text-xs font-bold leading-tight">{sub.shortName}</p>
                            <p className="text-[10px] text-slate-500 font-mono mt-0.5">{sub.questionCount} Questions • {sub.durationMinutes}m</p>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Active Subject Details Panel */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-sky-50/70 to-white border border-sky-200 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2.5">
                    <span className="text-2xl">{selectedSubject.icon}</span>
                    <div>
                      <h2 className="text-sm font-bold text-slate-900 leading-snug">
                        {selectedSubject.name}
                      </h2>
                      <p className="text-[11px] font-mono text-sky-700 font-semibold">
                        {selectedSubject.moduleCode} • DGCA Standard
                      </p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-white border border-sky-300 text-sky-700">
                    {selectedSubject.status}
                  </span>
                </div>

                {/* Pariksha Metrics Grid */}
                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-sky-100 text-center font-mono">
                  <div className="p-2 rounded-xl bg-white border border-sky-100">
                    <p className="text-xs text-slate-400">Time Limit</p>
                    <p className="text-sm font-bold text-slate-800">{selectedSubject.durationMinutes} Mins</p>
                  </div>
                  <div className="p-2 rounded-xl bg-white border border-sky-100">
                    <p className="text-xs text-slate-400">Total Pool</p>
                    <p className="text-sm font-bold text-sky-600">{selectedSubject.questionCount} Qs</p>
                  </div>
                  <div className="p-2 rounded-xl bg-white border border-sky-100">
                    <p className="text-xs text-slate-400">Pass Req.</p>
                    <p className="text-sm font-bold text-emerald-600">{selectedSubject.passPercentage}%</p>
                  </div>
                </div>

                {/* Pariksha CBT Marking Guidelines Notice */}
                <div className="p-3 rounded-xl bg-white/90 border border-sky-200/80 text-[11px] text-slate-600 flex items-start space-x-2.5">
                  <span className="text-sky-500 font-bold mt-0.5">ℹ️</span>
                  <div className="space-y-0.5">
                    <p className="font-semibold text-slate-800">DGCA Examination Protocol</p>
                    <p className="text-slate-500 leading-relaxed">
                      Questions follow the official Pariksha computer-based examination format with instantaneous timer, review flags, and detailed calculation explanations.
                    </p>
                  </div>
                </div>
              </div>

              {/* Action Bar */}
              <div className="mt-5 pt-4 border-t border-sky-100 flex items-center justify-between gap-3">
                <Link
                  href="/mock-exams"
                  className="flex-1 py-3 px-4 rounded-xl text-xs sm:text-sm font-bold text-white bg-sky-500 hover:bg-sky-600 shadow-md shadow-sky-500/20 text-center transition-all"
                >
                  Start {selectedSubject.shortName} Mock →
                </Link>
                <Link
                  href={`/subjects/${selectedSubject.slug}`}
                  className="py-3 px-4 rounded-xl text-xs sm:text-sm font-semibold text-sky-800 bg-white hover:bg-sky-50 border border-sky-200 transition-all text-center"
                >
                  Syllabus
                </Link>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
