"use client";

import React, { useState } from "react";
import Link from "next/link";

interface SubjectModule {
  id: string;
  code: string;
  title: string;
  slug: string;
  tagline: string;
  duration: string;
  questionCount: string;
  passPercentage: number;
  icon: string;
  topics: string[];
  keyRegulation: string;
}

const DGCA_MODULES: SubjectModule[] = [
  {
    id: "air-regs",
    code: "MODULE 0101",
    title: "Air Regulations",
    slug: "air-regulations",
    tagline: "ICAO Conventions, Indian Aircraft Act 1934, Aircraft Rules 1937, Civil Aviation Requirements (CARs), Airspace Classification, and ATC Procedures.",
    duration: "2.0 Hours",
    questionCount: "50-100 Questions",
    passPercentage: 70,
    icon: "⚖️",
    topics: [
      "Indian Aircraft Rules 1937",
      "ICAO Annex 2 (Rules of the Air)",
      "Civil Aviation Requirements (CARs)",
      "Air Traffic Services & Airspace",
      "Search and Rescue (SAR)",
      "Aerodrome Lighting & Markings",
    ],
    keyRegulation: "Passing threshold: 70% • Negative marking: Nil",
  },
  {
    id: "av-met",
    code: "MODULE 0102",
    title: "Aviation Meteorology",
    slug: "aviation-meteorology",
    tagline: "Atmospheric Thermodynamics, Synoptic Pressure Charts, Indian Monsoon Dynamics, Jet Streams, CAT, Fronts, and Severe Flight Weather Hazards.",
    duration: "2.0 Hours",
    questionCount: "50 Questions",
    passPercentage: 70,
    icon: "🌦️",
    topics: [
      "Pressure Altimetry & QNH/QFE Subscales",
      "Indian Monsoon Dynamics & ITCZ",
      "Tropical Cyclones & Depressions",
      "Thunderstorm & Microburst Avoidance",
      "Jet Streams & Clear Air Turbulence (CAT)",
      "METAR, SPECI & TAF Decoding",
    ],
    keyRegulation: "Passing threshold: 70% • Negative marking: Nil",
  },
  {
    id: "air-nav",
    code: "MODULE 0103",
    title: "Air Navigation",
    slug: "air-navigation",
    tagline: "General Navigation, Flight Planning, Dead Reckoning, 1:60 Rule Computations, Altimetry Calculations, and Terrestrial & Satellite Radio Aids.",
    duration: "2.5 Hours",
    questionCount: "70-100 Questions",
    passPercentage: 70,
    icon: "🧭",
    topics: [
      "1:60 Rule Track Error Calculations",
      "True Airspeed & Wind Triangle Vectors",
      "VOR, DME, ILS & NDB Radio Aids",
      "GNSS / GPS & Performance-Based Nav (PBN)",
      "Mercator & Lambert Conformal Projections",
      "Point of No Return (PNR) & Critical Point (CP)",
    ],
    keyRegulation: "Passing threshold: 70% • High-computation paper",
  },
  {
    id: "tech-gen",
    code: "MODULE 0104",
    title: "Technical General",
    slug: "technical-general",
    tagline: "Subsonic & Transonic Aerodynamics, Gas Turbine Engines, Piston Engines, Hydraulics, Electrics, Pneumatics, and Primary Flight Controls.",
    duration: "2.5 Hours",
    questionCount: "70-100 Questions",
    passPercentage: 70,
    icon: "⚙️",
    topics: [
      "Subsonic & Transonic Aerodynamics",
      "Turbofan & Jet Thermodynamic Cycles",
      "Aircraft Electrical & 28V DC / 115V AC Systems",
      "Hydraulic Actuation & Landing Gear",
      "Cabin Pressurization & Emergency Oxygen",
      "Flight Control Surfaces, Trims & Flaps",
    ],
    keyRegulation: "Passing threshold: 70% • Negative marking: Nil",
  },
  {
    id: "tech-spec",
    code: "MODULE 0105",
    title: "Technical Specific",
    slug: "technical-specific",
    tagline: "Single-Engine & Multi-Engine Aircraft Systems, Performance Tables, Weight & Balance Computations, Limitations, and Emergency Drills.",
    duration: "2.0 Hours",
    questionCount: "50 Questions",
    passPercentage: 70,
    icon: "✈️",
    topics: [
      "Cessna 172R / Skyhawk Operating Limits",
      "Piper Seneca PA-34 Twin-Engine Systems",
      "Diamond DA42 Austro Engine FADEC",
      "Takeoff & Landing Performance Tables",
      "Emergency Procedures & Engine-Out Driftdown",
      "Weight, Balance & CG Envelope Computations",
    ],
    keyRegulation: "Passing threshold: 70% • Type-specific paper",
  },
];

export default function SubjectModulesShowcase() {
  const [selectedModuleId, setSelectedModuleId] = useState(DGCA_MODULES[0].id);

  const activeModule = DGCA_MODULES.find((m) => m.id === selectedModuleId) || DGCA_MODULES[0];

  return (
    <section id="subjects" className="py-20 lg:py-28 bg-gradient-to-b from-white via-sky-50/30 to-white text-slate-900 border-b border-sky-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-white border border-sky-200 text-sky-700 text-xs font-bold uppercase tracking-wider shadow-xs">
            <span>DGCA SUBJECTS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-950 font-sans">
            DGCA Subjects
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Every candidate must clear these mandatory DGCA theoretical examinations to obtain a Commercial Pilot Licence (CPL) or Airline Transport Pilot Licence (ATPL).
          </p>
        </div>

        {/* Modular Selector Tabs */}
        <div className="flex flex-wrap gap-2.5 justify-center mb-10">
          {DGCA_MODULES.map((mod) => {
            const isSelected = mod.id === selectedModuleId;
            return (
              <button
                key={mod.id}
                type="button"
                onClick={() => setSelectedModuleId(mod.id)}
                className={`flex items-center space-x-2.5 px-4 sm:px-5 py-3 rounded-2xl border text-xs sm:text-sm font-bold transition-all ${
                  isSelected
                    ? "bg-sky-500 text-white border-sky-500 shadow-md shadow-sky-500/25 scale-105"
                    : "bg-white text-slate-700 border-sky-100 hover:bg-sky-50 hover:border-sky-300"
                }`}
              >
                <span>{mod.icon}</span>
                <span>{mod.title}</span>
              </button>
            );
          })}
        </div>

        {/* Active Module Detailed Showcase Card */}
        <div className="rounded-3xl bg-white border border-sky-200 p-6 sm:p-10 shadow-xl shadow-sky-500/5">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left Column: Details */}
            <div className="lg:col-span-7 space-y-6">
              <div className="flex flex-wrap items-center gap-3">
                <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-skyAccent-100 text-skyAccent-800 border border-skyAccent-300">
                  {activeModule.code}
                </span>
                <span className="text-xs text-slate-500 font-mono">
                  {activeModule.keyRegulation}
                </span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-black text-slate-950 flex items-center space-x-3">
                <span>{activeModule.icon}</span>
                <span>{activeModule.title}</span>
              </h3>

              <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                {activeModule.tagline}
              </p>

              {/* Topics Grid */}
              <div className="space-y-3 pt-2">
                <h4 className="text-xs font-bold text-skyAccent-700 uppercase tracking-wider font-mono">
                  Key Examination Focus Areas:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {activeModule.topics.map((topic, idx) => (
                    <div key={idx} className="flex items-center space-x-2.5 text-xs text-slate-700 bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-skyAccent-500 flex-shrink-0" />
                      <span>{topic}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 flex flex-wrap gap-4">
                <Link
                  href={`/subjects/${activeModule.slug}`}
                  className="px-6 py-3 rounded-xl text-xs sm:text-sm font-bold text-white bg-sky-500 hover:bg-sky-600 shadow-md shadow-sky-500/25 transition-all"
                >
                  View Full Syllabus & Topics →
                </Link>
                <Link
                  href="/mock-exams"
                  className="px-6 py-3 rounded-xl text-xs sm:text-sm font-semibold text-sky-800 bg-white hover:bg-sky-50 border border-sky-200 transition-all shadow-xs"
                >
                  Attempt Mock Paper
                </Link>
              </div>
            </div>

            {/* Right Column: Exam Blueprint Specs */}
            <div className="lg:col-span-5 bg-gradient-to-br from-white to-sky-50/50 rounded-2xl border border-sky-200 p-6 sm:p-7 space-y-6 shadow-sm">
              <h4 className="text-xs font-bold text-sky-800 uppercase tracking-wider font-mono border-b border-sky-100 pb-3">
                DGCA Computer-Based Exam Specs
              </h4>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-xl border border-sky-100 shadow-xs">
                  <p className="text-[11px] text-slate-500 font-mono uppercase">EXAM DURATION</p>
                  <p className="text-xl font-black text-slate-900 font-mono mt-1">{activeModule.duration}</p>
                </div>
                <div className="bg-white p-4 rounded-xl border border-sky-100 shadow-xs">
                  <p className="text-[11px] text-slate-500 font-mono uppercase">QUESTION COUNT</p>
                  <p className="text-xl font-black text-sky-600 font-mono mt-1">{activeModule.questionCount}</p>
                </div>
                <div className="bg-white p-4 rounded-xl border border-sky-100 shadow-xs">
                  <p className="text-[11px] text-slate-500 font-mono uppercase">PASS CRITERIA</p>
                  <p className="text-xl font-black text-emerald-600 font-mono mt-1">70% Minimum</p>
                </div>
                <div className="bg-white p-4 rounded-xl border border-sky-100 shadow-xs">
                  <p className="text-[11px] text-slate-500 font-mono uppercase">NEGATIVE MARK</p>
                  <p className="text-xl font-black text-slate-700 font-mono mt-1">Zero (0)</p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-white border border-sky-200 text-xs text-sky-900 leading-relaxed font-sans shadow-xs">
                💡 <span className="font-bold text-sky-700">Pariksha Layout:</span> CloudAero mock tests mirror the exact DGCA Pariksha screen format, complete with question palette flags, review bookmarks, and countdown chronometer.
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
