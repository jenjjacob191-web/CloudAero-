"use client";

import React from "react";
import Link from "next/link";

interface FeatureRow {
  feature: string;
  subtext: string;
  traditionalCoaching: string;
  staticPDFs: string;
  cloudAero: string;
}

const COMPARISON_DATA: FeatureRow[] = [
  {
    feature: "DGCA Pariksha CBT Simulator",
    subtext: "Exact timer, palette review buttons, and exam layout",
    traditionalCoaching: "❌ Paper printouts only",
    staticPDFs: "❌ Static text reader",
    cloudAero: "✅ Pixel-perfect CBT parity",
  },
  {
    feature: "In-Depth Question Explanations",
    subtext: "Formulas, ICAO rule citations, and visual memory aids",
    traditionalCoaching: "⚠️ Only if faculty has time",
    staticPDFs: "❌ Answer key only (A/B/C/D)",
    cloudAero: "✅ Instant explanations for every Q",
  },
  {
    feature: "Syllabus Freshness & CAR Amendments",
    subtext: "Real-time updates as DGCA releases new circulars",
    traditionalCoaching: "❌ Outdated photocopied notes",
    staticPDFs: "❌ Unverified old files",
    cloudAero: "✅ Updated for 2026 examination cycle",
  },
  {
    feature: "Weak-Area Diagnostic Analytics",
    subtext: "Identifies weak chapters (e.g. Altimetry or 1:60 Rule)",
    traditionalCoaching: "❌ No individual tracking",
    staticPDFs: "❌ Zero analytics",
    cloudAero: "✅ Diagnostic scorecards & progress radar",
  },
  {
    feature: "Device Mobility",
    subtext: "Practice anywhere on iPad, iPhone, Android, or Laptop",
    traditionalCoaching: "❌ Classroom physical attendance",
    staticPDFs: "⚠️ Clunky scrolling",
    cloudAero: "✅ Responsive pilot flight bag app",
  },
  {
    feature: "Pricing & Affordability",
    subtext: "Cost for complete ground theory preparation",
    traditionalCoaching: "₹40,000 – ₹80,000+",
    staticPDFs: "Unreliable",
    cloudAero: "Free Open Access",
  },
];

export default function ParikshaComparison() {
  return (
    <section className="py-20 lg:py-28 bg-white text-slate-900 border-b border-sky-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-sky-50 border border-sky-200 text-sky-700 text-xs font-bold uppercase tracking-wider shadow-xs">
            <span>THE MODERN FLIGHT TRAINING STANDARD</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-950 font-sans">
            Built for Cadets Who Demand Excellence
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            See how CloudAero provides an authentic computer-based testing environment compared to traditional coaching notes and static PDF files.
          </p>
        </div>

        {/* Comparison Table */}
        <div className="rounded-3xl bg-white border border-sky-200 overflow-hidden shadow-xl shadow-sky-500/5">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-sky-100 bg-sky-50/50 text-xs font-mono uppercase tracking-wider text-slate-500">
                  <th className="p-5 sm:p-6 font-bold text-slate-900 min-w-[240px]">Feature & Capability</th>
                  <th className="p-5 sm:p-6 text-slate-600 min-w-[180px]">Traditional Coaching</th>
                  <th className="p-5 sm:p-6 text-slate-600 min-w-[180px]">Static PDF Notes</th>
                  <th className="p-5 sm:p-6 font-bold text-sky-800 bg-sky-100/70 border-l border-sky-200 min-w-[200px]">
                    ✈️ CloudAero DGCA
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-sky-100/60 text-xs sm:text-sm">
                {COMPARISON_DATA.map((row, idx) => (
                  <tr key={idx} className="hover:bg-sky-50/30 transition-colors">
                    <td className="p-5 sm:p-6">
                      <p className="font-bold text-slate-900 text-sm">{row.feature}</p>
                      <p className="text-xs text-slate-500 mt-0.5">{row.subtext}</p>
                    </td>
                    <td className="p-5 sm:p-6 text-slate-600 font-sans">
                      {row.traditionalCoaching}
                    </td>
                    <td className="p-5 sm:p-6 text-slate-500 font-sans">
                      {row.staticPDFs}
                    </td>
                    <td className="p-5 sm:p-6 font-bold text-sky-700 bg-sky-50/60 border-l border-sky-200 font-sans">
                      {row.cloudAero}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Table Bottom Footer Bar */}
          <div className="p-6 bg-gradient-to-r from-sky-50/60 via-white to-sky-50/60 border-t border-sky-100 flex flex-wrap items-center justify-between gap-4">
            <div className="text-xs text-slate-600 font-medium">
              ⚡ Designed specifically for the DGCA Computer-Based Examination format across all 5 CPL & ATPL subjects.
            </div>
            <Link
              href="/pricing"
              className="px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-sky-500 hover:bg-sky-600 transition-colors shadow-md shadow-sky-500/20"
            >
              Get Started for ₹300/mo →
            </Link>
          </div>
        </div>

      </div>
    </section>
  );
}
