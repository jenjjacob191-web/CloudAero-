import React from "react";
import Link from "next/link";
import { SAMPLE_MOCKS_DEMO } from "@/data/mockData";

export default function MockExamPreview() {
  return (
    <section className="py-20 bg-aviation-950 border-b border-aviation-900 text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-aviation-900 border border-skyAccent-500/30 text-skyAccent-300 text-xs font-mono font-bold uppercase tracking-wider mb-3">
              <span>Exam Simulation</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              DGCA Mock Examinations
            </h2>
            <p className="mt-2 text-base text-slate-400">
              Replicate authentic DGCA examination room conditions. All CBT mock exam papers are unlocked exclusively with an active preparation pass.
            </p>
          </div>
          <div className="mt-4 md:mt-0">
            <Link
              href="/mock-exams"
              className="inline-flex items-center text-sm font-bold text-skyAccent-400 hover:text-skyAccent-200"
            >
              <span>Explore All Mock Papers</span>
              <svg className="w-4 h-4 ml-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
        </div>

        {/* Mock Exam Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SAMPLE_MOCKS_DEMO.map((mock) => (
            <div
              key={mock.id}
              className={`rounded-3xl p-6 border flex flex-col justify-between transition-all duration-300 ${
                mock.isPremium
                  ? "bg-aviation-900/60 backdrop-blur-md border-aviation-800 shadow-xl hover:border-amber-400/80 hover:shadow-amber-500/10"
                  : "bg-aviation-900/60 backdrop-blur-md border-skyAccent-500/30 shadow-xl hover:border-skyAccent-400"
              }`}
            >
              <div>
                {/* Status Badges */}
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[11px] font-mono font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-lg bg-aviation-950 text-slate-300 border border-aviation-700">
                    {mock.subjectName}
                  </span>

                  <span className="inline-flex items-center space-x-1 text-xs font-mono font-bold text-amber-300 bg-amber-950/60 border border-amber-500/40 px-2.5 py-0.5 rounded-full">
                    <svg className="w-3.5 h-3.5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                    Premium Pass
                  </span>
                </div>

                <h3 className="text-base font-bold text-white mb-3 leading-snug">
                  {mock.title}
                </h3>

                {/* Exam Parameters */}
                <div className="space-y-2 text-xs text-slate-300 bg-black/40 p-3.5 rounded-2xl border border-aviation-800 font-mono mb-6">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Duration:</span>
                    <span className="font-semibold text-white">{mock.durationMinutes} Minutes</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Exam Format:</span>
                    <span className="font-semibold text-skyAccent-300">DGCA Pariksha</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Passing Score:</span>
                    <span className="font-semibold text-emerald-400">{mock.passingMarks}% (DGCA Norm)</span>
                  </div>
                </div>
              </div>

              {/* Action */}
              <div>
                <Link
                  href="/pricing"
                  className="w-full inline-flex items-center justify-center py-2.5 px-4 rounded-xl text-xs font-bold text-amber-300 bg-amber-400/10 hover:bg-amber-400 hover:text-aviation-950 border border-amber-400/40 transition-colors"
                >
                  <svg className="w-4 h-4 mr-1.5 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                  Unlock with Premium Pass (₹300)
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
