"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useAuth } from "@/lib/auth-context";

export default function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, isAdmin, signOut } = useAuth();

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen((prev) => !prev);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-sky-100 shadow-sm shadow-sky-500/5 transition-all text-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Brand Logo & Name */}
          <Link href="/" className="flex items-center space-x-3 group">
            <div className="w-11 h-11 rounded-xl bg-sky-50 flex items-center justify-center shadow-md overflow-hidden border border-slate-200 group-hover:border-sky-500 transition-colors">
              <Image
                src="/images/logo.jpg"
                alt="CloudAero Emblem"
                width={44}
                height={44}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                priority
              />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-black tracking-tight text-slate-900 font-sans">
                  CloudAero
                </span>
                <span className="text-xs font-mono font-black uppercase px-2.5 py-0.5 rounded-md bg-sky-400 text-slate-950 border border-white/80 tracking-wider shadow-[0_0_12px_rgba(56,189,248,0.7)]">
                  DGCA
                </span>
              </div>
              <p className="text-[11px] font-medium tracking-tight -mt-0.5 text-slate-500">
                Commercial Pilot Exam Suite
              </p>
            </div>
          </Link>

          {/* Desktop Navigation Links (Visible only to authenticated pilots) */}
          {user && (
            <nav className="hidden lg:flex items-center space-x-8">
              <Link
                href="/"
                className="text-sm font-semibold text-slate-900 hover:text-sky-600 transition-colors"
              >
                Home
              </Link>
              <Link
                href="/subjects"
                className="text-sm font-medium text-slate-600 hover:text-sky-600 transition-colors"
              >
                DGCA Subjects
              </Link>
              <Link
                href="/question-bank"
                className="text-sm font-medium text-slate-600 hover:text-sky-600 transition-colors"
              >
                Question Bank
              </Link>
              <Link
                href="/mock-exams"
                className="text-sm font-medium text-slate-600 hover:text-sky-600 transition-colors"
              >
                CBT Mock Exams
              </Link>
              <Link
                href="/pricing"
                className="text-sm font-medium text-slate-600 hover:text-sky-600 transition-colors"
              >
                Cadet Passes
              </Link>
              <Link
                href="/about"
                className="text-sm font-medium text-slate-600 hover:text-sky-600 transition-colors"
              >
                About
              </Link>
            </nav>
          )}

          {/* Desktop Auth State Buttons */}
          <div className="hidden lg:flex items-center space-x-3.5">
            {user ? (
              <div className="flex items-center space-x-3">
                {isAdmin && (
                  <Link
                    href="/admin"
                    className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-amber-50 border border-amber-200 hover:bg-amber-100 text-amber-900 font-bold text-xs shadow-sm transition-all font-mono"
                  >
                    <span>🛡️</span>
                    <span>ADMIN CONSOLE</span>
                  </Link>
                )}

                <Link
                  href="/dashboard"
                  className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-800 font-semibold text-xs transition-colors shadow-sm"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span>Flight Deck</span>
                </Link>

                <button
                  type="button"
                  onClick={() => signOut()}
                  className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-500 hover:text-rose-600 hover:bg-rose-50 border border-transparent hover:border-rose-100 transition-colors"
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <Link
                  href="/login"
                  className="px-4 py-2 text-sm font-semibold text-slate-700 hover:text-sky-600 transition-colors"
                >
                  Sign In
                </Link>
                <Link
                  href="/register"
                  className="inline-flex items-center justify-center px-5 py-2.5 rounded-xl text-sm font-bold text-white bg-sky-500 hover:bg-sky-600 shadow-md shadow-sky-500/25 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
                >
                  Register Account →
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center lg:hidden">
            <button
              type="button"
              onClick={toggleMobileMenu}
              className="p-2 rounded-xl bg-slate-100 text-slate-700 hover:text-slate-900 border border-slate-200 transition-colors focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {isMobileMenuOpen ? (
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              )}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white/98 backdrop-blur-xl px-4 pt-4 pb-6 space-y-3 shadow-xl">
          {user && (
            <>
              <Link
                href="/"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block px-3 py-2 rounded-lg text-base font-semibold text-slate-900 hover:bg-slate-50"
              >
                Home
              </Link>
              <Link
                href="/subjects"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block px-3 py-2 rounded-lg text-base font-medium text-slate-700 hover:bg-slate-50"
              >
                DGCA Subjects
              </Link>
              <Link
                href="/question-bank"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block px-3 py-2 rounded-lg text-base font-medium text-slate-700 hover:bg-slate-50"
              >
                Question Bank
              </Link>
              <Link
                href="/mock-exams"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block px-3 py-2 rounded-lg text-base font-medium text-slate-700 hover:bg-slate-50"
              >
                Mock Exams
              </Link>
              <Link
                href="/pricing"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block px-3 py-2 rounded-lg text-base font-medium text-slate-700 hover:bg-slate-50"
              >
                Cadet Passes
              </Link>
              <Link
                href="/about"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block px-3 py-2 rounded-lg text-base font-medium text-slate-700 hover:bg-slate-50"
              >
                About
              </Link>
            </>
          )}

          <div className="pt-4 border-t border-slate-200">
            {user ? (
              <div className="space-y-2">
                <Link
                  href="/dashboard"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block w-full py-2.5 px-4 text-center rounded-xl bg-sky-50 text-sky-800 font-bold text-sm border border-sky-200"
                >
                  Access Student Dashboard
                </Link>
                {isAdmin && (
                  <Link
                    href="/admin"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block w-full py-2.5 px-4 text-center rounded-xl bg-amber-100 text-amber-900 font-bold text-sm border border-amber-200"
                  >
                    Admin Console
                  </Link>
                )}
                <button
                  type="button"
                  onClick={() => {
                    signOut();
                    setIsMobileMenuOpen(false);
                  }}
                  className="block w-full py-2 px-4 text-center text-xs font-semibold text-rose-600"
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <Link
                  href="/login"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block w-full py-2.5 px-4 text-center rounded-xl bg-slate-100 text-slate-800 font-bold text-sm"
                >
                  Sign In
                </Link>
                <Link
                  href="/register"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block w-full py-2.5 px-4 text-center rounded-xl bg-sky-500 text-white font-bold text-sm shadow-md"
                >
                  Register Pilot Account →
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
