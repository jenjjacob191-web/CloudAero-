"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";

export default function Footer() {
  return (
    <footer className="bg-gradient-to-b from-white via-sky-50/30 to-sky-50/60 text-slate-600 border-t border-sky-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand & Mission */}
          <div className="lg:col-span-2 space-y-4">
            <Link href="/" className="flex items-center space-x-3 group">
              <div className="w-11 h-11 rounded-xl bg-sky-50 flex items-center justify-center shadow-xs overflow-hidden border border-sky-200 group-hover:border-sky-400 transition-colors">
                <Image
                  src="/images/logo.jpg"
                  alt="CloudAero Emblem"
                  width={44}
                  height={44}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="text-2xl font-black tracking-tight text-slate-900 font-sans">
                  CloudAero
                </span>
                <span className="text-xs font-mono font-black uppercase px-2.5 py-0.5 rounded-md bg-sky-400 text-slate-950 border border-white/80 tracking-wider shadow-[0_0_12px_rgba(56,189,248,0.7)]">
                  DGCA
                </span>
              </div>
            </Link>
            <p className="text-sm text-slate-600 leading-relaxed max-w-sm">
              The premier aviation examination preparation platform engineered for aspiring Indian commercial and airline transport pilots. Master DGCA CPL/ATPL theory with chapter-wise drills and realistic CBT mock examinations.
            </p>
            <div className="pt-2">
              <span className="inline-flex items-center space-x-2 text-xs font-bold text-sky-800 bg-white px-3.5 py-1.5 rounded-full border border-sky-200 shadow-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Applicable for DGCA CPL, ATPL & PPL Syllabi</span>
              </span>
            </div>
          </div>

          {/* Column: DGCA Subjects */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 font-mono mb-4">
              Exam Subjects
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link href="/subjects/air-regulations" className="hover:text-sky-600 transition-colors">
                  Air Regulations
                </Link>
              </li>
              <li>
                <Link href="/subjects/aviation-meteorology" className="hover:text-sky-600 transition-colors">
                  Aviation Meteorology
                </Link>
              </li>
              <li>
                <Link href="/subjects/air-navigation" className="hover:text-sky-600 transition-colors">
                  Air Navigation
                </Link>
              </li>
              <li>
                <Link href="/subjects/technical-general" className="hover:text-sky-600 transition-colors">
                  Technical General
                </Link>
              </li>
              <li>
                <Link href="/subjects/technical-specific" className="hover:text-sky-600 transition-colors">
                  Technical Specific
                </Link>
              </li>
            </ul>
          </div>

          {/* Column: Quick Resources */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 font-mono mb-4">
              Practice & Mocks
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link href="/question-bank" className="hover:text-sky-600 transition-colors">
                  Chapter Question Bank
                </Link>
              </li>
              <li>
                <Link href="/mock-exams" className="hover:text-sky-600 transition-colors">
                  Subject Mock Exams
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="hover:text-sky-600 transition-colors">
                  Subscription Plans
                </Link>
              </li>
              <li>
                <Link href="/dashboard" className="hover:text-sky-600 transition-colors">
                  Student Dashboard
                </Link>
              </li>
              <li>
                <Link href="/faq" className="hover:text-sky-600 transition-colors">
                  DGCA Exam FAQ
                </Link>
              </li>
            </ul>
          </div>

          {/* Column: Platform & Legal */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 font-mono mb-4">
              Company & Legal
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link href="/about" className="hover:text-sky-600 transition-colors">
                  About CloudAero
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-sky-600 transition-colors">
                  Contact Support
                </Link>
              </li>
              <li>
                <Link href="/legal/terms" className="hover:text-sky-600 transition-colors">
                  Terms & Conditions
                </Link>
              </li>
              <li>
                <Link href="/legal/privacy" className="hover:text-sky-600 transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/legal/refund" className="hover:text-sky-600 transition-colors">
                  Refund & Cancellation
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Important DGCA Regulatory Disclaimer */}
        <div className="mt-12 pt-8 border-t border-sky-200/80">
          <div className="bg-white rounded-2xl p-5 border border-sky-200 shadow-xs mb-8">
            <h4 className="text-xs font-bold text-sky-800 uppercase tracking-wider mb-1.5 flex items-center">
              <svg className="w-4 h-4 mr-1.5 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              Official Regulatory Disclaimer
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              <strong>CloudAero DGCA</strong> is an independent educational training and exam-preparation platform developed to assist students in preparing for Indian aviation theory exams. CloudAero DGCA is <strong>not affiliated with, associated with, authorized by, endorsed by, or in any way officially connected with the Directorate General of Civil Aviation (DGCA), Government of India</strong>, or any of its subsidiaries or affiliates. All trademarks, official syllabus designations, and regulatory references belong to their respective statutory authorities.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 space-y-4 sm:space-y-0">
            <p>© {new Date().getFullYear()} CloudAero DGCA. All rights reserved.</p>
            <div className="flex items-center space-x-3">
              <button
                type="button"
                onClick={() => {
                  if (typeof window !== "undefined") {
                    window.dispatchEvent(new CustomEvent("cloudaero_replay_intro"));
                  }
                }}
                className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200 text-xs font-semibold transition-all hover:scale-105 cursor-pointer shadow-2xs"
                title="Watch the cockpit flight deck launch sequence again"
              >
                <span>🎬 Replay Intro</span>
              </button>
              <p className="flex items-center space-x-1 font-medium text-sky-700">
                <span>✈️ Engineered for Indian Commercial Pilot Aspirants</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
