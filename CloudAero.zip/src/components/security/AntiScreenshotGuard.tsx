"use client";

import React, { useEffect, useState, useCallback } from "react";
import { useAuth } from "@/lib/auth-context";

/**
 * AntiScreenshotGuard — High-Integrity Aviation Content Protection Suite
 *
 * Prevents unauthorized screen captures, PrintScreen keystrokes, Snipping Tool,
 * and content extraction while ensuring 100% smooth, uninterrupted user interaction
 * when selecting options, answering questions, or navigating.
 */
export default function AntiScreenshotGuard() {
  let user: { email?: string | null; id?: string } | null = null;
  try {
    const auth = useAuth();
    user = auth.user;
  } catch {
    // Graceful fallback during static prerendering
  }

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const candidateTag = user?.email
    ? `${user.email} • ID: ${user.id ? user.id.slice(0, 8) : "ANON"}`
    : "CLOUDAERO CANDIDATE • VERIFIED DGCA CADET";

  const triggerSecurityNotice = useCallback((message: string) => {
    // Overwrite clipboard buffer immediately
    if (typeof navigator !== "undefined" && navigator.clipboard && navigator.clipboard.writeText) {
      try {
        navigator.clipboard.writeText("").catch(() => {});
      } catch {
        // tolerate
      }
    }

    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;

    // 1. KEYBOARD TRAPS (PrintScreen, Snipping Tool, DevTools)
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key;
      const keyCode = e.keyCode || e.which;

      // PrintScreen key
      if (key === "PrintScreen" || keyCode === 44) {
        e.preventDefault();
        e.stopPropagation();
        triggerSecurityNotice("Screenshot Protected — DGCA Exam Material is Confidential");
        return false;
      }

      // Windows Snipping Tool: Win + Shift + S
      if (e.shiftKey && (key === "S" || key === "s") && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        e.stopPropagation();
        triggerSecurityNotice("Snipping Tool Intercepted — CloudAero Content Protected");
        return false;
      }

      // Mac Screenshot Shortcuts: Cmd + Shift + 3 / 4 / 5 / 6
      if (e.metaKey && e.shiftKey && ["3", "4", "5", "6"].includes(key)) {
        e.preventDefault();
        e.stopPropagation();
        triggerSecurityNotice("Screen Capture Intercepted — CloudAero Content Protected");
        return false;
      }

      // Print: Ctrl + P / Cmd + P
      if ((e.ctrlKey || e.metaKey) && (key === "p" || key === "P")) {
        e.preventDefault();
        e.stopPropagation();
        triggerSecurityNotice("Printing is disabled on this platform");
        return false;
      }

      // Save page: Ctrl + S / Cmd + S
      if ((e.ctrlKey || e.metaKey) && (key === "s" || key === "S")) {
        e.preventDefault();
        e.stopPropagation();
        triggerSecurityNotice("Saving page source is disabled");
        return false;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === "PrintScreen" || (e.keyCode || e.which) === 44) {
        triggerSecurityNotice("Screenshot Protected — Clipboard Cleared");
      }
    };

    // 2. CONTEXT MENU & COPY TRAP (Only for confidential content, allow inputs)
    const handleContextMenu = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      // Allow normal clicking everywhere, only prevent right-click inspection on exam content
      if (window.location.pathname.includes("/mock-exams") || window.location.pathname.includes("/practice")) {
        e.preventDefault();
      }
    };

    const handleCopy = (e: ClipboardEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      if (window.location.pathname.includes("/mock-exams") || window.location.pathname.includes("/practice")) {
        e.preventDefault();
        if (e.clipboardData) {
          e.clipboardData.setData(
            "text/plain",
            "DGCA Question Bank Protected — © CloudAero DGCA India."
          );
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    window.addEventListener("contextmenu", handleContextMenu);
    document.addEventListener("copy", handleCopy);
    document.addEventListener("cut", handleCopy);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
      window.removeEventListener("contextmenu", handleContextMenu);
      document.removeEventListener("copy", handleCopy);
      document.removeEventListener("cut", handleCopy);
    };
  }, [triggerSecurityNotice]);

  return (
    <>
      {/* Security Toast Notification (Only triggers when screenshot key is pressed) */}
      {toastMessage && (
        <div
          role="alert"
          aria-live="assertive"
          className="fixed top-5 left-1/2 transform -translate-x-1/2 z-[2147483647] flex items-center space-x-3 px-5 py-3 rounded-2xl bg-aviation-950/95 border border-rose-500/60 text-white shadow-2xl backdrop-blur-md animate-bounce"
        >
          <div className="w-8 h-8 rounded-xl bg-rose-500/20 border border-rose-500 text-rose-400 flex items-center justify-center font-bold text-sm">
            🛡️
          </div>
          <div>
            <p className="text-xs font-bold text-white tracking-wide">{toastMessage}</p>
            <p className="text-[10px] text-slate-400 font-mono">Forensic Session ID: {candidateTag}</p>
          </div>
        </div>
      )}

      {/* Subtle Forensic Watermark (Zero pointer events, never blocks clicks) */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 z-[100] overflow-hidden select-none opacity-[0.02]"
      >
        <div className="w-full h-full flex flex-wrap justify-between items-center rotate-[-25deg] scale-125 text-[10px] font-mono font-bold tracking-widest text-slate-900 uppercase">
          {Array.from({ length: 16 }).map((_, i) => (
            <span key={i} className="p-12 whitespace-nowrap">
              {`CLOUDAERO DGCA • ${candidateTag} • CONFIDENTIAL`}
            </span>
          ))}
        </div>
      </div>
    </>
  );
}
