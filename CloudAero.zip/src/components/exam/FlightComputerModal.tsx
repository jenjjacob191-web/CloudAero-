"use client";

import React, { useState } from "react";

interface FlightComputerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function FlightComputerModal({
  isOpen,
  onClose,
}: FlightComputerModalProps) {
  const [activeTab, setActiveTab] = useState<"calc" | "crosswind" | "altitude" | "oneInSixty">("calc");

  // Calculator State
  const [calcDisplay, setCalcDisplay] = useState("0");
  const [calcMemory, setCalcMemory] = useState<number | null>(null);
  const [calcOp, setCalcOp] = useState<string | null>(null);
  const [shouldResetDisplay, setShouldResetDisplay] = useState(false);

  // Crosswind Calculator State
  const [runwayHeading, setRunwayHeading] = useState<number>(90);
  const [windDirection, setWindDirection] = useState<number>(120);
  const [windSpeed, setWindSpeed] = useState<number>(18);

  // Pressure & Density Altitude State
  const [aerodromeElev, setAerodromeElev] = useState<number>(1000);
  const [qnhPressure, setQnhPressure] = useState<number>(1013);
  const [ambientTemp, setAmbientTemp] = useState<number>(25);

  // 1-in-60 Rule State
  const [distOffTrack, setDistOffTrack] = useState<number>(4);
  const [distFlown, setDistFlown] = useState<number>(40);
  const [distRemaining, setDistRemaining] = useState<number>(60);

  if (!isOpen) return null;

  // --- Calculator Logic ---
  const handleNumClick = (val: string) => {
    if (calcDisplay === "0" || shouldResetDisplay) {
      setCalcDisplay(val);
      setShouldResetDisplay(false);
    } else {
      setCalcDisplay(calcDisplay + val);
    }
  };

  const handleOpClick = (op: string) => {
    const current = parseFloat(calcDisplay);
    if (calcMemory === null) {
      setCalcMemory(current);
    } else if (calcOp) {
      const res = executeCalc(calcMemory, current, calcOp);
      setCalcMemory(res);
      setCalcDisplay(String(res));
    }
    setCalcOp(op);
    setShouldResetDisplay(true);
  };

  const executeCalc = (a: number, b: number, op: string): number => {
    switch (op) {
      case "+":
        return a + b;
      case "-":
        return a - b;
      case "×":
        return a * b;
      case "÷":
        return b !== 0 ? a / b : 0;
      default:
        return b;
    }
  };

  const handleEquals = () => {
    if (calcMemory !== null && calcOp) {
      const current = parseFloat(calcDisplay);
      const res = executeCalc(calcMemory, current, calcOp);
      setCalcDisplay(String(Math.round(res * 10000) / 10000));
      setCalcMemory(null);
      setCalcOp(null);
      setShouldResetDisplay(true);
    }
  };

  const handleClear = () => {
    setCalcDisplay("0");
    setCalcMemory(null);
    setCalcOp(null);
    setShouldResetDisplay(false);
  };

  const handleSqrt = () => {
    const current = parseFloat(calcDisplay);
    if (current >= 0) {
      setCalcDisplay(String(Math.round(Math.sqrt(current) * 10000) / 10000));
      setShouldResetDisplay(true);
    }
  };

  // --- Crosswind Calculations ---
  // Angle difference between runway and wind
  const angleDiff = Math.abs(windDirection - runwayHeading);
  const angleRad = (angleDiff * Math.PI) / 180;
  const headwindComponent = Math.round(windSpeed * Math.cos(angleRad));
  const crosswindComponent = Math.abs(Math.round(windSpeed * Math.sin(angleRad)));
  const crosswindSide = ((windDirection - runwayHeading + 360) % 360) > 180 ? "Port (Left)" : "Starboard (Right)";

  // --- Altitude Calculations ---
  // Pressure Altitude = Elevation + (1013.25 - QNH) * 30 ft (or 27.3 ft)
  const pressureAlt = Math.round(aerodromeElev + (1013 - qnhPressure) * 30);
  // ISA Temp at PA = 15 - (PA / 1000 * 2)
  const isaTemp = Math.round(15 - (pressureAlt / 1000) * 2);
  const isaDev = ambientTemp - isaTemp;
  // Density Altitude = Pressure Altitude + (118.8 * ISA Dev)
  const densityAlt = Math.round(pressureAlt + 120 * isaDev);

  // --- 1-in-60 Rule Calculations ---
  // Track Error Angle (TEA) = (Dist Off Track * 60) / Dist Flown
  const trackErrorAngle = distFlown > 0 ? Math.round(((distOffTrack * 60) / distFlown) * 10) / 10 : 0;
  // Closing Angle (CA) = (Dist Off Track * 60) / Dist Remaining
  const closingAngle = distRemaining > 0 ? Math.round(((distOffTrack * 60) / distRemaining) * 10) / 10 : 0;
  const totalCorrection = Math.round((trackErrorAngle + closingAngle) * 10) / 10;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-aviation-950 border border-aviation-700/80 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col text-slate-100 max-h-[90vh]">
        {/* Cockpit Instrument Header */}
        <div className="bg-aviation-900 px-5 py-3.5 border-b border-aviation-800 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <span className="w-3 h-3 rounded-full bg-skyAccent-400 animate-pulse" />
            <h3 className="font-mono text-sm font-bold tracking-wider text-skyAccent-300 uppercase">
              FLIGHT COMPUTER & CALC // CX-3 / E6B
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white rounded-lg p-1 transition-colors hover:bg-aviation-800"
            aria-label="Close Calculator"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Tab Selection */}
        <div className="grid grid-cols-4 bg-aviation-900/60 border-b border-aviation-800 text-xs font-mono">
          <button
            type="button"
            onClick={() => setActiveTab("calc")}
            className={`py-2.5 text-center font-semibold transition-colors border-b-2 ${
              activeTab === "calc"
                ? "border-skyAccent-400 text-skyAccent-300 bg-aviation-800/50"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            CALC
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("crosswind")}
            className={`py-2.5 text-center font-semibold transition-colors border-b-2 ${
              activeTab === "crosswind"
                ? "border-skyAccent-400 text-skyAccent-300 bg-aviation-800/50"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            CROSSWIND
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("altitude")}
            className={`py-2.5 text-center font-semibold transition-colors border-b-2 ${
              activeTab === "altitude"
                ? "border-skyAccent-400 text-skyAccent-300 bg-aviation-800/50"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            ALT / ISA
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("oneInSixty")}
            className={`py-2.5 text-center font-semibold transition-colors border-b-2 ${
              activeTab === "oneInSixty"
                ? "border-skyAccent-400 text-skyAccent-300 bg-aviation-800/50"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            1-IN-60
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-5 overflow-y-auto">
          {/* TAB 1: STANDARD CALCULATOR */}
          {activeTab === "calc" && (
            <div className="space-y-4">
              {/* Cockpit Digital Display */}
              <div className="bg-black/80 rounded-xl p-4 border border-aviation-800 text-right font-mono">
                <div className="text-xs text-skyAccent-400/80 h-4">
                  {calcMemory !== null && `${calcMemory} ${calcOp || ""}`}
                </div>
                <div className="text-3xl font-extrabold text-skyAccent-300 tracking-wider overflow-x-auto">
                  {calcDisplay}
                </div>
              </div>

              {/* Numpad Grid */}
              <div className="grid grid-cols-4 gap-2 font-mono text-sm">
                <button
                  type="button"
                  onClick={handleClear}
                  className="p-3 rounded-lg bg-rose-900/60 hover:bg-rose-800 text-rose-200 font-bold border border-rose-700/60"
                >
                  C
                </button>
                <button
                  type="button"
                  onClick={handleSqrt}
                  className="p-3 rounded-lg bg-aviation-800 hover:bg-aviation-700 text-slate-200 font-bold border border-aviation-700"
                >
                  √
                </button>
                <button
                  type="button"
                  onClick={() => handleOpClick("÷")}
                  className="p-3 rounded-lg bg-aviation-800 hover:bg-aviation-700 text-skyAccent-400 font-bold border border-aviation-700 text-base"
                >
                  ÷
                </button>
                <button
                  type="button"
                  onClick={() => handleOpClick("×")}
                  className="p-3 rounded-lg bg-aviation-800 hover:bg-aviation-700 text-skyAccent-400 font-bold border border-aviation-700 text-base"
                >
                  ×
                </button>

                {["7", "8", "9"].map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => handleNumClick(n)}
                    className="p-3 rounded-lg bg-aviation-900/90 hover:bg-aviation-800 text-white font-bold border border-aviation-800/80"
                  >
                    {n}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => handleOpClick("-")}
                  className="p-3 rounded-lg bg-aviation-800 hover:bg-aviation-700 text-skyAccent-400 font-bold border border-aviation-700 text-base"
                >
                  -
                </button>

                {["4", "5", "6"].map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => handleNumClick(n)}
                    className="p-3 rounded-lg bg-aviation-900/90 hover:bg-aviation-800 text-white font-bold border border-aviation-800/80"
                  >
                    {n}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => handleOpClick("+")}
                  className="p-3 rounded-lg bg-aviation-800 hover:bg-aviation-700 text-skyAccent-400 font-bold border border-aviation-700 text-base"
                >
                  +
                </button>

                {["1", "2", "3"].map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => handleNumClick(n)}
                    className="p-3 rounded-lg bg-aviation-900/90 hover:bg-aviation-800 text-white font-bold border border-aviation-800/80"
                  >
                    {n}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={handleEquals}
                  className="row-span-2 p-3 rounded-lg bg-skyAccent-500 hover:bg-skyAccent-400 text-aviation-950 font-extrabold text-xl shadow-lg shadow-skyAccent-500/30 flex items-center justify-center"
                >
                  =
                </button>

                <button
                  type="button"
                  onClick={() => handleNumClick("0")}
                  className="col-span-2 p-3 rounded-lg bg-aviation-900/90 hover:bg-aviation-800 text-white font-bold border border-aviation-800/80"
                >
                  0
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (!calcDisplay.includes(".")) handleNumClick(".");
                  }}
                  className="p-3 rounded-lg bg-aviation-900/90 hover:bg-aviation-800 text-white font-bold border border-aviation-800/80"
                >
                  .
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: CROSSWIND COMPONENT */}
          {activeTab === "crosswind" && (
            <div className="space-y-4 font-sans">
              <div className="grid grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-slate-400 font-mono mb-1">RWY HDG (°M)</label>
                  <input
                    type="number"
                    min="1"
                    max="360"
                    value={runwayHeading}
                    onChange={(e) => setRunwayHeading(Number(e.target.value) || 0)}
                    className="w-full bg-black/60 border border-aviation-700 rounded-lg p-2 font-mono text-skyAccent-300 font-bold text-center"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-mono mb-1">WIND DIR (°M)</label>
                  <input
                    type="number"
                    min="0"
                    max="360"
                    value={windDirection}
                    onChange={(e) => setWindDirection(Number(e.target.value) || 0)}
                    className="w-full bg-black/60 border border-aviation-700 rounded-lg p-2 font-mono text-skyAccent-300 font-bold text-center"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-mono mb-1">WIND VEL (kt)</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={windSpeed}
                    onChange={(e) => setWindSpeed(Number(e.target.value) || 0)}
                    className="w-full bg-black/60 border border-aviation-700 rounded-lg p-2 font-mono text-skyAccent-300 font-bold text-center"
                  />
                </div>
              </div>

              {/* Crosswind Telemetry Card */}
              <div className="bg-black/50 border border-aviation-800 rounded-xl p-4 space-y-3 font-mono">
                <div className="flex justify-between items-center border-b border-aviation-800/80 pb-2 text-xs">
                  <span className="text-slate-400">ANGULAR DIFFERENCE:</span>
                  <span className="text-skyAccent-400 font-bold">{angleDiff}°</span>
                </div>
                <div className="flex justify-between items-center border-b border-aviation-800/80 pb-2 text-xs">
                  <span className="text-slate-400">
                    {headwindComponent >= 0 ? "HEADWIND COMPONENT:" : "TAILWIND COMPONENT:"}
                  </span>
                  <span
                    className={`font-bold ${
                      headwindComponent >= 0 ? "text-emerald-400" : "text-amber-400"
                    }`}
                  >
                    {Math.abs(headwindComponent)} KT
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">CROSSWIND COMPONENT:</span>
                  <span
                    className={`font-extrabold text-base ${
                      crosswindComponent > 20
                        ? "text-rose-400 animate-pulse"
                        : crosswindComponent > 15
                        ? "text-amber-400"
                        : "text-emerald-400"
                    }`}
                  >
                    {crosswindComponent} KT ({crosswindSide})
                  </span>
                </div>
              </div>

              {crosswindComponent > 20 && (
                <div className="text-xs text-rose-300 bg-rose-950/60 border border-rose-800/60 p-2.5 rounded-lg flex items-center space-x-2">
                  <span>⚠️</span>
                  <span>WARNING: Crosswind exceeds 20 kt typical light aircraft maximum demonstrated limit!</span>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: PRESSURE & DENSITY ALTITUDE */}
          {activeTab === "altitude" && (
            <div className="space-y-4 font-sans">
              <div className="grid grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-slate-400 font-mono mb-1">ELEVATION (ft)</label>
                  <input
                    type="number"
                    value={aerodromeElev}
                    onChange={(e) => setAerodromeElev(Number(e.target.value) || 0)}
                    className="w-full bg-black/60 border border-aviation-700 rounded-lg p-2 font-mono text-skyAccent-300 font-bold text-center"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-mono mb-1">QNH (hPa/mb)</label>
                  <input
                    type="number"
                    value={qnhPressure}
                    onChange={(e) => setQnhPressure(Number(e.target.value) || 0)}
                    className="w-full bg-black/60 border border-aviation-700 rounded-lg p-2 font-mono text-skyAccent-300 font-bold text-center"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-mono mb-1">OAT (°C)</label>
                  <input
                    type="number"
                    value={ambientTemp}
                    onChange={(e) => setAmbientTemp(Number(e.target.value) || 0)}
                    className="w-full bg-black/60 border border-aviation-700 rounded-lg p-2 font-mono text-skyAccent-300 font-bold text-center"
                  />
                </div>
              </div>

              {/* Results */}
              <div className="bg-black/50 border border-aviation-800 rounded-xl p-4 space-y-3 font-mono">
                <div className="flex justify-between items-center border-b border-aviation-800/80 pb-2 text-xs">
                  <span className="text-slate-400">PRESSURE ALTITUDE (PA):</span>
                  <span className="text-skyAccent-400 font-bold">{pressureAlt} FT</span>
                </div>
                <div className="flex justify-between items-center border-b border-aviation-800/80 pb-2 text-xs">
                  <span className="text-slate-400">ISA TEMP AT PA:</span>
                  <span className="text-slate-200 font-semibold">{isaTemp}°C (Dev: {isaDev >= 0 ? `+${isaDev}` : isaDev}°C)</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">DENSITY ALTITUDE (DA):</span>
                  <span className="font-extrabold text-base text-amber-400">{densityAlt} FT</span>
                </div>
              </div>

              <div className="text-[11px] text-slate-400 font-mono">
                DGCA Formula: PA = Elev + (1013 - QNH) × 30 | DA = PA + (120 × ISA Dev)
              </div>
            </div>
          )}

          {/* TAB 4: 1-IN-60 RULE */}
          {activeTab === "oneInSixty" && (
            <div className="space-y-4 font-sans">
              <div className="grid grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-slate-400 font-mono mb-1">OFF TRACK (nm)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={distOffTrack}
                    onChange={(e) => setDistOffTrack(Number(e.target.value) || 0)}
                    className="w-full bg-black/60 border border-aviation-700 rounded-lg p-2 font-mono text-skyAccent-300 font-bold text-center"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-mono mb-1">DIST FLOWN (nm)</label>
                  <input
                    type="number"
                    value={distFlown}
                    onChange={(e) => setDistFlown(Number(e.target.value) || 0)}
                    className="w-full bg-black/60 border border-aviation-700 rounded-lg p-2 font-mono text-skyAccent-300 font-bold text-center"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-mono mb-1">DIST REMAIN (nm)</label>
                  <input
                    type="number"
                    value={distRemaining}
                    onChange={(e) => setDistRemaining(Number(e.target.value) || 0)}
                    className="w-full bg-black/60 border border-aviation-700 rounded-lg p-2 font-mono text-skyAccent-300 font-bold text-center"
                  />
                </div>
              </div>

              {/* 1-in-60 Results */}
              <div className="bg-black/50 border border-aviation-800 rounded-xl p-4 space-y-3 font-mono">
                <div className="flex justify-between items-center border-b border-aviation-800/80 pb-2 text-xs">
                  <span className="text-slate-400">TRACK ERROR ANGLE (TEA):</span>
                  <span className="text-skyAccent-400 font-bold">{trackErrorAngle}°</span>
                </div>
                <div className="flex justify-between items-center border-b border-aviation-800/80 pb-2 text-xs">
                  <span className="text-slate-400">CLOSING ANGLE (CA):</span>
                  <span className="text-skyAccent-400 font-bold">{closingAngle}°</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">TOTAL HEADING CORRECTION:</span>
                  <span className="font-extrabold text-base text-emerald-400">ALTER HEADING BY {totalCorrection}°</span>
                </div>
              </div>

              <div className="text-[11px] text-slate-400 font-mono">
                DGCA Navigation rule: Alter heading toward original track by (TEA + Closing Angle) to reach destination.
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-aviation-900/80 px-5 py-3 border-t border-aviation-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-aviation-800 hover:bg-aviation-700 text-xs font-semibold text-white transition-colors"
          >
            Close Calculator [ESC]
          </button>
        </div>
      </div>
    </div>
  );
}
