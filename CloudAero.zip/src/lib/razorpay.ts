import crypto from "crypto";

export interface CreateOrderParams {
  amountINR: number;
  receiptId: string;
  notes?: Record<string, string>;
}

export interface VerifySignatureParams {
  orderId: string;
  paymentId: string;
  signature: string;
  secret: string;
}

/**
 * Verifies Razorpay HMAC SHA-256 Signature using constant-time comparison.
 * Prevents timing attacks and ensures payments cannot be spoofed by client-side modifications.
 */
export function verifyRazorpaySignature({
  orderId,
  paymentId,
  signature,
  secret,
}: VerifySignatureParams): boolean {
  try {
    const body = `${orderId}|${paymentId}`;
    const expectedSignature = crypto
      .createHmac("sha256", secret)
      .update(body)
      .digest("hex");

    return crypto.timingSafeEqual(
      Buffer.from(expectedSignature, "utf-8"),
      Buffer.from(signature, "utf-8")
    );
  } catch (err) {
    console.error("Razorpay signature verification error:", err);
    return false;
  }
}

/**
 * Verifies Razorpay Webhook HMAC SHA-256 signature
 */
export function verifyRazorpayWebhookSignature(body: string, signature: string, secret: string): boolean {
  try {
    const expectedSignature = crypto
      .createHmac("sha256", secret)
      .update(body)
      .digest("hex");
    return crypto.timingSafeEqual(
      Buffer.from(expectedSignature, "utf-8"),
      Buffer.from(signature, "utf-8")
    );
  } catch (err) {
    console.error("Razorpay webhook signature verification error:", err);
    return false;
  }
}

export async function createRazorpayOrder({
  amountINR,
  receiptId,
  notes = {},
}: CreateOrderParams): Promise<{ id: string; amount: number; currency: string }> {
  const keyId = process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID?.trim();
  const keySecret = process.env.RAZORPAY_KEY_SECRET?.trim();

  if (!keyId || !keySecret || keyId.includes("placeholder")) {
    console.warn("Razorpay credentials not configured or in placeholder mode. Using local test order simulation.");
    return {
      id: `order_sim_${Date.now()}`,
      amount: Math.round(amountINR * 100), // convert to paise
      currency: "INR",
    };
  }

  try {
    const authHeader = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
    const response = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${authHeader}`,
      },
      body: JSON.stringify({
        amount: Math.round(amountINR * 100), // paise
        currency: "INR",
        receipt: receiptId,
        notes,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      let errorMessage = `Razorpay API status ${response.status}`;
      try {
        const errorJson = JSON.parse(errorText);
        if (errorJson?.error?.description) {
          errorMessage = errorJson.error.description;
        }
      } catch {
        errorMessage = errorText || errorMessage;
      }

      console.error(`Razorpay API error (${response.status}):`, errorMessage);

      // If in sandbox test mode, fallback to simulation
      if (keyId.startsWith("rzp_test_")) {
        console.warn("Using resilient test order fallback for test mode.");
        return {
          id: `order_sim_${Date.now()}`,
          amount: Math.round(amountINR * 100),
          currency: "INR",
        };
      }

      throw new Error(errorMessage);
    }

    const orderData = await response.json();
    return {
      id: orderData.id,
      amount: orderData.amount,
      currency: orderData.currency,
    };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("Razorpay order creation failed:", msg);

    // If test key mode, allow simulation fallback
    if (keyId?.startsWith("rzp_test_")) {
      return {
        id: `order_sim_${Date.now()}`,
        amount: Math.round(amountINR * 100),
        currency: "INR",
      };
    }

    throw new Error(msg || "Could not reach Razorpay payment servers. Please check network connection.");
  }
}
