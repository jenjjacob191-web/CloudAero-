// Shared role and permission utilities usable in both Server and Client runtimes

export const DEFAULT_ADMIN_EMAILS = [
  "admin@cloudaero.in",
  "admin@aeroprep.in",
  "admin@dgca.gov.in",
  "chief.instructor@cloudaero.in",
  "chief.instructor@aeroprep.in",
  "administrationprep@gmail.com",
];

export function checkIsAdminEmail(email?: string | null): boolean {
  if (!email) return false;
  const envEmails = (process.env.NEXT_PUBLIC_ADMIN_EMAILS || "")
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
  const allowed = [...DEFAULT_ADMIN_EMAILS.map((e) => e.toLowerCase()), ...envEmails];
  return allowed.includes(email.trim().toLowerCase());
}
