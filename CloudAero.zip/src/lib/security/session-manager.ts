import { randomInt } from "crypto";
import { supabaseAdmin } from "@/lib/supabase/admin";

interface ActiveSession {
  sessionId: string;
  userId: string;
  email: string;
  userAgent: string;
  ipAddress: string;
  createdAt: number;
  lastHeartbeat: number;
}

interface PendingOtp {
  code: string;
  email: string;
  expiresAt: number;
  attempts: number;
  createdAt: number;
}

// In-memory single-device session registry (persists across requests in Node server runtime)
// Global variable ensures persistence during Next.js server runtime
declare global {
  // eslint-disable-next-line no-var
  var __aeroprep_sessions: Map<string, ActiveSession> | undefined;
  // eslint-disable-next-line no-var
  var __aeroprep_otps: Map<string, PendingOtp> | undefined;
}

const activeSessions: Map<string, ActiveSession> =
  globalThis.__aeroprep_sessions || new Map<string, ActiveSession>();
globalThis.__aeroprep_sessions = activeSessions;

const pendingOtps: Map<string, PendingOtp> =
  globalThis.__aeroprep_otps || new Map<string, PendingOtp>();
globalThis.__aeroprep_otps = pendingOtps;

// Maximum allowed verification attempts before OTP is invalidated
const MAX_OTP_ATTEMPTS = 5;
// OTP validity duration: 5 minutes
const OTP_TTL_MS = 5 * 60 * 1000;

/**
 * Generate and dispatch a 6-digit numeric OTP for email verification
 */
export async function generateAndSendLoginOtp(
  email: string,
  clientIp = "unknown"
): Promise<{ success: boolean; message: string; devHint?: string }> {
  const normalizedEmail = email.toLowerCase().trim();

  // Generate cryptographically secure 6-digit code (100000 - 999999)
  const code = randomInt(100000, 1000000).toString();
  const now = Date.now();

  pendingOtps.set(normalizedEmail, {
    code,
    email: normalizedEmail,
    expiresAt: now + OTP_TTL_MS,
    attempts: 0,
    createdAt: now,
  });

  console.log(`\n=======================================================`);
  console.log(`🔐 CLOUDAERO 2FA LOGIN VERIFICATION CODE`);
  console.log(`👤 Target Email : ${normalizedEmail}`);
  console.log(`🔑 6-Digit Code : ${code}`);
  console.log(`⏳ Validity     : 5 Minutes (Expires at ${new Date(now + OTP_TTL_MS).toLocaleTimeString()})`);
  console.log(`🌐 Requested IP : ${clientIp}`);
  console.log(`=======================================================\n`);

  // Dispatch real email OTP via Supabase GoTrue Auth service
  try {
    const supabaseUrl =
      process.env.NEXT_PUBLIC_SUPABASE_URL || "https://vilaryczczniwiaeezlg.supabase.co";
    const serviceKey =
      process.env.SUPABASE_SERVICE_ROLE_KEY || "sb_secret_SipEf5BBB2DTJE03DrAELw_DhoLprF2";

    const emailRes = await fetch(`${supabaseUrl}/auth/v1/otp`, {
      method: "POST",
      headers: {
        apikey: serviceKey,
        Authorization: `Bearer ${serviceKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: normalizedEmail,
        create_user: false,
      }),
    });

    if (emailRes.ok) {
      console.log(`✉️ Real email OTP successfully dispatched to ${normalizedEmail} via Supabase Mail Delivery`);
    } else {
      const errText = await emailRes.text();
      console.warn(`Supabase GoTrue mail status ${emailRes.status}:`, errText);
    }
  } catch (err) {
    console.warn("Supabase background email trigger exception:", (err as Error).message);
  }

  return {
    success: true,
    message: `Verification code sent to ${normalizedEmail}. Please check your inbox.`,
    devHint: code, // Provides instant testing visibility for developer/admin
  };
}

/**
 * Verify submitted 6-digit OTP (checks both local generator and Supabase email token)
 */
export async function verifyLoginOtp(
  email: string,
  submittedCode: string
): Promise<{ success: boolean; error?: string }> {
  const normalizedEmail = email.toLowerCase().trim();
  const cleanCode = submittedCode.trim();

  // 1. First check local in-memory OTP store
  const record = pendingOtps.get(normalizedEmail);
  if (record && record.code === cleanCode) {
    if (Date.now() <= record.expiresAt && record.attempts < MAX_OTP_ATTEMPTS) {
      pendingOtps.delete(normalizedEmail);
      return { success: true };
    }
  }

  // 2. Also verify against Supabase GoTrue email token
  try {
    const supabaseUrl =
      process.env.NEXT_PUBLIC_SUPABASE_URL || "https://vilaryczczniwiaeezlg.supabase.co";
    const serviceKey =
      process.env.SUPABASE_SERVICE_ROLE_KEY || "sb_secret_SipEf5BBB2DTJE03DrAELw_DhoLprF2";

    const verifyRes = await fetch(`${supabaseUrl}/auth/v1/verify`, {
      method: "POST",
      headers: {
        apikey: serviceKey,
        Authorization: `Bearer ${serviceKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        type: "email",
        email: normalizedEmail,
        token: cleanCode,
      }),
    });

    if (verifyRes.ok) {
      pendingOtps.delete(normalizedEmail);
      return { success: true };
    }
  } catch (err) {
    console.warn("Supabase verify token error:", err);
  }

  // If local record exists and failed, record attempt
  if (record) {
    record.attempts += 1;
    const remaining = Math.max(0, MAX_OTP_ATTEMPTS - record.attempts);
    if (remaining === 0) {
      pendingOtps.delete(normalizedEmail);
      return {
        success: false,
        error: "Too many incorrect attempts. For security, this code has been revoked.",
      };
    }
    return {
      success: false,
      error: `Invalid verification code. ${remaining} attempt(s) remaining. Please check your email inbox.`,
    };
  }

  return {
    success: false,
    error: "Invalid or expired verification code. Please request a new code.",
  };
}

/**
 * Register a new device session for a user.
 * Automatically invalidates any previous session across any other device.
 * Indexed by both userId and email to guarantee cross-device kick-out.
 */
export async function registerDeviceSession(
  userId: string,
  email: string,
  userAgent = "Unknown Device",
  ipAddress = "unknown"
): Promise<{ sessionId: string; previousSessionTerminated: boolean }> {
  const normalizedUserId = (userId || "").trim();
  const normalizedEmail = (email || "").toLowerCase().trim();

  // Look for any existing session by userId OR by email
  const previous: ActiveSession | undefined =
    (normalizedUserId ? activeSessions.get(normalizedUserId) : undefined) ||
    (normalizedEmail ? activeSessions.get(normalizedEmail) : undefined);
  const hadPrevious = Boolean(previous && previous.sessionId);

  // Generate unique session identifier
  const sessionId = `cloudaero_sess_${Date.now()}_${randomInt(100000, 999999)}`;
  const now = Date.now();

  const newSession: ActiveSession = {
    sessionId,
    userId: normalizedUserId || normalizedEmail,
    email: normalizedEmail,
    userAgent,
    ipAddress,
    createdAt: now,
    lastHeartbeat: now,
  };

  // Set as the only active session for this user across both keys
  if (normalizedUserId) {
    activeSessions.set(normalizedUserId, newSession);
  }
  if (normalizedEmail) {
    activeSessions.set(normalizedEmail, newSession);
  }

  if (hadPrevious) {
    console.log(
      `🚨 [CONCURRENT SESSION DETECTED] User ${email} logged in on new device (${userAgent}). Previous session (${previous?.sessionId}) has been terminated.`
    );
  } else {
    console.log(
      `✅ [NEW ACTIVE SESSION] User ${email} session registered (${sessionId}) on ${userAgent}.`
    );
  }

  // Sync with Supabase profiles table in background if UUID
  if (normalizedUserId && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(normalizedUserId)) {
    try {
      await (supabaseAdmin.from("profiles") as any)
        .update({
          updated_at: new Date(now).toISOString(),
        })
        .eq("id", normalizedUserId);
    } catch {
      // ignore
    }
  }

  return {
    sessionId,
    previousSessionTerminated: hadPrevious,
  };
}

/**
 * Validate that client's local session matches the single active server session.
 * If another device has logged in since, this will return isValid: false.
 */
export function validateDeviceSession(
  userId?: string,
  clientSessionId?: string,
  email?: string
): { isValid: boolean; reason?: "CONCURRENT_DEVICE_LOGIN" | "SESSION_NOT_FOUND" } {
  const normalizedUserId = (userId || "").trim();
  const normalizedEmail = (email || "").toLowerCase().trim();

  if (!normalizedUserId && !normalizedEmail) {
    return { isValid: true };
  }

  // Find active session by userId or email
  let active = normalizedUserId ? activeSessions.get(normalizedUserId) : undefined;
  if (!active && normalizedEmail) {
    active = activeSessions.get(normalizedEmail);
  }

  // If no active session recorded on server yet:
  if (!active) {
    if (clientSessionId) {
      // Adopt this client's session as authoritative so subsequent logins kick it out
      const now = Date.now();
      const adoptedSession: ActiveSession = {
        sessionId: clientSessionId,
        userId: normalizedUserId || normalizedEmail,
        email: normalizedEmail,
        userAgent: "Client Browser",
        ipAddress: "unknown",
        createdAt: now,
        lastHeartbeat: now,
      };
      if (normalizedUserId) activeSessions.set(normalizedUserId, adoptedSession);
      if (normalizedEmail) activeSessions.set(normalizedEmail, adoptedSession);
    }
    return { isValid: true };
  }

  // If client session ID does not match the active session registered for this account:
  if (active.sessionId !== clientSessionId) {
    const sessionAgeMs = Date.now() - (active.createdAt || 0);

    // If the active session was registered less than 10 seconds ago (e.g. during OAuth or login handoff),
    // allow the client to adopt the active session ID rather than kicking it out in a false conflict.
    if (sessionAgeMs < 10000) {
      console.log(
        `ℹ️ [SESSION HANDOFF] Client (${clientSessionId}) synchronized to active session (${active.sessionId}) during login grace window.`
      );
      return {
        isValid: true,
      };
    }

    console.warn(
      `🚨 [KICK-OUT] Active session mismatch for ${normalizedEmail || normalizedUserId}! Client has (${clientSessionId}), but server active session is (${active.sessionId}). Rejecting client.`
    );
    return {
      isValid: false,
      reason: "CONCURRENT_DEVICE_LOGIN",
    };
  }

  // Update heartbeat timestamp
  active.lastHeartbeat = Date.now();
  return { isValid: true };
}

/**
 * Terminate active device session upon user manual Sign Out
 */
export function terminateDeviceSession(userId?: string, email?: string) {
  if (userId) activeSessions.delete(userId.trim());
  if (email) activeSessions.delete(email.toLowerCase().trim());
}
