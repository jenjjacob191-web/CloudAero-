/**
 * AeroPrep DGCA — Calendar Date Utilities
 * Accurately calculates 1-month and 6-month subscription expiries
 * with month-end edge case handling (e.g. Jan 31 -> Feb 28/29, Mar 31 -> Apr 30).
 */

export function calculateCalendarExpiryDate(startDate: Date, monthsToAdd: number): Date {
  const result = new Date(startDate.getTime());
  const originalDay = result.getDate();

  // Move forward by target months
  result.setMonth(result.getMonth() + monthsToAdd);

  // If the new month has fewer days than originalDay, JavaScript automatically
  // rolled over into the next month. We adjust back to the last day of the target month.
  // Example: Jan 31 + 1 month in JS rolls to March 2 or 3.
  // We detect this and pin it to the last day of February.
  if (result.getDate() !== originalDay) {
    result.setDate(0); // Sets to last day of previous month
  }

  // Preserve end of day timestamp for full validity period
  result.setHours(23, 59, 59, 999);
  return result;
}

export function isSubscriptionActive(expiresAt: string | Date | null | undefined): boolean {
  if (!expiresAt) return false;
  const expiry = new Date(expiresAt).getTime();
  return expiry > Date.now();
}

export function getDaysRemaining(expiresAt: string | Date | null | undefined): number {
  if (!expiresAt) return 0;
  const diff = new Date(expiresAt).getTime() - Date.now();
  return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
}

export function formatINR(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}
