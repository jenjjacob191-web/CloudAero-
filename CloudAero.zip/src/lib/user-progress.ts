// Client-side and database-synchronized real student analytics store

export interface RealMockAttempt {
  id: string;
  examId: string;
  examTitle: string;
  subjectName: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  passed: boolean;
  timeSpentSeconds: number;
  completedAt: string;
}

export interface RealBookmarkedQuestion {
  id: string;
  subjectName: string;
  chapterTitle: string;
  questionText: string;
  correctAnswerText: string;
  explanation: string;
  memoryAid?: string;
  bookmarkedAt: string;
}

export interface StudentStats {
  totalQuestionsPracticed: number;
  totalCorrect: number;
  accuracyPercentage: number;
  chaptersCompleted: number;
  totalChapters: number;
  mockAttemptsCount: number;
  mockAttemptsPassed: number;
  subjectProgress: Record<string, { attempted: number; total: number; accuracy: number }>;
}

const STORAGE_KEYS = {
  PRACTICE_ANSWERS: "aeroprep_real_practice_answers",
  COMPLETED_CHAPTERS: "aeroprep_real_completed_chapters",
  MOCK_ATTEMPTS: "aeroprep_real_mock_attempts",
  BOOKMARKS: "aeroprep_real_bookmarks",
};

// Safe access to window.localStorage
function getStorageItem<T>(key: string, defaultValue: T): T {
  if (typeof window === "undefined") return defaultValue;
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function setStorageItem<T>(key: string, value: T): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.warn("Storage write error:", err);
  }
}

// 1. Get real student statistics
export function getRealStudentStats(): StudentStats {
  const practiceAnswers = getStorageItem<Record<string, { isCorrect: boolean; subjectId: string; chapterId: string }>>(
    STORAGE_KEYS.PRACTICE_ANSWERS,
    {}
  );
  const completedChapters = getStorageItem<string[]>(STORAGE_KEYS.COMPLETED_CHAPTERS, []);
  const mockAttempts = getStorageItem<RealMockAttempt[]>(STORAGE_KEYS.MOCK_ATTEMPTS, []);

  const totalAttempted = Object.keys(practiceAnswers).length;
  const totalCorrect = Object.values(practiceAnswers).filter((a) => a.isCorrect).length;
  const accuracy = totalAttempted > 0 ? Math.round((totalCorrect / totalAttempted) * 100) : 0;

  const passedMocks = mockAttempts.filter((m) => m.passed).length;

  // Compute real per-subject progress
  const subjectProgress: StudentStats["subjectProgress"] = {
    "air-regulations": { attempted: 0, total: 0, accuracy: 0 },
    "aviation-meteorology": { attempted: 0, total: 0, accuracy: 0 },
    "air-navigation": { attempted: 0, total: 0, accuracy: 0 },
    "technical-general": { attempted: 0, total: 0, accuracy: 0 },
    "technical-specific": { attempted: 0, total: 0, accuracy: 0 },
  };

  Object.values(practiceAnswers).forEach((ans) => {
    if (subjectProgress[ans.subjectId]) {
      subjectProgress[ans.subjectId].attempted++;
    }
  });

  return {
    totalQuestionsPracticed: totalAttempted,
    totalCorrect,
    accuracyPercentage: accuracy,
    chaptersCompleted: completedChapters.length,
    totalChapters: 24,
    mockAttemptsCount: mockAttempts.length,
    mockAttemptsPassed: passedMocks,
    subjectProgress,
  };
}

// 2. Record a real question practice answer
export function recordRealQuestionPractice(
  questionId: string,
  isCorrect: boolean,
  subjectId: string,
  chapterId: string
) {
  const current = getStorageItem<Record<string, { isCorrect: boolean; subjectId: string; chapterId: string }>>(
    STORAGE_KEYS.PRACTICE_ANSWERS,
    {}
  );
  current[questionId] = { isCorrect, subjectId, chapterId };
  setStorageItem(STORAGE_KEYS.PRACTICE_ANSWERS, current);
}

// 3. Mark chapter completed
export function recordRealChapterCompletion(chapterId: string) {
  const current = getStorageItem<string[]>(STORAGE_KEYS.COMPLETED_CHAPTERS, []);
  if (!current.includes(chapterId)) {
    current.push(chapterId);
    setStorageItem(STORAGE_KEYS.COMPLETED_CHAPTERS, current);
  }
}

// 4. Record real mock exam attempt
export function recordRealMockAttempt(attempt: RealMockAttempt) {
  const current = getStorageItem<RealMockAttempt[]>(STORAGE_KEYS.MOCK_ATTEMPTS, []);
  // Prepend newest attempt
  const updated = [attempt, ...current.filter((a) => a.id !== attempt.id)];
  setStorageItem(STORAGE_KEYS.MOCK_ATTEMPTS, updated);
}

// 5. Get all real mock attempts
export function getRealMockAttempts(): RealMockAttempt[] {
  return getStorageItem<RealMockAttempt[]>(STORAGE_KEYS.MOCK_ATTEMPTS, []);
}

// 6. Get real bookmarks
export function getRealBookmarks(): RealBookmarkedQuestion[] {
  return getStorageItem<RealBookmarkedQuestion[]>(STORAGE_KEYS.BOOKMARKS, []);
}

// 7. Toggle bookmark
export function toggleRealBookmark(item: RealBookmarkedQuestion): boolean {
  const current = getStorageItem<RealBookmarkedQuestion[]>(STORAGE_KEYS.BOOKMARKS, []);
  const exists = current.some((b) => b.id === item.id);
  let updated: RealBookmarkedQuestion[];
  if (exists) {
    updated = current.filter((b) => b.id !== item.id);
  } else {
    updated = [item, ...current];
  }
  setStorageItem(STORAGE_KEYS.BOOKMARKS, updated);
  return !exists;
}
