import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        aviation: {
          50: "#f0f5fa",
          100: "#e1ebf5",
          200: "#c4d7ec",
          300: "#98bde0",
          400: "#659ecf",
          500: "#3f80bc",
          600: "#2c659e",
          700: "#235180",
          800: "#133e87", // Primary Aviation Blue
          900: "#0b2545", // Deep Cockpit Navy
          950: "#07172c",
        },
        skyAccent: {
          50: "#f0f9ff",
          100: "#e0f2fe",
          200: "#bae6fd",
          300: "#7dd3fc",
          400: "#38bdf8",
          500: "#0ea5e9",
          600: "#0284c7",
        },
        cockpit: {
          green: "#10b981", // Passed / Correct
          amber: "#f59e0b", // Flagged / Review
          red: "#ef4444",   // Incorrect
          slate: "#64748b", // Neutral / Unanswered
        },
      },
      fontFamily: {
        sans: [
          "Inter",
          "-apple-system",
          "BlinkMacSystemFont",
          "Segoe UI",
          "Roboto",
          "sans-serif",
        ],
        mono: [
          "JetBrains Mono",
          "Fira Code",
          "Consolas",
          "monospace",
        ],
      },
      boxShadow: {
        aviation: "0 4px 20px -2px rgba(11, 37, 69, 0.08)",
        "aviation-hover": "0 10px 25px -3px rgba(11, 37, 69, 0.15)",
        cockpit: "inset 0 1px 2px 0 rgba(0, 0, 0, 0.05)",
      },
    },
  },
  plugins: [],
};

export default config;
