@echo off
title CloudAero DGCA - Localhost:3000
color 0b
echo ======================================================================
echo              CLOUDAERO DGCA - LAUNCHING LOCALHOST:3000
echo ======================================================================
echo.
cd /d "C:\Users\jenjj\.gemini\antigravity\scratch\aeroprep-dgca"

:: Add Node.js to PATH
set PATH=%PATH%;C:\Users\jenjj\.nodejs

echo Localhost URL: http://localhost:3000
echo Opening in your browser...
echo.

:: Automatically open browser after 2 seconds
start "" http://localhost:3000

:: Start Next.js development server
npm run dev

pause
