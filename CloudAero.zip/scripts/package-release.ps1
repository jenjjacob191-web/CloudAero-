# CloudAero — POSIX-Compliant Release Packaging Script
# Generates zip archives with forward slashes ('/') for 100% Linux/Vercel/GitHub compatibility.

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$source = "C:\Users\jenjj\.gemini\antigravity\scratch\aeroprep-dgca"
$primary = "C:\Users\jenjj\.gemini\antigravity\brain\d349407a-8d3b-48cd-8c4b-a79e11643b17\AEROP.zip"

if (Test-Path $primary) { Remove-Item -Force $primary }

Write-Host "Creating POSIX-compliant archive: $primary ..."

$zipStream = [System.IO.File]::Create($primary)
$archive = New-Object System.IO.Compression.ZipArchive($zipStream, [System.IO.Compression.ZipArchiveMode]::Create)

$allFiles = Get-ChildItem -Path $source -Recurse -File
$count = 0

foreach ($file in $allFiles) {
    $relative = $file.FullName.Substring($source.Length).TrimStart('\', '/')
    
    # Exclude build caches, modules, and local temp files
    if ($relative -notmatch '^(node_modules|\.next|\.git|dist|build|coverage)($|\\|/)') {
        # Normalize to forward slash for Linux / Vercel compatibility
        $entryName = $relative -replace '\\', '/'
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
            $archive,
            $file.FullName,
            $entryName,
            [System.IO.Compression.CompressionLevel]::Optimal
        ) | Out-Null
        $count++
    }
}

$archive.Dispose()
$zipStream.Dispose()

$size = (Get-Item $primary).Length / 1MB
Write-Host ("Successfully packaged {0} files into {1} ({2:N2} MB)" -f $count, $primary, $size)

# Copy to Downloads and Desktop targets
$otherTargets = @(
    "C:\Users\jenjj\Downloads\AEROP.zip",
    "C:\Users\jenjj\OneDrive\Desktop\AEROP.zip",
    "C:\Users\jenjj\Downloads\CloudAero.zip",
    "C:\Users\jenjj\OneDrive\Desktop\CloudAero.zip",
    "C:\Users\jenjj\Downloads\aeroprep-dgca-github.zip",
    "C:\Users\jenjj\OneDrive\Desktop\aeroprep-dgca-github.zip",
    "C:\Users\jenjj\Downloads\aeroprep-dgca-vercel.zip",
    "C:\Users\jenjj\OneDrive\Desktop\aeroprep-dgca-vercel.zip",
    "C:\Users\jenjj\.gemini\antigravity\brain\d349407a-8d3b-48cd-8c4b-a79e11643b17\aeroprep-dgca-github.zip"
)

foreach ($target in $otherTargets) {
    try {
        if (Test-Path $target) { Remove-Item -Force $target -ErrorAction SilentlyContinue }
        Copy-Item $primary $target -Force -ErrorAction SilentlyContinue
        Write-Host "Copied to: $target"
    } catch {}
}
