// AeroPrep DGCA — Automated Pre-Flight Smoke Test & System Health Runner
// Run via: node scripts/smoke-test.mjs

const BASE_URL = process.env.BASE_URL || "http://localhost:3000";

const ROUTES_TO_TEST = [
  { path: "/", name: "Homepage & Flight Deck Hero" },
  { path: "/subjects", name: "DGCA Subjects Catalog" },
  { path: "/subjects/aviation-meteorology", name: "Meteorology Subject Details" },
  { path: "/subjects/air-navigation", name: "Navigation Subject Details" },
  { path: "/question-bank", name: "Question Bank Explorer" },
  { path: "/practice/pressure-and-altimetry", name: "Chapter Practice Drill" },
  { path: "/mock-exams", name: "Subject-Wise Mock Catalog" },
  { path: "/mock-exams/mock-met-diagnostic/instructions", name: "CBT Exam Instructions" },
  { path: "/mock-exams/mock-met-diagnostic/live", name: "Live CBT Exam Room" },
  { path: "/pricing", name: "Subscription Pricing" },
  { path: "/checkout?plan=monthly", name: "Checkout Portal" },
  { path: "/login", name: "Candidate Login" },
  { path: "/register", name: "Student Registration" },
  { path: "/forgot-password", name: "Password Recovery" },
  { path: "/dashboard", name: "Student Dashboard" },
  { path: "/about", name: "About AeroPrep" },
  { path: "/contact", name: "Flight Support & Dispatch" },
  { path: "/faq", name: "DGCA FAQ" },
  { path: "/legal/terms", name: "Terms & Conditions" },
  { path: "/legal/privacy", name: "Privacy Policy" },
  { path: "/legal/refund", name: "Refund & Cancellation" },
  { path: "/admin", name: "Admin Dashboard" },
  { path: "/admin/subjects", name: "Admin Syllabus Manager" },
  { path: "/admin/questions", name: "Admin Question Editor & CSV Uploader" },
  { path: "/admin/mock-exams", name: "Admin Mock Exam Builder" },
  { path: "/admin/students", name: "Admin Student Directory" },
  { path: "/admin/reports", name: "Admin Question Issues Inbox" },
];

async function runSmokeTests() {
  console.log("\n=======================================================");
  console.log("✈️  AEROPREP DGCA — PRE-FLIGHT SMOKE TEST RUNNER");
  console.log("=======================================================\n");
  console.log(`Target Host: ${BASE_URL}\n`);

  let passedRoutes = 0;
  let failedRoutes = 0;

  // 1. Verify Public & Protected HTTP Endpoints
  console.log("--- 1. Testing Route Availability & HTTP Status ---");
  for (const route of ROUTES_TO_TEST) {
    try {
      const res = await fetch(`${BASE_URL}${route.path}`, { method: "GET" });
      if (res.status === 200) {
        console.log(`  [PASS] ${res.status} OK   - ${route.name} (${route.path})`);
        passedRoutes++;
      } else {
        console.error(`  [FAIL] ${res.status} ERR  - ${route.name} (${route.path})`);
        failedRoutes++;
      }
    } catch (err) {
      console.error(`  [FAIL] EXCEPTION  - ${route.name} (${route.path}): ${err.message}`);
      failedRoutes++;
    }
  }

  // 2. Test Payment Order API (Monthly Plan)
  console.log("\n--- 2. Testing Payment Order Creation: Monthly Pass (₹300) ---");
  try {
    const res = await fetch(`${BASE_URL}/api/payments/create-order`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ planId: "monthly", userId: "test_candidate_001" }),
    });
    const data = await res.json();
    if (res.status === 200 && data.amount === 30000 && data.priceINR === 300) {
      console.log(`  [PASS] Monthly Order Generated: ₹${data.priceINR} (${data.amount} paise), Order ID: ${data.orderId}`);
    } else {
      console.error(`  [FAIL] Unexpected Monthly Order Response:`, data);
      failedRoutes++;
    }
  } catch (err) {
    console.error(`  [FAIL] Monthly Order Exception: ${err.message}`);
    failedRoutes++;
  }

  // 3. Test Payment Order API (Six-Month Plan)
  console.log("\n--- 3. Testing Payment Order Creation: Six-Month Pass (₹1,500) ---");
  try {
    const res = await fetch(`${BASE_URL}/api/payments/create-order`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ planId: "six_month", userId: "test_candidate_001" }),
    });
    const data = await res.json();
    if (res.status === 200 && data.amount === 150000 && data.priceINR === 1500) {
      console.log(`  [PASS] Six-Month Order Generated: ₹${data.priceINR} (${data.amount} paise), Order ID: ${data.orderId}`);
    } else {
      console.error(`  [FAIL] Unexpected Six-Month Order Response:`, data);
      failedRoutes++;
    }
  } catch (err) {
    console.error(`  [FAIL] Six-Month Order Exception: ${err.message}`);
    failedRoutes++;
  }

  // 4. Test Payment Security Guard (Fraudulent Signature Block)
  console.log("\n--- 4. Testing Payment Security Guard (HMAC Tampering Defense) ---");
  try {
    const res = await fetch(`${BASE_URL}/api/payments/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        razorpay_order_id: "order_spoof_999",
        razorpay_payment_id: "pay_spoof_888",
        razorpay_signature: "tampered_fake_signature_hash",
        planId: "monthly",
      }),
    });
    if (res.status === 400) {
      console.log(`  [PASS] Fraudulent Payment Blocked (HTTP 400 Bad Request returned as expected)`);
    } else {
      console.error(`  [FAIL] Security Guard Failed to Block Invalid Signature! Status: ${res.status}`);
      failedRoutes++;
    }
  } catch (err) {
    console.error(`  [FAIL] Security Guard Exception: ${err.message}`);
    failedRoutes++;
  }

  // 5. Test DGCA 70% Passing Threshold Logic
  console.log("\n--- 5. Testing DGCA Exam Pass/Fail Grading Logic ---");
  const testScores = [
    { score: 6, total: 6, expectedPass: true, label: "6/6 (100.0%)" },
    { score: 5, total: 6, expectedPass: true, label: "5/6 (83.3%)" },
    { score: 4, total: 6, expectedPass: false, label: "4/6 (66.7%) - Below 70% threshold" },
    { score: 0, total: 6, expectedPass: false, label: "0/6 (0.0%) - Fail" },
  ];

  for (const t of testScores) {
    const percentage = Math.round((t.score / t.total) * 100);
    const passed = percentage >= 70;
    if (passed === t.expectedPass) {
      console.log(`  [PASS] Score ${t.label} -> Result: ${passed ? "PASSED (Cleared DGCA)" : "FAILED (Referral Required)"}`);
    } else {
      console.error(`  [FAIL] Grading Mismatch for ${t.label}`);
      failedRoutes++;
    }
  }

  // 6. Test 2FA Email OTP Verification and Single-Device Enforcement
  console.log("\n--- 6. Testing 2FA Email OTP & Single-Device Enforcement ---");
  try {
    const testEmail = "pilot.security.test@aeroprep.in";
    const testUserId = "user-audit-999";

    // Request OTP
    const sendRes = await fetch(`${BASE_URL}/api/auth/otp/send`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: testEmail }),
    });
    const sendData = await sendRes.json();
    if (sendRes.status === 200 && sendData.devHint) {
      console.log(`  [PASS] 2FA Email OTP Generated: Code ${sendData.devHint}`);
      passedRoutes++;
    } else {
      console.error("  [FAIL] 2FA OTP generation failed");
      failedRoutes++;
    }

    // Verify Device A
    const verifyA = await fetch(`${BASE_URL}/api/auth/otp/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: testEmail, code: sendData.devHint, userId: testUserId, userAgent: "Device A" }),
    });
    const verifyDataA = await verifyA.json();
    if (verifyA.status === 200 && verifyDataA.sessionId) {
      console.log(`  [PASS] Device A Verified & Registered (Session: ${verifyDataA.sessionId})`);
      passedRoutes++;
    } else {
      console.error("  [FAIL] Device A verification failed");
      failedRoutes++;
    }

    // Device B logs in (concurrent)
    const sendResB = await fetch(`${BASE_URL}/api/auth/otp/send`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: testEmail }),
    });
    const sendDataB = await sendResB.json();
    await fetch(`${BASE_URL}/api/auth/otp/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: testEmail, code: sendDataB.devHint, userId: testUserId, userAgent: "Device B" }),
    });

    // Check Device A heartbeat (must be blocked)
    const hbA = await fetch(`${BASE_URL}/api/auth/session/heartbeat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: testUserId, sessionId: verifyDataA.sessionId }),
    });
    const hbDataA = await hbA.json();
    if (hbDataA.valid === false && hbDataA.reason === "CONCURRENT_DEVICE_LOGIN") {
      console.log("  [PASS] Concurrent Device Lock Active: Device A automatically terminated when Device B logged in.");
      passedRoutes++;
    } else {
      console.error("  [FAIL] Concurrent session was not terminated");
      failedRoutes++;
    }
  } catch (err) {
    console.error(`  [FAIL] Security check exception: ${err.message}`);
    failedRoutes++;
  }

  // Summary
  console.log("\n=======================================================");
  if (failedRoutes === 0) {
    console.log("✅ ALL SYSTEMS GO! FLIGHT READINESS CHECK PASSED (100%)");
    console.log(`Total Checks Executed : ${ROUTES_TO_TEST.length + 7}`);
    console.log(`Passed Checks         : ${passedRoutes + 4}`);
    console.log(`Failed Checks         : 0`);
    console.log("=======================================================\n");
    process.exit(0);
  } else {
    console.error(`❌ FLIGHT CHECK INCOMPLETE: ${failedRoutes} issues detected.`);
    console.log("=======================================================\n");
    process.exit(1);
  }
}

runSmokeTests();
