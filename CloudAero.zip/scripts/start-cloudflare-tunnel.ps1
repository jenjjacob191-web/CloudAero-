# AeroPrep DGCA - Cloudflare Edge Tunnel
$cfPath = "C:\Users\jenjj\.gemini\antigravity\scratch\cloudflared.exe"
if (-not (Test-Path $cfPath)) {
    Write-Host "Downloading Cloudflare Tunnel binary..."
    curl.exe -L "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe" -o $cfPath
}

Write-Host "Launching Cloudflare Tunnel to port 3000..."
& $cfPath tunnel --url http://localhost:3000
